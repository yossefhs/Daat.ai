# Siman 397 — décisions

## Vérification allégée, passe 1

- Obj. 1 et 5 (niveau 1, séif יז, lecture de la seule MB ס״ק מ״א) : FONDÉES (Biour Halakha « אכן באמת לשון המחבר … תלוי בייחד לו מקום … ולא תלי הדבר כלל בחיוב שמירה »). Corrigé FR/HE/EN : MB ס״ק מ״א et מ״ב attribuées (« Selon la Michna Beroura ») dans l'encadré ; forme courte « sur ce qui décide de ce cas, les commentateurs divergent : niveau 2, section 8 » ajoutée à l'encadré, au tableau (section 4), à la section 6 (nouvelle puce séif יז), à la synthèse (section 8) et à la question. Pas de mention de « celui qui réserve le coin » (forme des niveaux 3/4 gardée).
- Obj. 2 et 4 (niveau 1, séif י, bête en association sans réserve) : FONDÉES (Biour Halakha « דין המחבר הוא רק דעת הרי״ף והרמב״ם אבל שארי ראשונים פליגי »). Corrigé FR/HE/EN : « sur la bête, les commentateurs divergent : niveau 2, section 5 » à l'encadré, au concept ברירה, au tableau, à la section 6 (nouvelle puce séif י), à la synthèse ; question reformulée « Selon la Michna Beroura (ס״ק כ״ד et כ״ה), pourquoi… ? » + réserve. Mot « commentateurs » (HE « המפרשים », EN « commentators ») dans les ajouts ; les « décisionnaires » existants (ד, ה, טז) laissés (mineur, reporté).
- Obj. 3 (niveau 2, section 5, conclusion du BH rattachée au Rachba) : FONDÉE (« אלא שמסיים ומ״מ יש לחוש להחמיר כדעת הראשונים | וע״כ במקום צורך בודאי יש להקל » — « וע״כ » est la décision du BH). Corrigé FR et EN : « — et [le Biour Halakha conclut :] c'est pourquoi… » ; HE sans traduction, rien à corriger.
- Index : n'énonce pas les règles des séifim י et יז ; rien à corriger.
- Portes : verifier-citations (fr,he,en) 342/342 conformes ; verifier-troncatures 0 trou, 0 coupure.

## Verification allegee, passe 2

- [a_corriger, RETENUE] niveau-3-synthese.html l. 376 et niveau-3-synthese-en.html l. 360, schema du seif י : « le tonneau de vin acheté et partagé le jour de fête » / « a barrel of wine bought and divided on Yom Tov » faisait porter « le jour de fête » sur l'achat ; SA 397:10 ne date que le partage (« לקחו חבית של יין וחלקוה ביום טוב »), Rachi Beitsa 37b et SAH 397:10 placent l'achat la veille. Corrige en « le tonneau de vin partagé le jour de fête » / « a barrel of wine divided on Yom Tov », comme aux sections 4 et 10 et au piege 4. HE inchange (forme de la source). Traductions litterales du seif aux niveaux 1-2 laissees (meme ambiguite que la source). Portes : verifier-citations (fr,he,en) 342 conformes, 0 grave ; verifier-troncatures 0 trou, 0 coupure.
