#!/usr/bin/env python3
"""Corrections du coordinateur après la passe 3 du lot 398-401 (398 ×3, 399 ×1, 401 ×1). Pages : comptes exacts, sinon arrêt
sans rien écrire. Sources de build (corps) : même remplacement, compte imprimé (une source peut porter un marqueur au lieu du texte)."""
import pathlib
SP = '/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad'
S = pathlib.Path(SP + '/wt-e9/sources/shabbat'); M = pathlib.Path(SP + '/oh366/memoire-e9')
R4FR = " (sur la condition de l'enceinte, les avis divergent : voir le niveau 2)"
R4EN = " (on the condition of the enclosure, the opinions differ: see Level 2)"
R4HE = " (בתנאי ההיקף הדעות חלוקות: ראה רמה 2)"
C398FR = ", et conclut qu'il paraît [juste] d'alléger ainsi"
C398EN = ", and concludes that it seems [right] to be lenient so"
C398HE = ", ומסיקה שכן נראה להקל"
# (page, [corps...], [(ancien, nouveau, compte)])
T = [
 # 398 — entête des index : la plate-forme sans sa largeur
 ('siman-398/index.html', [], [("un torrent bordé d'une plate-forme ;", "un torrent le plus souvent sec bordé d'une plate-forme large de quatre coudées ;", 4)]),
 ('siman-398/index-en.html', [], [("a riverbed bordered by a platform;", "a mostly dry riverbed bordered by a platform four amos wide;", 4)]),
 ('siman-398/index-he.html', [], [("או נחל שיש לפניו מצבה;", "או נחל שרוב העתים הוא יבש ויש לפניו מצבה ברוחב ארבע אמות;", 4)]),
 # 398 — niveau 1, section 2
 ('siman-398/niveau-1-base.html', [M/'n1-corps-fr.html'], [("le torrent le plus souvent sec, bordé d'une plate-forme (séif ט", "le torrent le plus souvent sec, bordé d'une plate-forme large de quatre coudées (séif ט", 1)]),
 ('siman-398/niveau-1-base-en.html', [M/'n1-corps-en.html'], [("a riverbed that is mostly dry, with a platform on its bank (seif ט", "a riverbed that is mostly dry, with a platform four amos wide on its bank (seif ט", 1)]),
 ('siman-398/niveau-1-base-he.html', [M/'n1-corps-he.html'], [("נחל שרוב העתים הוא יבש, שיש מצבה על שפתו (סעיף ט", "נחל שרוב העתים הוא יבש, שיש על שפתו מצבה ברוחב ארבע אמות (סעיף ט", 1)]),
 # 398 — niveau 3 : la conclusion du Rama (« וכן נראה להקל », séif ד ; « וכן נראה לי להקל », séif ה)
 ('siman-398/niveau-3-synthese.html', [pathlib.Path(SP + '/e9-n3/body_fr.py')], [
   ("rapporte un יש אומרים et pose une condition à tout cela", "rapporte un יש אומרים et pose une condition à tout cela" + C398FR, 3),
   ("la glose du Rama ajoute un יש אומרים et une condition (séif ד)", "la glose du Rama ajoute un יש אומרים et une condition" + C398FR + " (séif ד)", 1),
   ("s'en éloigne encore de soixante-dix coudées et un reste (séif ה)", "s'en éloigne encore de soixante-dix coudées et un reste, et de même partout où l'on mesure, et il lui paraît [juste] d'alléger ainsi (séif ה)", 1)]),
 ('siman-398/niveau-3-synthese-en.html', [pathlib.Path(SP + '/e9-n3/body_en.py')], [
   ("reports a יש אומרים and sets a condition on all this", "reports a יש אומרים and sets a condition on all this" + C398EN, 3),
   ("the Rema's gloss adds a יש אומרים and a condition (seif ד)", "the Rema's gloss adds a יש אומרים and a condition" + C398EN + " (seif ד)", 1),
   ("another seventy amos and a remainder (seif ה) — the commentators differ", "another seventy amos and a remainder, and likewise wherever one measures, and so it seems to him [right] to be lenient (seif ה) — the commentators differ", 1)]),
 ('siman-398/niveau-3-synthese-he.html', [pathlib.Path(SP + '/e9-n3/body_he.py')], [
   ("מביאה יש אומרים ומתנה תנאי על כל זה", "מביאה יש אומרים ומתנה תנאי על כל זה" + C398HE, 3),
   ("הגהת הרמ״א מוסיפה יש אומרים ותנאי (סעיף ד)", "הגהת הרמ״א מוסיפה יש אומרים ותנאי" + C398HE + " (סעיף ד)", 1),
   ("שמרחיקים ממנו עוד שבעים אמה ושיריים (סעיף ה)", "שמרחיקים ממנו עוד שבעים אמה ושיריים, וכן בכל מקום שמודדים, ומסיקה שכן נראה לו להקל (סעיף ה)", 1)]),
 # 399 — niveau 3, piège 4 : la condition des deux mille
 ('siman-399/niveau-3-synthese.html', [pathlib.Path(SP + '/e9-n3-399/body_fr.py')], [
   ("le Choulhan Aroukh HaRav l'écrit dans son séif, 399:8).", "le Choulhan Aroukh HaRav l'écrit dans son séif, 399:8) — quand le fil s'éloigne de quatre coudées, pourvu qu'elle ne soit pas profonde de plus de deux mille ; plus profonde, on mesure toute la pente, même si l'on peut l'englober (séif ה ; Michna Beroura, ס״ק כ״א).", 1)]),
 ('siman-399/niveau-3-synthese-en.html', [pathlib.Path(SP + '/e9-n3-399/body_en.py')], [
   ("the Shulchan Aruch HaRav writes it in its seif, 399:8).", "the Shulchan Aruch HaRav writes it in its seif, 399:8) — when the line moves four amos away, provided it is not deeper than two thousand; deeper, one measures the whole slope, even if one can span it (seif ה; Mishnah Berurah, ס״ק כ״א).", 1)]),
 ('siman-399/niveau-3-synthese-he.html', [pathlib.Path(SP + '/e9-n3-399/body_he.py')], [
   ("שולחן ערוך הרב כותב זאת בסעיפו, שו״ע הרב שצ״ט:ח).", "שולחן ערוך הרב כותב זאת בסעיפו, שו״ע הרב שצ״ט:ח) — כשחוט המשקולת מתרחק ארבע אמות, ובלבד שלא יהא עמוק יותר מאלפים; עמוק יותר — מודד את כל השיפוע, אף אם יכול להבליעו (סעיף ה; משנה ברורה, ס״ק כ״א).", 1)]),
 # 401 — niveau 1 : la condition de la glose du Rama, réserve courte
 ('siman-401/niveau-1-base.html', [M/'s401/n1-corps-fr.html'], [
   ("si la ville n'est pas entourée d'une cloison.</", "si la ville n'est pas entourée d'une cloison" + R4FR + ".</", 1),
   ("si la ville n'est pas entourée d'une cloison, car les objets ont acquis la chevita chez le non-Juif. Le degré", "si la ville n'est pas entourée d'une cloison" + R4FR + ", car les objets ont acquis la chevita chez le non-Juif. Le degré", 1),
   ("si la ville n'est pas entourée d'une cloison, car le vêtement", "si la ville n'est pas entourée d'une cloison" + R4FR + ", car le vêtement", 1),
   ("si la ville n'est pas entourée d'une cloison ; selon la Michna Beroura", "si la ville n'est pas entourée d'une cloison" + R4FR + " ; selon la Michna Beroura", 1),
   ("אצל העכו״ם</span>. <em>La Michna Beroura : il les lui avait prêtés", "אצל העכו״ם</span>" + R4FR + ". <em>La Michna Beroura : il les lui avait prêtés", 1)]),
 ('siman-401/niveau-1-base-en.html', [M/'s401/n1-corps-en.html'], [
   ("if the city is not enclosed by a partition.</", "if the city is not enclosed by a partition" + R4EN + ".</", 1),
   ("if the city is not enclosed by a partition, for the objects acquired shevisah with the non-Jew. Its degree", "if the city is not enclosed by a partition" + R4EN + ", for the objects acquired shevisah with the non-Jew. Its degree", 1),
   ("if the city is not enclosed by a partition, for the garment", "if the city is not enclosed by a partition" + R4EN + ", for the garment", 1),
   ("if the city is not enclosed by a partition; according to the Mishnah Berurah", "if the city is not enclosed by a partition" + R4EN + "; according to the Mishnah Berurah", 1),
   ("אצל העכו״ם</span>. <em>The Mishnah Berurah: he lent them", "אצל העכו״ם</span>" + R4EN + ". <em>The Mishnah Berurah: he lent them", 1)]),
 ('siman-401/niveau-1-base-he.html', [M/'s401/n1-corps-he.html'], [
   ("אם אין העיר מוקפת מחיצה.</", "אם אין העיר מוקפת מחיצה" + R4HE + ".</", 1),
   ("אם אין העיר מוקפת מחיצה, שהרי הבגד", "אם אין העיר מוקפת מחיצה" + R4HE + ", שהרי הבגד", 1),
   ("אם אין העיר מוקפת מחיצה; לפי המשנה ברורה", "אם אין העיר מוקפת מחיצה" + R4HE + "; לפי המשנה ברורה", 1),
   ("אצל העכו״ם</span>. <em>המשנה ברורה: השאילם לו", "אצל העכו״ם</span>" + R4HE + ". <em>המשנה ברורה: השאילם לו", 1),
   ("(רמ״א או״ח ת״א:א). לשונו לשון אזהרה", "(רמ״א או״ח ת״א:א)" + R4HE + ". לשונו לשון אזהרה", 1)]),
]
out, rap = {}, []
for page, corps, reps in T:
    f = S / page; s = out.get(f) or f.read_text()
    for a, b, k in reps:
        assert s.count(a) == k, (page, a, s.count(a)); s = s.replace(a, b)
    out[f] = s
    for c in corps:
        t = out.get(c) or c.read_text()
        for a, b, k in reps:
            n = t.count(a); t = t.replace(a, b); rap.append((c.name, a[:50], n, k))
        out[c] = t
for f, s in out.items(): f.write_text(s)
print(len(out), 'fichiers écrits')
for r in rap:
    if r[2] != r[3]: print('CORPS ÉCART', r)
