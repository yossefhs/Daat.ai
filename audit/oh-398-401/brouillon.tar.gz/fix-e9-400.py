#!/usr/bin/env python3
"""400 N1 : « מפסיד מצד זה » rendu comme un lieu — rétablit la formulation arbitrée à la passe 1 (pages et corps)."""
import pathlib
SP='/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad'
D=pathlib.Path(SP+'/wt-e9/sources/shabbat/siman-400'); C=pathlib.Path(SP+'/oh366/memoire-e9/s400')
R={'':[("du côté où il s'est assis, il n'a pas deux mille coudées depuis cet endroit","il perd de ce fait à l'endroit où il s'est assis, car il n'a pas de là la mesure de deux mille coudées")],
   '-en':[("on the side where he sat, he does not have two thousand amos from that place","he loses on this account at the place where he sat, for he does not have from there the measure of two thousand amos")],
   '-he':[("מצד המקום שישב בו אין לו משם שיעור אלפים","הוא מפסיד במקום שישב בו, שאין לו משם שיעור אלפים")]}
CORPS={'':'n1-corps-fr.html','-en':'n1-corps-en.html','-he':'n1-corps-he.html'}
out={}
for suf,reps in R.items():
    for f in (D/f'niveau-1-base{suf}.html', C/CORPS[suf]):
        s=f.read_text()
        for a,b in reps:
            assert s.count(a)==3,(f,s.count(a)); s=s.replace(a,b)
        out[f]=s
for f,s in out.items(): f.write_text(s)
print(len(out),'fichiers')
