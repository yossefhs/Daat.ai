#!/usr/bin/env python3
"""Assemble le niveau 4 du siman 400 (FR, HE, EN).

Charpente (head, header, fil d'Ariane, section 3, navigation, pied) : siman-397 (publié,
Hilkhot Te'houmin ; CSS de 365 à l'octet). Formes des sections 1, 2 et 4 : siman-395
(séif unique + glose du Rama). Tout l'hébreu de source est EXTRAIT par
scripts/sefaria-extrait.py ; rien n'est retapé. Le contenu rédigé est dans contenu400n4.py.
"""
import os, re, subprocess, sys

WT = '/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9'
EX = os.path.join(WT, 'scripts', 'sefaria-extrait.py')
SRC = os.path.join(WT, 'sources', 'shabbat', 'siman-397')
DST = os.path.join(WT, 'sources', 'shabbat', 'siman-400')
N = 400


def run(args):
    r = subprocess.run([sys.executable, EX] + args, capture_output=True, text=True, cwd=WT)
    if r.returncode != 0:
        raise SystemExit('ECHEC extraction %r : %s %s' % (args, r.stdout, r.stderr))
    return r.stdout.strip()


def seif(w, k, siman=None):
    return run(['seif', w, str(siman or N), str(k)])


def ex(w, k, debut=None, fin=None, frag=None, ref=None):
    siman = ref if ref else str(N)
    a = ['extrait', w, siman, str(k)]
    if frag:
        a.append(frag)
    else:
        a += ['--debut', debut, '--fin', fin]
    s = run(a)
    if s.count('(') > s.count(')'):
        s += ')'
    return s


Q = {
    # Mehaber et Rama (Maginei Eretz)
    'm1': ex('SA', 1, 'מי שהיה בא', 'וחוצה לה אלפים אמה לכל רוח'),
    'm2': ex('SA', 1, 'אבל אם לא היה', 'יותר מחציה'),
    'm2a': ex('SA', 1, frag='לא היה דעתו ליכנס למדינה זו'),
    'm3': ex('SA', 1, 'ואם כלים אלפים', 'יותר מחציה'),
    'rama': ex('SA', 1, 'והוא הדין', 'פרק כ״ז'),
    # Rav (Kehot vocalisée)
    'r1': ex('SAH', 1, 'מי שהיה בא', 'קנה שביתה עמהם'),
    'r2': ex('SAH', 1, 'אבל אם לא היה', 'יותר מחציה'),
    'r2a': ex('SAH', 1, frag='לא היה בדעתו כלל לכנס לעיר זו'),
    'r3': ex('SAH', 1, 'ואם כלים בסוף', 'בסמן ת״ח'),
    'r4': ex('SAH', 1, 'ואפלו אם מבעוד', 'וקנה שביתה במקומו'),
    # Michna, Beit Yossef, Magen Avraham, Michna Beroura
    'mish': ex('REF', 4, 'מי שישב בדרך', 'בלא מתכון', ref='Mishnah_Eruvin.4'),
    'by1': ex('BY', 1, 'שאע״פ שלא היה', 'שביתה עמהם'),
    'by2': ex('BY', 1, frag='וידוע דהלכה כרבי יהודה'),
    'by3': ex('BY', 1, 'ומדברי הרמב״ם', 'נכנס עמהם בתחום'),
    'by4': ex('BY', 1, 'וכתב שם ה״ה', 'למדינה זו נמי'),
    'ma1': ex('MA', 1, 'ואם כלתה', 'ת״ח'),
    'ma2': ex('MA', 2, 'כשהיה בדרך', 'שביתתי במקומי'),
    'mb1': ex('MB', 1, frag='ואפילו נתכוין לקנות שביתה במקום הזה'),
    'mb2': ex('MB', 2, 'כיון שמתחלה', 'הרשות בידו'),
    'mb3': ex('MB', 3, frag='ר״ל עיר'),
    'mb5': ex('MB', 5, 'אבל אם כלים', 'בסימן ת״ח'),
    'mb6': ex('MB', 6, 'ר״ל דגם ברישא', 'ממקום שביתתו'),
}


def q(s):
    def rep(m):
        return Q[m.group(1)]
    out = re.sub(r'\[\[(\w+)\]\]', rep, s)
    assert '[[' not in out, out
    return out


# ---------------------------------------------------------------- section 1 : le texte du Rav
SEIFS = []
for k in range(1, 2):
    t = seif('SAH', k)
    t = t.replace('<b>', '').replace('</b>', '')
    t = t.replace('<br>', '<br><br>')
    SEIFS.append(t)
PREV_N = [21]
LETTRES = ['א']


def apercu(t, n):
    plain = re.sub(r'<[^>]+>', ' ', t)
    mots = plain.split()
    pris = mots[:n]
    pris[-1] = pris[-1].rstrip(',;:.—')
    return ' '.join(pris) + '…'


PREVIEWS = [apercu(SEIFS[i], PREV_N[i]) for i in range(len(SEIFS))]
CHAPEAU = SEIFS[0].split(':<br>')[0]  # « מִי שֶׁיָּשַׁב … וּבוֹ סְעִיף אֶחָד »
CHAP_SANS_COMPTE = CHAPEAU.rsplit(' וּבוֹ ', 1)[0]
COMPTE = 'וּבוֹ ' + CHAPEAU.rsplit(' וּבוֹ ', 1)[1]

exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'contenu400n4.py'), encoding='utf-8').read())


def bloc(i, trad_cls, trad):
    ouvert = ' open' if i == 0 else ''
    s = ('    <details class="seif-details"%s>\n'
         '      <summary class="seif-summary">\n'
         '        <span class="seif-num">סעיף %s</span>\n'
         '        <span class="seif-preview">%s</span>\n'
         '      </summary>\n'
         '      <div class="sa-block">\n'
         '        <p class="sa-he">%s</p>\n') % (ouvert, LETTRES[i], PREVIEWS[i], SEIFS[i])
    if trad_cls:
        s += '        <p class="%s">%s</p>\n' % (trad_cls, trad)
    s += '      </div>\n    </details>\n'
    return s


def points(lang, pts):
    out = []
    h3font = "'Frank Ruhl Libre', serif" if lang == 'he' else "'Cormorant Garamond', serif"
    lab = LABELS[lang]
    for p in pts:
        s = '    <div class="sa-block">\n'
        s += '      <p class="sa-he" style="font-size: 19px; font-weight: 700; margin-bottom: 12px; color: var(--habad-deep);">%s</p>\n' % p['he_t']
        if lang != 'he':
            s += '      <p class="sa-%s">%s</p>\n' % (lang, p['t'])
        s += ('      <h3 style="font-family: %s; font-size: 19px; font-weight: 600; color: var(--navy); margin-bottom: 10px;" id="%s">%s</h3>\n'
              % (h3font, p['id'], p['h3']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['rama' if p.get('rama') else 'meh'], q(p['meh']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['rav'], q(p['rav']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['diff'], q(p['diff']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['comm'], q(p['comm']))
        s += '    </div>\n'
        out.append(s)
    return ''.join(out)


def construire(lang):
    suf = {'fr': '', 'he': '-he', 'en': '-en'}[lang]
    C = CONTENU[lang]
    T = open(os.path.join(SRC, 'niveau-4-daat-harav%s.html' % suf), encoding='utf-8').read()
    i_hero = T.index('<div class="page-hero">')
    m3 = re.search(r'\n  <!-- 3\. ', T)
    i_s3 = m3.start() + 1
    i_s4 = T.index('    <!-- 4. LEMAASEH')
    i_nav = T.index('<nav class="niveau-nav"')
    A, B, Cc = T[:i_hero], T[i_s3:i_s4], T[i_nav:]

    def fix(x):
        x = x.replace('/oh/397/', '/oh/400/').replace('/oh/396/', '/oh/399/')
        x = x.replace('siman-397', 'siman-400')
        x = x.replace('Siman 397', 'Siman 400').replace('Siman 396', 'Siman 399')
        x = x.replace('סימן שצ״ו · 396', 'סימן שצ״ט · 399')
        x = x.replace('סימן שצ״ז · 397', 'סימן ת׳ · 400')
        x = x.replace('שצ״ז', 'ת׳').replace('שצ-ז', 'ת')
        return x

    A = fix(A)
    A = re.sub(r'<title>.*?</title>', '<title>%s</title>' % C['title'], A, count=1)
    A = re.sub(r'<meta name="description" content="[^"]*">', '<meta name="description" content="%s">' % C['desc'], A, count=1)
    A = re.sub(r'<meta property="og:description" content="[^"]*">', '<meta property="og:description" content="%s">' % C['og'], A, count=1)
    A = re.sub(r'<meta name="twitter:description" content="[^"]*">', '<meta name="twitter:description" content="%s">' % C['tw'], A, count=1)
    A = re.sub(r'"headline": "[^"]*"', '"headline": "%s"' % C['title'], A, count=1)
    A = re.sub(r'"description": "[^"]*"', '"description": "%s"' % C['ld'], A, count=1)
    A = re.sub(r'"datePublished": "[^"]*"', '"datePublished": "2026-11-26"', A, count=1)
    A = re.sub(r'"dateModified": "[^"]*"', '"dateModified": "2026-11-26"', A, count=1)
    B = fix(B)
    Cc = fix(Cc)

    s1 = ''.join(bloc(i, C['trad_cls'], C['trads'][i] if C['trad_cls'] else None) for i in range(len(SEIFS)))
    corps = C['hero'] + '\n<main>\n\n' + C['intro'] + '\n' + C['s1_head'] + '\n' + s1 + '\n' + C['s1_source'] + '\n  </section>\n\n'
    corps += C['s2_head'] + '\n' + points(lang, C['points']) + '\n  </section>\n\n'
    s4 = C['s4_head'] + '\n' + '\n'.join('        <li>%s</li>' % q(li) for li in C['s4']) + '\n' + C['s4_foot']
    out = A + corps + B + s4 + '\n' + Cc
    os.makedirs(DST, exist_ok=True)
    with open(os.path.join(DST, 'niveau-4-daat-harav%s.html' % suf), 'w', encoding='utf-8') as f:
        f.write(out)
    # résidus
    for mot in ('397', 'שצ״ז', '396', 'שצ״ו', '[[', ']]', 'שצ-ז'):
        for m in re.finditer(re.escape(mot), out):
            ligne = out[max(0, m.start() - 60):m.end() + 30].replace('\n', ' ')
            print('RESIDU', lang, mot, '…', ligne)
    print('écrit', lang, len(out))


for L in ('fr', 'he', 'en'):
    construire(L)
