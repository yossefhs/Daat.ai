#!/usr/bin/env python3
"""Assemble index{,-he,-en}.html du siman 400 : index publié de 397 (Te'houmin), champs remplacés un à un.
Chaque motif doit apparaître exactement le nombre de fois attendu ; l'hébreu du chapeau est extrait de Sefaria."""
import importlib.util, re, sys, pathlib
WT = pathlib.Path('/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9')
spec = importlib.util.spec_from_file_location('se', WT / 'scripts' / 'sefaria-extrait.py')
se = importlib.util.module_from_spec(spec); spec.loader.exec_module(se)

def extrait(w, s, k, frag):
    t = se.nettoyer(se.segments(w, s)[2][k - 1])
    occ = se.trouver(t, frag)
    if len(occ) != 1:
        raise SystemExit('extrait %s %s:%d « %s » : %d' % (w, s, k, frag, len(occ)))
    a, b = occ[0]
    return re.sub(r'<[^>]+>', '', t[a:b]).strip()

CHAP = extrait('SA', '400', 1, 'מי שישב לו בדרך לנוח ולא ידע אם הוא בתחום אם לאו')
CHAP399 = extrait('SA', '399', 1, 'במה מודדין התחומין ובמקום המדידה ומי הוא המודד')

C = {}
C[''] = dict(
 title="Siman 400 — Celui qui s'est assis en chemin sans savoir qu'il était dans le te'houm de la ville | Hilkhot Te'houmin",
 desc="Étude du Siman 400 du Choulhan Aroukh, Orah Haïm, Hilkhot Te'houmin : celui qui venait pour entrer dans une ville, s'est assis en chemin pour se reposer quand la nuit est tombée, sans savoir qu'il était dans le te'houm de la ville, puis s'y est trouvé, a acquis la chevita dans la ville — il la parcourt toute, avec deux mille coudées au-dehors ; il paraît évident à la Michna Beroura que cela vaut quand il veut aller à la ville, et que, s'il veut rester à sa place, le choix lui appartient — ; s'il n'avait pas l'intention d'entrer dans cette ville, il a acquis la chevita à sa place, avec deux mille coudées à partir de là, et, si elles s'achèvent au milieu de la ville, il n'y marche pas au-delà de sa moitié ; la glose du Rama : la loi est aussi ainsi s'il avait l'intention d'entrer et a dit « ma chevita est à ma place » (selon la Michna Beroura, dit expressément au crépuscule). 1 séif dans le Choul'han Aroukh du Mehaber, avec une glose du Rama introduite par הגה, et 1 dans le Choulhan Aroukh HaRav.",
 kw="siman 400, choulhan aroukh, hilkhot te'houmin, te'houm chabbat, chevita, kana chevita, deux mille coudées, alpayim ama, ville, intention d'entrer, chevitati bimkomi, daat harav, admour hazaken, habad",
 sujet="Celui qui s'est assis en chemin sans savoir qu'il était dans le te'houm de la ville",
 og_suffix=" (Choulhan Aroukh)",
 sub="1 séif dans le Choul'han Aroukh du Mehaber, avec une glose du Rama introduite par הגה ; 1 dans le Choulhan Aroukh HaRav, sous sa propre numérotation (niveau 4). Celui qui s'est assis en chemin pour se reposer quand la nuit est tombée, et qui était, sans le savoir, dans le te'houm d'une ville : où a-t-il acquis la chevita ? Le séif répond selon son intention : s'il venait pour entrer dans la ville, il a acquis la chevita dans la ville, la parcourt toute, et a deux mille coudées au-dehors — selon la Michna Beroura, même s'il avait eu l'intention de l'acquérir à cet endroit, et il lui paraît évident que cela vaut quand il veut aller à la ville, et que, s'il veut rester à sa place, le choix lui appartient (niveau 2) ; s'il n'avait pas l'intention d'entrer dans cette ville, il a acquis la chevita à sa place, avec deux mille coudées à partir de là, et, si elles s'achèvent au milieu de la ville, il n'y marche pas au-delà de sa moitié. Le Rama ajoute : la loi est aussi ainsi s'il avait l'intention d'entrer et a dit « ma chevita est à ma place » — selon la Michna Beroura, dit expressément au crépuscule (niveau 2).",
 n4="Le Choulhan Aroukh de l'Admour HaZaken sur ce siman : 1 séif.",
 n4_old="Le Choulhan Aroukh de l'Admour HaZaken sur ce siman : 20 séifim.",
 prev='<a href="/oh/399/" class="prev">← Siman 399 — Avec quoi, où et par qui l\'on mesure les te\'houmim</a>',
 label_old='Siman 397', label_new='Siman 400',
)
C['-he'] = dict(
 title="סימן ת׳ — %s | הלכות תחומין" % CHAP,
 desc="לימוד סימן ת׳ בשולחן ערוך, אורח חיים, הלכות תחומין: מי שהיה בא בדרך ליכנס לעיר, וישב בדרך לנוח וחשכה לו, ולא ידע שהוא בתחום העיר, ואחר כך מצא עצמו בתחומה — קנה שביתה בעיר, ומהלך את כולה וחוצה לה אלפים אמה; ונראה למשנה ברורה פשוט שכל זה כשרוצה לילך לעיר, ואם רוצה להישאר במקומו, הרשות בידו —; אם לא היה דעתו ליכנס לעיר זו, קנה שביתה במקומו, ויש לו משם אלפים אמה, ואם כלים בחצי העיר, אינו מהלך בעיר יותר מחציה; הגהת הרמ״א: גם בזה הדין כך, אם היה דעתו ליכנס ואמר שביתתי במקומי (לפי המשנה ברורה, שאמר כן בפירוש בין השמשות). סעיף אחד בשולחן ערוך של המחבר, עם הגהת רמ״א הפותחת במילה הגה, וסעיף אחד בשולחן ערוך הרב.",
 kw="סימן ת׳, שולחן ערוך, הלכות תחומין, תחום שבת, שביתה, קנה שביתה, אלפים אמה, עיר, דעתו ליכנס, שביתתי במקומי, דעת הרב, אדמו״ר הזקן, חב״ד",
 sujet=CHAP,
 og_suffix=" (שולחן ערוך)",
 h1="מי שישב בדרך ולא ידע שהוא בתחום העיר",
 sub="סעיף אחד בשולחן ערוך של המחבר, עם הגהת רמ״א הפותחת ב«הגה»; סעיף אחד בשולחן ערוך הרב, במספור משלו (רמה 4). מי שישב בדרך לנוח וחשכה לו, והיה בתחום העיר ולא ידע — היכן קנה שביתה? הסעיף משיב לפי דעתו: אם היה בא ליכנס לעיר, קנה שביתה בעיר, ומהלך את כולה וחוצה לה אלפים אמה — לפי המשנה ברורה, ואפילו נתכוון לקנות שביתה במקום הזה, ונראה לו פשוט שכל זה כשרוצה לילך לעיר, ואם רוצה להישאר במקומו, הרשות בידו (רמה 2); אם לא היה דעתו ליכנס לעיר זו, קנה שביתה במקומו, ויש לו משם אלפים אמה, ואם כלים בחצי העיר, אינו מהלך בעיר יותר מחציה. הרמ״א מוסיף: גם בזה הדין כך, אם היה דעתו ליכנס ואמר «שביתתי במקומי» — לפי המשנה ברורה, שאמר כן בפירוש בין השמשות (רמה 2).",
 n4="שולחן ערוך הרב על סימן זה: סעיף אחד.",
 n4_old="שולחן ערוך הרב על סימן זה: כ׳ סעיפים.",
 prev='<a href="/oh/399/he" class="prev">סימן שצ״ט · 399 — %s →</a>' % CHAP399,
 label_old='סימן שצ״ז', label_new='סימן ת׳',
)
C['-en'] = dict(
 title="Siman 400 — One who sat on the road without knowing he was within the city's techum | Hilchos Techumin",
 desc="Study of Siman 400 of the Shulchan Aruch, Orach Chaim, Hilchos Techumin: one who was coming to enter a city, sat on the road to rest when night fell, without knowing that he was within the city's techum, and afterwards found himself within it, acquired his shevisah in the city — he walks all of it, with two thousand amos outside it; it seems obvious to the Mishnah Berurah that this applies when he wants to go to the city, and that, if he wants to remain in his place, the choice is his —; if he did not intend to enter this city, he acquired his shevisah in his place, with two thousand amos from there, and, if they end in the middle of the city, he does not walk in it beyond its half; the Rema's gloss: the law is also so if he intended to enter and said “my shevisah is in my place” (according to the Mishnah Berurah, said explicitly at twilight). 1 seif in the Shulchan Aruch of the Mechaber, with a gloss of the Rema introduced by הגה, and 1 in the Shulchan Aruch HaRav.",
 kw="siman 400, shulchan aruch, hilchos techumin, techum shabbos, shevisah, kanah shevisah, two thousand amos, alpayim amah, city, intention to enter, shevisasi bimkomi, daat harav, alter rebbe, chabad",
 sujet="One who sat on the road without knowing he was within the city's techum",
 og_suffix=" (Shulchan Aruch)",
 sub="1 seif in the Shulchan Aruch of the Mechaber, with a gloss of the Rema introduced by הגה; 1 in the Shulchan Aruch HaRav, under its own numbering (Level 4). One who sat on the road to rest when night fell, and was, without knowing it, within the techum of a city: where did he acquire his shevisah? The seif answers according to his intention: if he was coming to enter the city, he acquired his shevisah in the city, walks all of it, and has two thousand amos outside it — according to the Mishnah Berurah, even if he had intended to acquire it in that place, and it seems obvious to it that this applies when he wants to go to the city, and that, if he wants to remain in his place, the choice is his (Level 2); if he did not intend to enter this city, he acquired his shevisah in his place, with two thousand amos from there, and, if they end in the middle of the city, he does not walk in it beyond its half. The Rema adds: the law is also so if he intended to enter and said “my shevisah is in my place” — according to the Mishnah Berurah, said explicitly at twilight (Level 2).",
 n4="The Shulchan Aruch HaRav of the Alter Rebbe on this siman: 1 seif.",
 n4_old="The Shulchan Aruch HaRav of the Alter Rebbe on this siman: 20 seifim.",
 prev='<a href="/oh/399/en" class="prev">← Siman 399 — With what, where and by whom the techumin are measured</a>',
 label_old='Siman 397', label_new='Siman 400',
)

def sub1(t, motif, valeur, n=1):
    k = len(re.findall(motif, t))
    if k != n:
        raise SystemExit('motif %r : %d (attendu %d)' % (motif, k, n))
    return re.sub(motif, lambda m: valeur, t)

def construire(suf):
    c = C[suf]
    for v in c.values():
        if '"' in v and not v.startswith('<a '):
            raise SystemExit('guillemet ASCII dans %r' % v[:60])
    t = (WT / 'sources/shabbat/siman-397' / ('index%s.html' % suf)).read_text(encoding='utf-8')
    sujet = c['sujet']
    t = sub1(t, r'<title>[^<]*</title>', '<title>%s</title>' % c['title'])
    t = sub1(t, r'<meta name="description" content="[^"]*">', '<meta name="description" content="%s">' % c['desc'])
    t = sub1(t, r'<meta name="keywords" content="[^"]*">', '<meta name="keywords" content="%s">' % c['kw'])
    t = sub1(t, r'<meta property="og:title" content="[^"]*">', '<meta property="og:title" content="%s — %s%s">' % (c['label_new'] if suf == '-he' else 'Siman 400', sujet, c['og_suffix']))
    t = sub1(t, r'<meta property="og:description" content="[^"]*">', '<meta property="og:description" content="%s">' % c['desc'])
    t = sub1(t, r'<meta name="twitter:title" content="[^"]*">', '<meta name="twitter:title" content="%s — %s">' % (c['label_new'] if suf == '-he' else 'Siman 400', sujet))
    t = sub1(t, r'<meta name="twitter:description" content="[^"]*">', '<meta name="twitter:description" content="%s">' % c['desc'])
    t = sub1(t, r'"headline": "[^"]*"', '"headline": "%s — %s"' % (c['label_new'] if suf == '-he' else 'Siman 400', sujet))
    t = sub1(t, r'"alternativeHeadline": "[^"]*"', '"alternativeHeadline": "%s"' % CHAP)
    t = sub1(t, r'"description": "(?:Étude du Siman|לימוד סימן|Study of Siman)[^"]*"', '"description": "%s"' % c['desc'])
    t = sub1(t, r'"keywords": "[^"]*"', '"keywords": "%s"' % c['kw'])
    t = sub1(t, r'<div class="daat-hero-siman"><span class="daat-hero-siman-he">[^<]*</span><span class="daat-hero-siman-num">[^<]*</span></div>',
             '<div class="daat-hero-siman"><span class="daat-hero-siman-he">סימן ת׳</span><span class="daat-hero-siman-num">Siman 400</span></div>')
    t = sub1(t, r'<p class="daat-hero-title-he" aria-hidden="true">[^<]*</p>', '<p class="daat-hero-title-he" aria-hidden="true">%s</p>' % CHAP)
    t = sub1(t, r'<h1 class="daat-hero-title-fr" style="margin: 0;">[^<]*</h1>', '<h1 class="daat-hero-title-fr" style="margin: 0;">%s</h1>' % c.get('h1', sujet))
    t = sub1(t, r'<p class="daat-hero-subtitle">[^<]*</p>', '<p class="daat-hero-subtitle">%s</p>' % c['sub'])
    if t.count(c['n4_old']) != 1:
        raise SystemExit('carte N4 : %r' % c['n4_old'])
    t = t.replace(c['n4_old'], c['n4'])
    t = sub1(t, r'<a href="/oh/396/[^"]*" class="prev">[^<]*</a>', c['prev'])
    t = t.replace('/oh/397/', '/oh/400/').replace('siman-397.png', 'siman-400.png')
    t = t.replace('"%s"' % c['label_old'], '"%s"' % c['label_new'])
    t = t.replace('<span class="current">%s</span>' % c['label_old'], '<span class="current">%s</span>' % c['label_new'])
    for ln, l in enumerate(t.split('\n'), 1):
        if re.search(r'39[6-9]|שצ״[זוחט]', l):
            print('  [voisin] %s l.%d : %s' % (suf or 'fr', ln, l.strip()[:160]), file=sys.stderr)
    out = WT / 'sources/shabbat/siman-400' / ('index%s.html' % suf)
    out.write_text(t, encoding='utf-8')
    print('écrit', out, len(t))

if __name__ == '__main__':
    for suf in [x if x != 'fr' else '' for x in (sys.argv[1:] or ['fr', '-he', '-en'])]:
        construire(suf)
