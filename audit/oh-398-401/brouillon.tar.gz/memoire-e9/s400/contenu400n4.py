# Contenu rédigé du niveau 4 du siman 400 — lu par build400n4.py (exec).
# Les marqueurs [[clé]] sont remplacés par l'extraction de Sefaria (dict Q du builder).
# Variables attendues du builder : CHAP_SANS_COMPTE, COMPTE.

LABELS = {
    'fr': {'meh': "Ce qu'écrit le Mehaber :", 'rama': "Ce qu'écrit le Rama :", 'rav': "Ce qu'écrit le Rav :",
           'diff': 'La différence :', 'comm': 'Ce qui se lit ailleurs :'},
    'he': {'meh': 'דברי המחבר:', 'rama': 'דברי הרמ״א:', 'rav': 'דברי הרב:',
           'diff': 'ההבדל:', 'comm': 'מה שכתוב במקום אחר:'},
    'en': {'meh': 'What the Mechaber writes:', 'rama': 'What the Rema writes:', 'rav': 'What the Rav writes:',
           'diff': 'The difference:', 'comm': 'What is found elsewhere:'},
}

SAH = '(שו״ע הרב ת׳:א)'
SA = '(שו״ע או״ח ת׳:א)'
RAMA = '(רמ״א או״ח ת׳:א)'
BY = '(בית יוסף או״ח ת׳)'
MISH = '(משנה עירובין ד:ד)'


def Qt(k, ref):
    return '«&nbsp;[[%s]]&nbsp;» %s' % (k, ref)


def MB(n):
    return '(משנה ברורה ת׳ ס״ק %s)' % n


def MA(n):
    return '(מגן אברהם ת׳ ס״ק %s)' % n


CHAP_STRONG = 'סימן ת׳ — %s — %s' % (CHAP_SANS_COMPTE, COMPTE)

# ============================================================================ FR
FR = {}
FR['title'] = "Siman ת׳ · Niveau 4 — Chitah de l'Admour HaZaken : celui qui s'est assis en chemin pour se reposer sans savoir s'il était dans la limite | Hilkhot Te'houmin"
FR['desc'] = ("Niveau 4 (Daat HaRav) du Siman ת׳ — celui qui, venant en chemin pour entrer dans une ville, s'est assis pour se reposer, "
              "sur qui la nuit est tombée sans qu'il sache qu'il était dans la limite de la ville, et qui s'est ensuite trouvé dans sa limite : "
              "il acquiert son lieu de repos (chevita) dans la ville, bien qu'il ait eu l'intention de l'acquérir à sa place ; "
              "s'il n'avait pas du tout l'intention d'entrer dans cette ville, ou si, ayant eu de jour l'intention d'y entrer, il a dit expressément "
              "au crépuscule « mon lieu de repos est à ma place », il l'acquiert à sa place. Le texte intégral du séif unique du Choulhan Aroukh "
              "de l'Admour HaZaken, sa traduction, ce en quoi le texte du Rav diffère du Mehaber et du Rama, la conduite pratique.")
FR['og'] = ("La chitah de l'Admour HaZaken sur celui qui s'est assis en chemin sans savoir qu'il était dans la limite de la ville : "
            "où il acquiert son lieu de repos selon son intention d'entrer dans la ville, ce qu'il peut parcourir de la ville, "
            "et la parole expresse au crépuscule « mon lieu de repos est à ma place ».")
FR['tw'] = "Chitah de l'Admour HaZaken sur celui qui s'est assis en chemin pour se reposer sans savoir s'il était dans la limite."
FR['ld'] = ("Niveau 4 (Daat HaRav) du Siman ת׳ : celui qui s'est assis en chemin pour se reposer sans savoir s'il était dans la limite, "
            "dans le Choulhan Aroukh de l'Admour HaZaken.")
FR['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">Orah Haïm ת׳ · Niveau 4 · שיטת אדמו״ר הזקן</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">Daat HaRav — Le Choulhan Aroukh de l'Admour HaZaken sur le Siman ת׳</h1>
    <p class="hero-subtitle">Celui qui s'est assis en chemin pour se reposer, sur qui la nuit est tombée, et qui ne savait pas s'il était dans la limite (<em>te'houm</em>) de la ville : s'il venait pour entrer dans la ville, il acquiert son lieu de repos (<em>chevita</em>) dans la ville, bien qu'il ait eu l'intention de l'acquérir à sa place ; s'il n'avait pas du tout l'intention d'entrer dans cette ville, il l'acquiert à sa place, avec ce qu'il peut alors parcourir de la ville ; et si, de jour encore, il avait l'intention d'y entrer mais a dit expressément au crépuscule « mon lieu de repos est à ma place », il l'acquiert aussi à sa place. Le séif unique du Choulhan Aroukh de l'Admour HaZaken, comparé au séif unique du Mehaber et à la glose du Rama.</p>
  </div>
</div>
'''
FR['intro'] = '''  <div class="intro-block">
    <p><strong>Pourquoi un niveau 4 dédié à l'Admour HaZaken ?</strong> Le <strong>Choulhan Aroukh de l'Admour HaZaken</strong> n'est pas un commentaire sur le Mehaber (מחבר) : c'est un Choulhan Aroukh à part entière, écrit par l'Admour HaZaken, avec sa propre découpe et sa propre numérotation des séifim. Ici, le Choulhan Aroukh HaRav compte un séif, et le Choul'han Aroukh du Mehaber un séif aussi : les renvois de cette page suivent la numérotation du Rav, sauf quand le Choul'han Aroukh du Mehaber est nommé.</p>
    <p>Cette page rassemble, pour le siman ת׳, le texte intégral du Rav et sa traduction, ce en quoi son texte diffère de celui du Mehaber et du Rama, et la conduite pratique qui en découle.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken.html" style="color:var(--habad);font-weight:600;">→ Lire la préface générale sur la chitah de l'Admour HaZaken</a></p>
  </div>
'''
FR['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · טקסט אדמו״ר הזקן</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-ת">שלחן ערוך הרב — סימן ת׳</h2>
    <h2 class="section-title-fr" id="le-texte-integral-du-choulhan-aroukh-de-l-admour-hazaken-שולחן-ערוך-הרב">Le texte intégral du Choulhan Aroukh de l'Admour HaZaken (שולחן ערוך הרב)</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 15px;">
      <strong>%s</strong><br>
      <em>Source : édition Kehot, telle que reproduite sur Sefaria. 1 séif (le Choul'han Aroukh du Mehaber en compte 1 aussi, sous sa propre numérotation).</em>
    </p>
''' % CHAP_STRONG
FR['trad_cls'] = 'sa-fr'
FR['trads'] = [
    "Celui qui s'est assis en chemin pour se reposer et ne savait pas s'il était dans la limite (<em>te'houm</em>) ou non ; il contient un seul séif :<br><br>"
    "Celui qui venait en chemin pour entrer dans la ville, s'est assis en chemin pour se reposer, et la nuit est tombée sur lui, sans qu'il sache qu'il était dans la limite (<em>te'houm</em>) de la ville, et ensuite il s'est trouvé [être] dans sa limite : il a acquis son lieu de repos (<em>kana chevita</em>) dans la ville ; il y entre le Chabbat, il en parcourt toute [l'étendue] et, au-dehors, deux mille amot dans chaque direction. Et bien qu'il ait eu l'intention d'acquérir son lieu de repos à sa place, puisque, s'il avait su que la ville était à l'intérieur de sa limite, il n'aurait voulu acquérir son lieu de repos qu'avec les gens de la ville, il est comme s'il avait acquis son lieu de repos avec eux. <br><br>"
    "Mais s'il n'avait pas du tout l'intention d'entrer dans cette ville, il a acquis son lieu de repos à sa place, et de là il a deux mille amot dans chaque direction. Et si les deux mille [amot] depuis le lieu de son repos s'achèvent à la moitié de la ville, il ne marche pas dans la ville plus que sa moitié. Et s'ils s'achèvent au bout de la ville, toute la ville compte pour lui comme quatre amot, comme il sera expliqué au siman 408.<br><br>"
    "Et même si, alors qu'il faisait encore jour (<em>mibe'od yom</em>), il avait l'intention d'entrer dans cette ville, et qu'au crépuscule (<em>bein hachmachot</em>) il a dit expressément « mon lieu de repos est à ma place » (<em>chevitati bimkomi</em>), il a déraciné son lieu de repos de [celui des] gens de la ville, et il a acquis son lieu de repos à sa place :"
]
FR['s1_source'] = '''    <p style="margin-top: 20px; font-size: 13px; color: var(--text-muted); font-style: italic;">
      Source : <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.400" target="_blank" style="color: var(--habad);">Sefaria — Shulchan Arukh HaRav, Orach Chayim ת׳</a>. Sefaria ne donne aucune entrée de Kountress Aharon pour ce siman.
    </p>'''
FR['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · לשון הרב ולשון המחבר</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ-א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="ou-le-texte-du-rav-differe-du-seif-du-mehaber-et-du-rama">Où le texte du Rav diffère du séif du Mehaber et du Rama</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid);">
      Chaque point met côte à côte le séif unique du Choul'han Aroukh du Mehaber, ou la glose du Rama, et le séif unique du Choulhan Aroukh de l'Admour HaZaken, dans l'ordre du texte du Rav, et ne relève que ce que la comparaison des deux textes montre. Un point relevé n'est pas propre au Rav pour autant : la page en nomme parfois la source ; elle ne relève ni toutes les sources ni toutes les divergences (voir aussi le niveau 2).
    </p>'''
FR['points'] = [
    {
        'he_t': 'נקודה א — מי שהיה בא בדרך לכנס לעיר ולא ידע שהוא בתחום (שו״ע הרב ת׳:א)',
        't': "Point א — celui qui venait pour entrer dans la ville sans savoir qu'il était dans sa limite (Choulhan Aroukh HaRav 400:1)",
        'id': 'le-lieu-de-repos-acquis-dans-la-ville',
        'h3': 'Le lieu de repos acquis dans la ville',
        'meh': Qt('m1', SA) + '.',
        'rav': Qt('r1', SAH) + '.',
        'diff': ("le texte du Rav reprend le cas et la règle du séif du Mehaber, et y ajoute ce que ce séif n'écrit pas : "
                 "la règle vaut bien qu'il ait eu l'intention d'acquérir son lieu de repos à sa place ; et sa raison : puisque, s'il avait su "
                 "que la ville était à l'intérieur de sa limite, il n'aurait voulu acquérir son lieu de repos qu'avec les gens de la ville, "
                 "il est comme s'il l'avait acquis avec eux."),
        'comm': ("la Michna : " + Qt('mish', MISH) + " — celui qui s'est assis en chemin, s'est levé et a vu qu'il était proche de la ville : "
                 "puisque ce n'était pas son intention, il n'entre pas, ce sont les paroles de Rabbi Meïr ; Rabbi Yehouda dit : il entre ; "
                 "Rabbi Yehouda a dit : c'est arrivé, et Rabbi Tarfon est entré sans en avoir l'intention. "
                 "Le Beit Yossef, avant le Rav, explique ainsi la parole de Rabbi Yehouda : " + Qt('by1', BY) +
                 " — bien qu'il ne sût pas que la ville était à l'intérieur de sa limite, et qu'il eût l'intention d'établir son repos à sa place, "
                 "comme [la Michna] l'enseigne : « ce n'était pas son intention », puisque, s'il avait su que la ville était à l'intérieur de sa limite, "
                 "il n'aurait acquis son lieu de repos qu'avec les gens de la ville, il est comme celui qui a acquis son lieu de repos avec eux ; "
                 "puis il écrit : " + Qt('by2', BY) + " — on sait que la halakha est comme Rabbi Yehouda ; et : " + Qt('by3', BY) +
                 " — des paroles du Rambam et du Maggid Michné, au chapitre 26, il ressort qu'il s'agit ici du cas où il avait l'intention "
                 "d'aller à cette ville, et c'est pourquoi il a acquis son lieu de repos avec les gens de la ville, comme eux, puisqu'il est entré "
                 "avec eux dans la limite. La Michna Beroura, après le Rav, écrit sur ce séif : " + Qt('mb1', MB('א')) +
                 " — et même s'il avait eu l'intention d'acquérir son lieu de repos en ce lieu-ci ; et : " + Qt('mb2', MB('ב')) +
                 " — puisqu'au départ il avait l'intention d'entrer dans la ville, et que, s'il avait su que la ville était à l'intérieur de sa limite, "
                 "il n'aurait voulu acquérir son lieu de repos qu'avec les gens de la ville ; c'est pourquoi maintenant aussi il est comme l'un des gens "
                 "de la ville, pour la parcourir tout entière et avoir deux mille [amot] dans chaque direction. Néanmoins, il y a là aussi une rigueur : "
                 "il perd de ce fait, à l'endroit où il s'est assis : il n'a pas de là la mesure de deux mille, puisqu'il est compté comme l'un des gens "
                 "de la ville ; et il paraît simple que tout cela vaut quand il veut maintenant aller à la ville, et c'est en sa faveur qu'on a été "
                 "indulgent avec lui ; mais s'il veut rester à l'endroit où il a acquis son lieu de repos, libre à lui. Ce dernier point (le choix "
                 "de rester), la Michna Beroura l'écrit ; le séif du Rav ne l'écrit pas."),
    },
    {
        'he_t': 'נקודה ב — אם לא היה בדעתו כלל לכנס לעיר זו (שו״ע הרב ת׳:א)',
        't': "Point ב — s'il n'avait pas du tout l'intention d'entrer dans cette ville (Choulhan Aroukh HaRav 400:1)",
        'id': 'le-lieu-de-repos-acquis-a-sa-place',
        'h3': 'Le lieu de repos acquis à sa place',
        'meh': Qt('m2', SA) + '.',
        'rav': Qt('r2', SAH) + '.',
        'diff': ("la règle est la même dans les deux textes, y compris pour le cas où les deux mille s'achèvent à la moitié de la ville. "
                 "Là où le Mehaber écrit " + Qt('m2a', SA) + ", le Rav écrit " + Qt('r2a', SAH) +
                 " : il ajoute <em>kelal</em> (« pas du tout ») et écrit <em>'ir</em> (« ville ») là où le Mehaber écrit <em>medina</em>."),
        'comm': ("la Michna Beroura, après le Rav, explique le mot <em>lamedina</em> du Mehaber : " + Qt('mb3', MB('ג')) +
                 " — c'est-à-dire une ville."),
    },
    {
        'he_t': 'נקודה ג — אם כלים בסוף העיר (שו״ע הרב ת׳:א)',
        't': "Point ג — si [les deux mille amot] s'achèvent au bout de la ville (Choulhan Aroukh HaRav 400:1)",
        'id': 'la-ville-comptee-comme-quatre-amot',
        'h3': 'La ville comptée comme quatre amot',
        'meh': "le séif du Mehaber traite du cas où les deux mille s'achèvent à la moitié de la ville : " + Qt('m3', SA) + '.',
        'rav': "après la même règle, le Rav écrit : " + Qt('r3', SAH) + '.',
        'diff': ("le texte du Rav ajoute le cas où les deux mille s'achèvent au bout de la ville : toute la ville compte pour lui comme "
                 "quatre amot ; il renvoie au siman 408. Le séif du Mehaber n'écrit pas ce cas ici."),
        'comm': ("le Magen Avraham, avant le Rav, écrit sur ce passage du Mehaber : " + Qt('ma1', MA('א')) +
                 " — et si sa mesure s'achève au bout de la ville, toute la ville compte comme quatre amot, comme il est écrit au début du "
                 "siman 408. La Michna Beroura, après le Rav : " + Qt('mb5', MB('ה')) +
                 " — mais si les deux mille s'achèvent au bout de la ville, toute la ville ne compte pour lui que comme quatre amot, et il marche "
                 "aussi hors de la ville jusqu'à compléter la mesure de deux mille depuis le lieu de son repos, comme il a été expliqué au siman 408."),
    },
    {
        'rama': True,
        'he_t': 'נקודה ד — אמר בפירוש שביתתי במקומי (שו״ע הרב ת׳:א)',
        't': "Point ד — s'il a dit expressément « mon lieu de repos est à ma place » (Choulhan Aroukh HaRav 400:1)",
        'id': 'la-parole-expresse-au-crepuscule',
        'h3': 'La parole expresse au crépuscule',
        'meh': ("dans sa glose, introduite par הגה à la fin du séif א du Mehaber : " + Qt('rama', RAMA) +
                " — et de même, s'il avait l'intention d'entrer dans la ville et a dit « mon lieu de repos est à ma place », la loi est aussi "
                "ainsi (le Maggid, chapitre 27)."),
        'rav': Qt('r4', SAH) + '.',
        'diff': ("la glose du Rama étend la règle à celui qui avait l'intention d'entrer dans la ville et a dit « mon lieu de repos est à ma "
                 "place », sans écrire à quel moment. Le texte du Rav écrit que l'intention d'entrer était de jour encore (<em>mibe'od yom</em>), "
                 "et que la parole a été dite au crépuscule (<em>bein hachmachot</em>) et expressément (<em>befeirouch</em>) ; et il en écrit "
                 "l'effet : il a déraciné son lieu de repos de [celui des] gens de la ville, et il l'a acquis à sa place."),
        'comm': ("le Beit Yossef, avant le Rav : " + Qt('by4', BY) +
                 " — et le Maggid [Michné] a écrit là, au nom du Raavad et du Rachba, que s'il était éveillé, a prononcé de ses lèvres et a dit "
                 "« que mon lieu de repos soit à ma place », il a déraciné son lieu de repos de [celui des] gens de la ville ; c'est-à-dire : même "
                 "s'il avait l'intention d'aller à cette ville. Le Magen Avraham, avant le Rav, écrit sur la glose du Rama : " + Qt('ma2', MA('ב')) +
                 " — quand il était en chemin, il avait l'intention d'entrer dans la ville, et au crépuscule il a dit « mon lieu de repos est à ma "
                 "place ». La Michna Beroura, après le Rav : " + Qt('mb6', MB('ו')) +
                 " — c'est-à-dire que même dans le premier cas, où il avait l'intention d'entrer, [son intention] ne sert à le rendre comme l'un "
                 "des gens de la ville qu'à la condition précise qu'il n'ait pas énoncé expressément de sa bouche qu'il acquiert son lieu de repos "
                 "à sa place, mais seulement en pensée ; mais s'il l'a dit expressément de sa bouche au crépuscule, « mon lieu de repos est à ma "
                 "place », même si au début, quand il venait en chemin, il avait l'intention d'entrer dans la ville, et que sa parole n'était, elle "
                 "aussi, due qu'au fait qu'il ne savait pas que la ville était proche de lui, il a néanmoins déjà déraciné par là son lieu de repos "
                 "de [celui des] gens de la ville, et il n'a que deux mille [amot] depuis le lieu de son repos."),
    },
]
FR['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · למעשה</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="la-conduite-habad-pratique">La conduite Habad pratique</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      Points de conduite halakhique qui découlent directement du Choulhan Aroukh de l'Admour HaZaken siman ת׳, dans la sensibilité Habad. Chaque point renvoie à son séif du Rav, dans l'ordre du texte.
    </p>

    <div class="lemaaseh-block">
      <h3 id="pour-le-hassid-חסיד-habad-siman-ת">Pour le Hassid (חסיד) Habad — Siman ת׳</h3>
      <ul>'''
FR['s4'] = [
    ("<strong>① Celui qui venait pour entrer dans la ville :</strong> celui qui venait en chemin pour entrer dans la ville, s'est assis en "
     "chemin pour se reposer, sur qui la nuit est tombée sans qu'il sache qu'il était dans la limite de la ville, et qui s'est ensuite trouvé "
     "dans sa limite, a acquis son lieu de repos dans la ville : il y entre le Chabbat, il en parcourt toute [l'étendue] et, au-dehors, deux "
     "mille amot dans chaque direction ; et cela, bien qu'il ait eu l'intention d'acquérir son lieu de repos à sa place (400:1). S'il a dit "
     "expressément au crépuscule « mon lieu de repos est à ma place », voir le point ③. Ce qu'écrit la Michna Beroura, après le Rav, sur ce "
     "cas : section 2, point א. <em>Référence : Choulhan Aroukh de l'Admour HaZaken ת׳:1.</em>"),
    ("<strong>② Celui qui n'avait pas du tout l'intention d'entrer dans cette ville :</strong> il a acquis son lieu de repos à sa place, et de "
     "là il a deux mille amot dans chaque direction ; si les deux mille [amot] depuis le lieu de son repos s'achèvent à la moitié de la ville, "
     "il ne marche pas dans la ville plus que sa moitié ; s'ils s'achèvent au bout de la ville, toute la ville compte pour lui comme quatre "
     "amot ; le Rav renvoie au siman 408 (400:1). <em>Référence : Choulhan Aroukh de l'Admour HaZaken ת׳:1.</em>"),
    ("<strong>③ La parole expresse au crépuscule :</strong> même si, de jour encore, il avait l'intention d'entrer dans cette ville, s'il a "
     "dit expressément au crépuscule « mon lieu de repos est à ma place », il a déraciné son lieu de repos de [celui des] gens de la ville et "
     "a acquis son lieu de repos à sa place (400:1). <em>Référence : Choulhan Aroukh de l'Admour HaZaken ת׳:1.</em>"),
]
FR['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 13px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ Cette section présente la conduite halakhique Habad. Pour toute question concrète : <strong>consulter ton Rav</strong>.
      </p>
    </div>
  </section>
'''

# ============================================================================ HE
HE = {}
HE['title'] = 'סימן ת׳ · רמה 4 — שיטת אדמו״ר הזקן: מי שישב בדרך לנוח ולא ידע אם הוא בתחום | דעת'
HE['desc'] = ('רמה 4 (דעת הרב) של סימן ת׳ — מי שהיה בא בדרך לכנס לעיר וישב לנוח וחשכה לו, ולא ידע שהוא בתחום העיר, ואחר כך מצא עצמו '
              'בתחומה: קנה שביתה בעיר, אף על פי שנתכוון לקנות שביתה במקומו; אם לא היה בדעתו כלל לכנס לעיר זו, או שמבעוד יום היה בדעתו '
              'לכנס ובין השמשות אמר בפירוש שביתתי במקומי, קנה שביתה במקומו. הטקסט המלא של הסעיף היחיד של שולחן ערוך אדמו״ר הזקן, '
              'במה שונה לשון הרב מדברי המחבר והרמ״א, ההנהגה המעשית.')
HE['og'] = ('שיטת אדמו״ר הזקן במי שישב בדרך ולא ידע שהוא בתחום העיר: היכן קנה שביתה לפי דעתו לכנס לעיר, כמה מהלך בעיר, '
            'ואמירה בפירוש בין השמשות שביתתי במקומי.')
HE['tw'] = 'שיטת אדמו״ר הזקן במי שישב בדרך לנוח ולא ידע אם הוא בתחום.'
HE['ld'] = 'רמה 4 (דעת הרב) של סימן ת׳: מי שישב בדרך לנוח ולא ידע אם הוא בתחום, בשולחן ערוך אדמו״ר הזקן.'
HE['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">דעת · רמה 4 — דעת הרב · שיטת אדמו״ר הזקן</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">דעת הרב — שולחן ערוך אדמו״ר הזקן על סימן ת׳</h1>
    <p class="hero-subtitle">מי שישב בדרך לנוח וחשכה לו, ולא ידע אם הוא בתחום העיר: אם היה בא לכנס לעיר — קנה שביתה בעיר, אף על פי שנתכוון לקנות שביתה במקומו; אם לא היה בדעתו כלל לכנס לעיר זו — קנה שביתה במקומו, וכמה מהלך בעיר; ואם מבעוד יום היה בדעתו לכנס לעיר, ובין השמשות אמר בפירוש שביתתי במקומי — אף הוא קנה שביתה במקומו. הסעיף היחיד של שולחן ערוך אדמו״ר הזקן, מושווה לסעיף היחיד של המחבר ולהגהת הרמ״א.</p>
  </div>
</div>
'''
HE['intro'] = '''  <div class="intro-block">
    <p><strong>מדוע רמה 4 מוקדשת לאדמו״ר הזקן?</strong> <strong>שולחן ערוך אדמו״ר הזקן</strong> אינו פירוש על המחבר: זהו שולחן ערוך בפני עצמו, שנכתב על ידי אדמו״ר הזקן, בחלוקה ובמספור סעיפים משלו. כאן יש בשולחן ערוך הרב סעיף אחד, וגם בשולחן ערוך של המחבר סעיף אחד; ההפניות בעמוד זה הולכות לפי מספור הרב, אלא אם כן נזכר בפירוש השולחן ערוך של המחבר.</p>
    <p>עמוד זה מקבץ, לסימן ת׳, את הטקסט המלא של הרב, את מה ששונה בלשונו מדברי המחבר והרמ״א, ואת ההנהגה המעשית העולה מדבריו.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken-he.html" style="color:var(--habad);font-weight:600;">← קרא את ההקדמה הכללית על שיטת אדמו״ר הזקן</a></p>
  </div>
'''
HE['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · טקסט אדמו״ר הזקן</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-ת׳">שלחן ערוך הרב — סימן ת׳</h2>
    <h2 class="section-title-fr" id="הטקסט-המלא-של-שולחן-ערוך-אדמו״ר-הזקן-שולחן-ערוך-הרב">הטקסט המלא של שולחן ערוך אדמו״ר הזקן (שולחן ערוך הרב)</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 16px;">
      <strong>%s</strong><br>
      <em>מקור: מהדורת קה״ת, כפי שמופיע בספריא. סעיף אחד (גם בשולחן ערוך של המחבר סעיף אחד, במספור שלו).</em>
    </p>
''' % CHAP_STRONG
HE['trad_cls'] = None
HE['trads'] = None
HE['s1_source'] = '''    <p style="margin-top: 20px; font-size: 14px; color: var(--text-muted); font-style: italic;">
      מקור: <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.400" target="_blank" style="color: var(--habad);">ספריא — שולחן ערוך הרב, אורח חיים ת׳</a>. בספריא לא מופיעים ערכי קונטרס אחרון לסימן זה.
    </p>'''
HE['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · לשון הרב ולשון המחבר</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="במה-שונה-לשון-הרב-מסעיף-המחבר-והרמ״א">במה שונה לשון הרב מסעיף המחבר והרמ״א</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid);">
      כל נקודה מעמידה זה לצד זה את הסעיף היחיד של שולחן ערוך המחבר, או את הגהת הרמ״א, ואת הסעיף היחיד של שולחן ערוך אדמו״ר הזקן, לפי סדר לשון הרב, ואינה מציינת אלא מה שעולה מהשוואת שני הטקסטים. אין בכך שנקודה מסוימת מיוחדת לרב: הדף מזכיר לפעמים את מקורה; אין הוא מציין את כל המקורות ולא את כל המחלוקות (ראה גם רמה 2).
    </p>'''
HE['points'] = [
    {
        'he_t': FR['points'][0]['he_t'],
        'id': 'קניית-שביתה-בעיר',
        'h3': 'קניית שביתה בעיר',
        'meh': Qt('m1', SA) + '.',
        'rav': Qt('r1', SAH) + '.',
        'diff': ('לשון הרב מביאה את המקרה ואת הדין שבסעיף המחבר, ומוסיפה מה שסעיף זה אינו כותב: שהדין כן אף על פי שנתכוון לקנות '
                 'שביתה במקומו; ואת טעמו: כיון שאילו היה יודע שהעיר בתוך תחומו לא היה חפץ לקנות שביתה אלא עם בני העיר, הרי הוא כאילו '
                 'קנה שביתה עמהם.'),
        'comm': ('המשנה: ' + Qt('mish', MISH) + '. הבית יוסף, שקדם לרב, מפרש כך את דברי רבי יהודה: ' + Qt('by1', BY) +
                 '; וכותב: ' + Qt('by2', BY) + '; ועוד: ' + Qt('by3', BY) + '. המשנה ברורה, אחרי הרב, כותב על סעיף זה: ' +
                 Qt('mb1', MB('א')) + '; ובס״ק ב: ' + Qt('mb2', MB('ב')) +
                 '. את הדבר האחרון (שאם רוצה לישאר במקומו הרשות בידו) כותב המשנה ברורה; סעיף הרב אינו כותב אותו.'),
    },
    {
        'he_t': FR['points'][1]['he_t'],
        'id': 'קניית-שביתה-במקומו',
        'h3': 'קניית שביתה במקומו',
        'meh': Qt('m2', SA) + '.',
        'rav': Qt('r2', SAH) + '.',
        'diff': ('הדין שווה בשני הטקסטים, וכן המקרה שכלים האלפים בחצי העיר. במקום שהמחבר כותב ' + Qt('m2a', SA) + ', הרב כותב ' +
                 Qt('r2a', SAH) + ': הוא מוסיף את המלה כלל, וכותב עיר במקום מדינה.'),
        'comm': ('המשנה ברורה, אחרי הרב, מפרש את מלת המחבר למדינה: ' + Qt('mb3', MB('ג')) + '.'),
    },
    {
        'he_t': FR['points'][2]['he_t'],
        'id': 'כל-העיר-נחשבת-כארבע-אמות',
        'h3': 'כל העיר נחשבת כארבע אמות',
        'meh': 'סעיף המחבר עוסק במקרה שכלים האלפים בחצי העיר: ' + Qt('m3', SA) + '.',
        'rav': 'אחרי אותו דין, כותב הרב: ' + Qt('r3', SAH) + '.',
        'diff': ('לשון הרב מוסיפה את המקרה שכלים האלפים בסוף העיר: כל העיר נחשבת לו כארבע אמות; והיא מפנה לסימן ת״ח. '
                 'סעיף המחבר אינו כותב מקרה זה כאן.'),
        'comm': ('המגן אברהם, שקדם לרב, כותב על מקום זה בדברי המחבר: ' + Qt('ma1', MA('א')) + '. המשנה ברורה, אחרי הרב: ' +
                 Qt('mb5', MB('ה')) + '.'),
    },
    {
        'rama': True,
        'he_t': FR['points'][3]['he_t'],
        'id': 'אמירה-בפירוש-בין-השמשות',
        'h3': 'אמירה בפירוש בין השמשות',
        'meh': 'בהגהתו, הפותחת במלה הגה בסוף סעיף א של המחבר: ' + Qt('rama', RAMA) + '.',
        'rav': Qt('r4', SAH) + '.',
        'diff': ('הגהת הרמ״א מרחיבה את הדין למי שהיה דעתו ליכנס לעיר ואמר שביתתי במקומי, ואינה כותבת באיזה זמן. לשון הרב כותבת '
                 'שדעתו לכנס היתה מבעוד יום, ושהאמירה היתה בין השמשות ובפירוש; וכותבת את תוצאתה: עקר שביתתו מאנשי העיר, וקנה שביתה '
                 'במקומו.'),
        'comm': ('הבית יוסף, שקדם לרב: ' + Qt('by4', BY) + '. המגן אברהם, שקדם לרב, כותב על הגהת הרמ״א: ' + Qt('ma2', MA('ב')) +
                 '. המשנה ברורה, אחרי הרב: ' + Qt('mb6', MB('ו')) + '.'),
    },
]
HE['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · למעשה</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="ההנהגה-המעשית-לחב״ד">ההנהגה המעשית לחב״ד</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      נקודות הנהגה הלכתית הנובעות ישירות משולחן ערוך אדמו״ר הזקן סימן ת׳, ברגישות החב״דית. כל נקודה מפנה לסעיף שלה בשולחן ערוך הרב, לפי סדר הלשון.
    </p>

    <div class="lemaaseh-block">
      <h3 id="לחסיד-חב״ד-סימן-ת׳">לחסיד חב״ד — סימן ת׳</h3>
      <ul>'''
HE['s4'] = [
    ('<strong>① מי שהיה בא לכנס לעיר:</strong> מי שהיה בא בדרך לכנס לעיר וישב בדרך לנוח וחשכה לו, ולא ידע שהוא בתחום העיר, ואחר כך '
     'מצא עצמו בתחומה — קנה שביתה בעיר: נכנס לתוכה בשבת, ומהלך את כולה וחוצה לה אלפים אמה לכל רוח; ואף על פי שנתכוון לקנות שביתה '
     'במקומו (שו״ע הרב ת׳:א). אם אמר בפירוש בין השמשות שביתתי במקומי — ראה נקודה ③. מה שכותב המשנה ברורה, אחרי הרב, במקרה זה: פרק 2, '
     'נקודה א. <em>הפניה: שולחן ערוך אדמו״ר הזקן ת׳:א.</em>'),
    ('<strong>② מי שלא היה בדעתו כלל לכנס לעיר זו:</strong> קנה שביתה במקומו, ומשם יש לו אלפים אמה לכל רוח; ואם כלים אלפים ממקום '
     'שביתתו בחצי העיר — אינו מהלך בעיר יותר מחציה; ואם כלים בסוף העיר — כל העיר נחשבת לו כארבע אמות; הרב מפנה לסימן ת״ח (שו״ע הרב '
     'ת׳:א). <em>הפניה: שולחן ערוך אדמו״ר הזקן ת׳:א.</em>'),
    ('<strong>③ אמירה בפירוש בין השמשות:</strong> אפילו אם מבעוד יום היה בדעתו לכנס לעיר זו, ובין השמשות אמר בפירוש שביתתי במקומי — '
     'הרי עקר שביתתו מאנשי העיר וקנה שביתה במקומו (שו״ע הרב ת׳:א). <em>הפניה: שולחן ערוך אדמו״ר הזקן ת׳:א.</em>'),
]
HE['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 14px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ סעיף זה מציג את ההנהגה ההלכתית של חב״ד. לכל שאלה ממשית: <strong>להיוועץ ברב שלך</strong>.
      </p>
    </div>
  </section>
'''

# ============================================================================ EN
EN = {}
EN['title'] = 'Siman ת׳ · Level 4 — Shitah of the Alter Rebbe: one who sat on the road to rest, not knowing whether he was within the techum | Hilchos Techumin'
EN['desc'] = ("Level 4 (Daat HaRav) of Siman ת׳ — one who was coming on the road to enter a city, sat down to rest, night fell on him, and he "
              "did not know that he was within the techum of the city, then found himself within it: he acquires his place of rest (shevisah) "
              "in the city, although he intended to acquire it where he was; if he had no intention at all of entering this city, or if, having "
              "intended by day to enter it, he said explicitly at twilight “my place of rest is where I am”, he acquires it where he is. The full "
              "text of the single seif of the Shulchan Aruch HaRav, its translation, where the Rav's text differs from the Mechaber's and the "
              "Rema's, and the practical conduct.")
EN['og'] = ("The shitah of the Alter Rebbe on one who sat on the road not knowing that he was within the techum of the city: where he "
            "acquires his place of rest according to his intention to enter the city, how much of the city he may walk, and the explicit "
            "statement at twilight “my place of rest is where I am”.")
EN['tw'] = 'Shitah of the Alter Rebbe on one who sat on the road to rest, not knowing whether he was within the techum.'
EN['ld'] = ('Level 4 (Daat HaRav) of Siman ת׳: one who sat on the road to rest, not knowing whether he was within the techum, in the '
            'Shulchan Aruch HaRav.')
EN['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">DAAT · LEVEL 4 — DAAT HARAV · Shitah of the Alter Rebbe</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">Daat HaRav — The Shulchan Aruch HaRav on Siman 400</h1>
    <p class="hero-subtitle">One who sat on the road to rest, on whom night fell, and who did not know whether he was within the <em>techum</em> of the city: if he was coming to enter the city, he acquires his place of rest (<em>shevisah</em>) in the city, although he intended to acquire it where he was; if he had no intention at all of entering this city, he acquires it where he is, with how much of the city he may then walk; and if, while it was still day, he intended to enter the city but said explicitly at twilight “my place of rest is where I am”, he too acquires it where he is. The single seif of the Shulchan Aruch HaRav, compared with the Mechaber's single seif and the Rema's gloss.</p>
  </div>
</div>
'''
EN['intro'] = '''  <div class="intro-block">
    <p><strong>Why a Level 4 dedicated to the Alter Rebbe?</strong> The <strong>Shulchan Aruch HaRav</strong> is not a commentary on the Mechaber: it is a Shulchan Aruch in its own right, written by the Alter Rebbe, with its own division and its own numbering of the seifim. Here the Shulchan Aruch HaRav has one seif, and the Mechaber's Shulchan Aruch has one seif too; the references on this page follow the Rav's numbering, except where the Mechaber's Shulchan Aruch is named.</p>
    <p>This page gathers, for Siman 400, the full text of the Rav with its translation, where his text differs from the Mechaber's and the Rema's, and the practical conduct that follows from it.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken-en.html" style="color:var(--habad);font-weight:600;">→ Read the general preface on the shitah of the Alter Rebbe</a></p>
  </div>
'''
EN['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · Text of the Alter Rebbe</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-ת׳">שלחן ערוך הרב — סימן ת׳</h2>
    <h2 class="section-title-fr" id="the-full-text-of-the-shulchan-aruch-harav-of-the-alter-rebbe">The full text of the Shulchan Aruch HaRav of the Alter Rebbe</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 15px;">
      <strong>%s</strong><br>
      <em>Source: Kehot edition, as reproduced on Sefaria. 1 seif (the Mechaber's Shulchan Aruch has 1 too, under its own numbering).</em>
    </p>
''' % CHAP_STRONG
EN['trad_cls'] = 'sa-en'
EN['trads'] = [
    "One who sat on the road to rest and did not know whether he was within the <em>techum</em> or not; it contains one seif:<br><br>"
    "One who was coming on the road to enter the city, sat down on the road to rest, and night fell on him, and he did not know that he was within the <em>techum</em> of the city, and afterwards found himself [to be] within its <em>techum</em> — he has acquired his place of rest (<em>kanah shevisah</em>) in the city: he enters it on Shabbos, and he walks all of it and, outside it, two thousand <em>amos</em> in every direction. And although he intended to acquire his place of rest where he was, since, had he known that the city was within his <em>techum</em>, he would have wanted to acquire his place of rest only with the people of the city — he is as though he acquired his place of rest with them. <br><br>"
    "But if he had no intention at all of entering this city, he has acquired his place of rest where he is, and from there he has two thousand <em>amos</em> in every direction. And if the two thousand [<em>amos</em>] from the place of his rest end halfway through the city, he does not walk in the city more than half of it. And if they end at the far end of the city, the whole city is reckoned for him as four <em>amos</em>, as will be explained in Siman 408.<br><br>"
    "And even if, while it was still day (<em>mibe'od yom</em>), he intended to enter this city, and at twilight (<em>bein hashmashos</em>) he said explicitly “my place of rest is where I am” (<em>shevisasi bimkomi</em>) — he has uprooted his place of rest from [that of] the people of the city, and he has acquired his place of rest where he is:"
]
EN['s1_source'] = '''    <p style="margin-top: 20px; font-size: 13px; color: var(--text-muted); font-style: italic;">
      Source: <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.400" target="_blank" style="color: var(--habad);">Sefaria — Shulchan Arukh HaRav, Orach Chayim 400</a>. Sefaria gives no Kuntres Acharon entry for this siman.
    </p>'''
EN['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · The Rav's text and the Mechaber's</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="where-the-rav-s-text-differs-from-the-mechaber-s-seif-and-the-rema-s">Where the Rav's text differs from the Mechaber's seif and the Rema's</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid);">
      Each point sets side by side the single seif of the Mechaber's Shulchan Aruch, or the Rema's gloss, and the single seif of the Shulchan Aruch HaRav, in the order of the Rav's text, and notes only what the comparison of the two texts shows. A point noted is not thereby unique to the Rav: the page sometimes names its source; it notes neither all the sources nor all the divergences (see also Level 2).
    </p>'''
EN['points'] = [
    {
        'he_t': FR['points'][0]['he_t'],
        't': "Point א — one who was coming to enter the city without knowing that he was within its techum (Shulchan Aruch HaRav 400:1)",
        'id': 'the-place-of-rest-acquired-in-the-city',
        'h3': 'The place of rest acquired in the city',
        'meh': Qt('m1', SA) + '.',
        'rav': Qt('r1', SAH) + '.',
        'diff': ("the Rav's text repeats the case and the ruling of the Mechaber's seif, and adds what this seif does not write: "
                 "the ruling holds although he intended to acquire his place of rest where he was; and its reason: since, had he known that "
                 "the city was within his <em>techum</em>, he would have wanted to acquire his place of rest only with the people of the city, "
                 "he is as though he acquired it with them."),
        'comm': ("the Mishnah: " + Qt('mish', MISH) + " — one who sat on the road, stood up, and saw that he was near the city: since that "
                 "was not his intention, he does not enter — the words of Rabbi Meir; Rabbi Yehudah says: he enters; Rabbi Yehudah said: it "
                 "once happened, and Rabbi Tarfon entered without intending to. The Beis Yosef, before the Rav, explains Rabbi Yehudah's words "
                 "thus: " + Qt('by1', BY) + " — although he did not know that the city was within his <em>techum</em>, and he intended to rest "
                 "where he was, as [the Mishnah] teaches, “that was not his intention”, since, had he known that the city was within his "
                 "<em>techum</em>, he would have acquired his place of rest only with the people of the city, he is like one who acquired his "
                 "place of rest with them; then he writes: " + Qt('by2', BY) + " — it is known that the halachah follows Rabbi Yehudah; and: " +
                 Qt('by3', BY) + " — from the words of the Rambam and the Maggid Mishneh in chapter 26 it appears that the case here is where "
                 "he intended to go to this city, and therefore he acquired his place of rest with the people of the city, like them, since he "
                 "entered the <em>techum</em> with them. The Mishnah Berurah, after the Rav, writes on this seif: " + Qt('mb1', MB('א')) +
                 " — and even if he intended to acquire his place of rest in this place; and: " + Qt('mb2', MB('ב')) +
                 " — since from the outset he intended to enter the city, and had he known that the city was within his <em>techum</em> he "
                 "would have wanted to acquire his place of rest only with the people of the city; therefore now too he is like one of the "
                 "people of the city, to walk all of it and to have two thousand [<em>amos</em>] in every direction. Nevertheless there is "
                 "also a stringency in this: he loses on this account at the place where he sat: he does not have the measure of two "
                 "thousand from there, since he is counted as one of the people of the city; and it seems simple that all this is when he now "
                 "wants to go to the city, and it was for his benefit that they were lenient with him; but if he wants to remain at the place "
                 "where he acquired his place of rest, he may. This last point (the choice to remain), the Mishnah Berurah writes; the Rav's "
                 "seif does not write it."),
    },
    {
        'he_t': FR['points'][1]['he_t'],
        't': "Point ב — if he had no intention at all of entering this city (Shulchan Aruch HaRav 400:1)",
        'id': 'the-place-of-rest-acquired-where-he-is',
        'h3': 'The place of rest acquired where he is',
        'meh': Qt('m2', SA) + '.',
        'rav': Qt('r2', SAH) + '.',
        'diff': ("the ruling is the same in both texts, including the case where the two thousand end halfway through the city. Where the "
                 "Mechaber writes " + Qt('m2a', SA) + ", the Rav writes " + Qt('r2a', SAH) +
                 ": he adds <em>klal</em> (“at all”) and writes <em>ir</em> (“city”) where the Mechaber writes <em>medinah</em>."),
        'comm': ("the Mishnah Berurah, after the Rav, explains the Mechaber's word <em>lamedinah</em>: " + Qt('mb3', MB('ג')) +
                 " — that is, a city."),
    },
    {
        'he_t': FR['points'][2]['he_t'],
        't': "Point ג — if [the two thousand amos] end at the far end of the city (Shulchan Aruch HaRav 400:1)",
        'id': 'the-city-reckoned-as-four-amos',
        'h3': 'The city reckoned as four amos',
        'meh': "the Mechaber's seif deals with the case where the two thousand end halfway through the city: " + Qt('m3', SA) + '.',
        'rav': "after the same ruling, the Rav writes: " + Qt('r3', SAH) + '.',
        'diff': ("the Rav's text adds the case where the two thousand end at the far end of the city: the whole city is reckoned for him as "
                 "four <em>amos</em>; it refers to Siman 408. The Mechaber's seif does not write this case here."),
        'comm': ("the Magen Avraham, before the Rav, writes on this passage of the Mechaber: " + Qt('ma1', MA('א')) +
                 " — and if his measure ends at the far end of the city, the whole city is reckoned as four <em>amos</em>, as is written at "
                 "the beginning of Siman 408. The Mishnah Berurah, after the Rav: " + Qt('mb5', MB('ה')) +
                 " — but if the two thousand end at the far end of the city, the whole city is reckoned for him only as four <em>amos</em>, "
                 "and he walks outside the city too, until completing the measure of two thousand from the place of his rest, as was "
                 "explained in Siman 408."),
    },
    {
        'rama': True,
        'he_t': FR['points'][3]['he_t'],
        't': "Point ד — if he said explicitly “my place of rest is where I am” (Shulchan Aruch HaRav 400:1)",
        'id': 'the-explicit-statement-at-twilight',
        'h3': 'The explicit statement at twilight',
        'meh': ("in his gloss, introduced by הגה at the end of the Mechaber's seif א: " + Qt('rama', RAMA) +
                " — and likewise, if he intended to enter the city and said “my place of rest is where I am”, the law is also so (the "
                "Maggid, chapter 27)."),
        'rav': Qt('r4', SAH) + '.',
        'diff': ("the Rema's gloss extends the ruling to one who intended to enter the city and said “my place of rest is where I am”, "
                 "without writing at what time. The Rav's text writes that the intention to enter was while it was still day "
                 "(<em>mibe'od yom</em>), and that the statement was made at twilight (<em>bein hashmashos</em>) and explicitly "
                 "(<em>befeirush</em>); and it writes its effect: he has uprooted his place of rest from [that of] the people of the city, "
                 "and he has acquired it where he is."),
        'comm': ("the Beis Yosef, before the Rav: " + Qt('by4', BY) +
                 " — and the Maggid [Mishneh] wrote there, in the name of the Raavad and the Rashba, that if he was awake, uttered with his "
                 "lips and said “let my place of rest be where I am”, he has uprooted his place of rest from [that of] the people of the city; "
                 "that is to say, even if he intended to go to this city. The Magen Avraham, before the Rav, writes on the Rema's gloss: " +
                 Qt('ma2', MA('ב')) + " — when he was on the road he intended to enter the city, and at twilight he said “my place of rest is "
                 "where I am”. The Mishnah Berurah, after the Rav: " + Qt('mb6', MB('ו')) +
                 " — that is, even in the first case, where he intended to enter, [his intention] helps to make him like one of the people of "
                 "the city only on the precise condition that he did not state explicitly with his mouth that he acquires his place of rest "
                 "where he is, but only in thought; but if he said so explicitly with his mouth at twilight, “my place of rest is where I am”, "
                 "even though at first, when he was coming on the road, he intended to enter the city, and his statement now too was only "
                 "because he did not know that the city was near him, he has nevertheless already uprooted thereby his place of rest from "
                 "[that of] the people of the city, and he has only two thousand [<em>amos</em>] from the place of his rest."),
    },
]
EN['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · Lemaaseh</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="the-practical-chabad-conduct">The practical Chabad conduct</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      Points of halachic conduct that flow directly from the Shulchan Aruch HaRav Siman 400, in the Chabad sensibility. Each point refers to its seif of the Rav, in the order of the text.
    </p>

    <div class="lemaaseh-block">
      <h3 id="for-the-chabad-chassid-siman-400">For the Chabad Chassid — Siman 400</h3>
      <ul>'''
EN['s4'] = [
    ("<strong>① One who was coming to enter the city:</strong> one who was coming on the road to enter the city, sat down on the road to "
     "rest, on whom night fell without his knowing that he was within the <em>techum</em> of the city, and who afterwards found himself "
     "within its <em>techum</em>, has acquired his place of rest in the city: he enters it on Shabbos, and he walks all of it and, outside "
     "it, two thousand <em>amos</em> in every direction; and this although he intended to acquire his place of rest where he was (400:1). "
     "If he said explicitly at twilight “my place of rest is where I am”, see point ③. What the Mishnah Berurah, after the Rav, writes on "
     "this case: section 2, point א. <em>Reference: Shulchan Aruch HaRav 400:1.</em>"),
    ("<strong>② One who had no intention at all of entering this city:</strong> he has acquired his place of rest where he is, and from "
     "there he has two thousand <em>amos</em> in every direction; if the two thousand [<em>amos</em>] from the place of his rest end halfway "
     "through the city, he does not walk in the city more than half of it; if they end at the far end of the city, the whole city is "
     "reckoned for him as four <em>amos</em>; the Rav refers to Siman 408 (400:1). <em>Reference: Shulchan Aruch HaRav 400:1.</em>"),
    ("<strong>③ The explicit statement at twilight:</strong> even if, while it was still day, he intended to enter this city, if at "
     "twilight he said explicitly “my place of rest is where I am”, he has uprooted his place of rest from [that of] the people of the "
     "city and has acquired his place of rest where he is (400:1). <em>Reference: Shulchan Aruch HaRav 400:1.</em>"),
]
EN['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 13px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ This section presents the Chabad halachic conduct. For any concrete question: <strong>consult your Rav</strong>.
      </p>
    </div>
  </section>
'''

CONTENU = {'fr': FR, 'he': HE, 'en': EN}
