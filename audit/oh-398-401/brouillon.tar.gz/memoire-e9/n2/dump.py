import importlib.util, sys, pathlib
WT = pathlib.Path('/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9')
spec = importlib.util.spec_from_file_location('se', WT / 'scripts' / 'sefaria-extrait.py')
se = importlib.util.module_from_spec(spec); spec.loader.exec_module(se)
w, s = sys.argv[1], sys.argv[2]
r = se.segments(w, s)
segs = r[2]
print('# ', r[0], r[1], len(segs))
for i, t in enumerate(segs, 1):
    print('[%d] %s' % (i, se.nettoyer(t)))
