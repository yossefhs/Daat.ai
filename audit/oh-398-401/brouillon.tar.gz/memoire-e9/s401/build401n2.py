#!/usr/bin/env python3
"""Assemble niveau-2-lamdan{,-he,-en}.html du siman 401 : charpente de 397 (publié) + corps rédigé.

Aucun mot d'hébreu cité n'est retapé : les marqueurs [[…]] du corps sont remplacés par
l'extraction de Sefaria (scripts/sefaria-extrait.py, importé).
  [[t:W:K]]            texte nettoyé du segment K (blockquote ; balises b/br/small gardées)
  [[q:W:K:frag]]       sous-chaîne exacte (squelette), balises retirées, ' -> ׳ après une lettre
  [[qd:W:K:debut|fin]] de debut à fin, même rendu que q
  W = SA, MB, BH, SAH… (siman 401) ou W@SIMAN ou REF@Ref.Sefaria (K = 0 : tout)
"""
import importlib.util, re, sys, pathlib

WT = pathlib.Path('/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9')
ICI = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('se', WT / 'scripts' / 'sefaria-extrait.py')
se = importlib.util.module_from_spec(spec); spec.loader.exec_module(se)

_cache = {}
def texte(w, k):
    if '@' in w:
        w, s = w.split('@', 1)
    else:
        s = '401'
    cle = (w, s)
    if cle not in _cache:
        _cache[cle] = se.segments(w, s)[2]
    segs = _cache[cle]
    if k == 0:
        return se.nettoyer(' '.join(segs))
    if not 1 <= k <= len(segs):
        raise SystemExit('hors limites : %s %s %d' % (w, s, k))
    return se.nettoyer(segs[k - 1])

def unique(occ, quoi, w, k):
    if len(occ) != 1:
        raise SystemExit('%s : %d occurrence(s) de « %s » dans %s:%d' % ('INTROUVABLE' if not occ else 'AMBIGU', len(occ), quoi, w, k))
    return occ[0]

def fin_apostrophe(t, f):
    while f < len(t) and t[f] in "'":
        f += 1
    return f

def bords(t, s, f, debut_frag, fin_frag):
    """Inclut la ponctuation de bord demandée par le fragment (« ( » en tête, « ) » en fin)."""
    tete = re.match(r'^[^א-ת]*', debut_frag).group(0).strip()
    if tete:
        avant = t[:s].rstrip()
        if not avant.endswith(tete):
            raise SystemExit('bord de tête %r absent avant « %s »' % (tete, debut_frag))
        s = len(avant) - len(tete)
    queue = re.search(r'[^א-ת׳״\']*$', fin_frag).group(0).strip()
    if queue:
        apres = t[f:]
        k = len(apres) - len(apres.lstrip())
        if not apres.lstrip().startswith(queue):
            raise SystemExit('bord de fin %r absent après « %s »' % (queue, fin_frag))
        f = f + k + len(queue)
    return s, f

def rendu_q(s):
    s = re.sub(r'<[^>]+>', ' ', s)
    s = re.sub(r"(?<=[א-ת])'", '׳', s)
    s = re.sub(r'\s+', ' ', s).strip()
    s = re.sub(r'\(\s+', '(', s); s = re.sub(r'\s+\)', ')', s)
    return s

def remplacer(m):
    kind, w, k, arg = m.group(1), m.group(2), int(m.group(3)), m.group(4)
    t = texte(w, k)
    if kind == 't':
        return t
    if kind == 'q':
        s, f = unique(se.trouver(t, arg), arg, w, k)
        deb, fin = arg, arg
    else:
        deb, fin = arg.split('|')
        s, _ = unique(se.trouver(t, deb), deb, w, k)
        fins = [ff for (ss, ff) in se.trouver(t, fin) if ss >= s]
        if len(fins) != 1:
            raise SystemExit('fin « %s » : %d occurrence(s) après le début dans %s:%d' % (fin, len(fins), w, k))
        f = fins[0]
    f = fin_apostrophe(t, f)
    s, f = bords(t, s, f, deb, fin)
    return rendu_q(t[s:f])

MARQ = re.compile(r'\[\[(t|q|qd):([A-Za-z]+(?:@[^:\]]+)?):(\d+)(?::(.*?))?\]\]')

def corps(chemin):
    src = chemin.read_text(encoding='utf-8')
    out = MARQ.sub(remplacer, src)
    if '[[' in out or ']]' in out:
        raise SystemExit('marqueur non résolu dans %s' % chemin)
    return out


def tete_et_queue(modele):
    t = modele.read_text(encoding='utf-8')
    i = t.index('<main>')
    j = t.index('<div class="yh-watermark">')
    return t[:i], t[j:]

def remplace_meta(tete, champs):
    for motif, valeur in champs:
        n = len(re.findall(motif, tete))
        if n != 1:
            raise SystemExit('motif %r : %d' % (motif, n))
        tete = re.sub(motif, lambda m: valeur, tete)
    return tete

def construire(suf, champs, nav):
    mod = WT / 'sources/shabbat/siman-397' / ('niveau-2-lamdan%s.html' % suf)
    tete, queue = tete_et_queue(mod)
    tete = remplace_meta(tete, champs)
    tete = tete.replace('/oh/397/', '/oh/401/').replace('siman-397.png', 'siman-401.png')
    tete = tete.replace('"Siman 397"', '"Siman 401"').replace('סימן שצ״ז · 397', 'סימן ת״א · 401')
    queue = queue.replace('/oh/397/', '/oh/401/').replace('/oh/396/', '/oh/400/')
    for a, b in nav:
        if a not in queue:
            raise SystemExit('queue : %r absent' % a)
        queue = queue.replace(a, b)
    page = tete + corps(ICI / ('n2-corps%s.html' % (suf or '-fr'))) + queue
    for ln, l in enumerate(page.split('\n'), 1):
        if re.search(r'39[6-9]|40[02-9]|שצ״[זוחט]|ת׳', l):
            print('  [voisin] %s l.%d : %s' % (suf or 'fr', ln, l.strip()[:150]), file=sys.stderr)
    out = WT / 'sources/shabbat/siman-401' / ('niveau-2-lamdan%s.html' % suf)
    out.write_text(page, encoding='utf-8')
    print('écrit', out, len(page))

if __name__ == '__main__':
    import json
    cfg = json.loads((ICI / 'n2-meta.json').read_text(encoding='utf-8'))
    for suf in [x if x != 'fr' else '' for x in (sys.argv[1:] or ['fr', '-he', '-en'])]:
        c = cfg[suf or 'fr']
        construire(suf, [(m, v) for m, v in c['champs']], [tuple(x) for x in c['nav']])
