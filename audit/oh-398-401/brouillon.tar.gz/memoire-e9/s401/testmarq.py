import sys, importlib.util, pathlib
ICI = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('b', ICI / 'build401n2.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
for m in sys.argv[1:]:
    try:
        print('OK ', b.MARQ.sub(b.remplacer, m))
    except SystemExit as e:
        print('ERR', m, '->', e)
