#!/usr/bin/env python3
"""Écrit n3-meta.json du siman 401 (chapeau du Mehaber extrait de Sefaria, jamais retapé)."""
import importlib.util, json, re, pathlib
WT = pathlib.Path('/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9')
spec = importlib.util.spec_from_file_location('se', WT / 'scripts' / 'sefaria-extrait.py')
se = importlib.util.module_from_spec(spec); spec.loader.exec_module(se)
t = se.nettoyer(se.segments('SA', '401')[2][0])
(a, b), = se.trouver(t, 'מי שישן בדרך וחשכה לו קונה אלפים אמה לכל רוח')
CHAP = re.sub(r'<[^>]+>', '', t[a:b]).strip()
DESC_JSONLD = r'"description": "(?:Niveau 3 \(Synthèse\) du Siman|רמה 3 \(סיכום\) של סימן|Level 3 \(Synthesis\) of Siman) שצ״ז[^"]*"'
def champs(title, desc, ogt, ogd, twt, twd, head, jd):
    return [["<title>[^<]*</title>", "<title>%s</title>" % title],
            ['<meta name="description" content="[^"]*">', '<meta name="description" content="%s">' % desc],
            ['<meta property="og:title" content="[^"]*">', '<meta property="og:title" content="%s">' % ogt],
            ['<meta property="og:description" content="[^"]*">', '<meta property="og:description" content="%s">' % ogd],
            ['<meta name="twitter:title" content="[^"]*">', '<meta name="twitter:title" content="%s">' % twt],
            ['<meta name="twitter:description" content="[^"]*">', '<meta name="twitter:description" content="%s">' % twd],
            ['"headline": "[^"]*"', '"headline": "%s"' % head],
            [DESC_JSONLD, '"description": "%s"' % jd]]
FR_S = "Celui qui dormait en chemin à la tombée de la nuit, et la chevita des objets"
EN_S = "One who was asleep on the way when night fell, and the shevisah of objects"
cfg = {
 'fr': {'champs': champs(
    "Siman ת״א · Niveau 3 Synthèse Magistrale — %s | Hilkhot Te'houmin" % FR_S,
    "Niveau 3 (Synthèse) du Siman ת״א — celui qui dormait en chemin à la tombée de la nuit, les objets sans propriétaire, les objets d'un non-Juif, la ville entourée pour l'habitation et la glose du Rama sur les objets prêtés à un non-Juif : axiome, déroulement du séif, arbre de décision, le Mehaber, le Rama et le Choulhan Aroukh HaRav, mnémonique, pièges et commandements pratiques ; les cas où les avis divergent renvoient au niveau 2.",
    "Siman ת״א · Niveau 3 Synthèse Magistrale — %s" % FR_S,
    "Récapitulatif structuré du siman 401 — celui qui dort en chemin acquiert la chevita à sa place ; les objets sans propriétaire, ceux d'un non-Juif, la ville entourée pour l'habitation, les objets prêtés à un non-Juif ; et des cas où les avis divergent (niveau 2) —, pour la révision.",
    "Siman ת״א · Niveau 3 Synthèse Magistrale — %s" % FR_S,
    "Récapitulatif structuré : celui qui dormait en chemin à la tombée de la nuit, et la chevita des objets.",
    "Siman ת״א · Niveau 3 Synthèse Magistrale — %s | Hilkhot Te'houmin" % FR_S,
    "Niveau 3 (Synthèse) du Siman ת״א — %s" % FR_S[0].lower() + FR_S[1:] if False else "Niveau 3 (Synthèse) du Siman ת״א — celui qui dormait en chemin à la tombée de la nuit, et la chevita des objets"),
   'nav': [["<em>סימן שצ״ז · Niveau 3", "<em>סימן ת״א · Niveau 3"], ["← Siman 396", "← Siman 400"]]},
 '-he': {'champs': champs(
    "סימן ת״א · רמה 3 סיכום מגיסטרלי — %s | דעת" % CHAP,
    "רמה 3 (סיכום) של סימן ת״א — מי שישן בדרך וחשכה לו, חפצי הפקר, חפצי עכו״ם, העיר המוקפת לדירה, והגהת הרמ״א בכלים שהשאיל ישראל לעכו״ם: אקסיומה, מהלך הסעיף, עץ החלטה, המחבר, הרמ״א ושולחן ערוך הרב, סימן זכרון, מלכודות והוראות מעשיות; במקרים שהדעות חלוקות בהם — ראה רמה 2.",
    "סימן ת״א · רמה 3 סיכום מגיסטרלי — %s" % CHAP,
    "סיכום מובנה של סימן ת״א — מי שישן בדרך קנה שביתה במקומו; חפצי הפקר, חפצי עכו״ם, העיר המוקפת לדירה, וכלים שהשאיל ישראל לעכו״ם; ומקרים שהדעות חלוקות בהם (רמה 2) —, לחזרה.",
    "סימן ת״א · רמה 3 סיכום מגיסטרלי — %s" % CHAP,
    "סיכום מובנה: מי שישן בדרך וחשכה לו, ושביתת החפצים.",
    "סימן ת״א · רמה 3 סיכום מגיסטרלי — %s | דעת" % CHAP,
    "רמה 3 (סיכום) של סימן ת״א — מי שישן בדרך וחשכה לו, ושביתת החפצים"),
   'nav': [["<em>סימן שצ״ז · רמה 3", "<em>סימן ת״א · רמה 3"], ["סימן שצ״ו · 396 →", "סימן ת׳ · 400 →"]]},
 '-en': {'champs': champs(
    "Siman ת״א · Level 3 Magisterial Synthesis — %s | Hilchos Techumin" % EN_S,
    "Level 3 (Synthesis) of Siman ת״א — one who was asleep on the way when night fell, ownerless objects, the objects of a non-Jew, the city enclosed for dwelling and the Rema's gloss on objects lent to a non-Jew: axiom, course of the seif, decision tree, the Mechaber, the Rema and the Shulchan Aruch HaRav, mnemonic, pitfalls and practical commandments; the cases on which the opinions differ refer to Level 2.",
    "Siman ת״א · Level 3 Magisterial Synthesis — %s" % EN_S,
    "Structured recap of siman 401 — one who is asleep on the way acquires his shevisah in his place; ownerless objects, those of a non-Jew, the city enclosed for dwelling, objects lent to a non-Jew; and cases on which the opinions differ (Level 2) —, for review.",
    "Siman ת״א · Level 3 Magisterial Synthesis — %s" % EN_S,
    "Structured recap: one who was asleep on the way when night fell, and the shevisah of objects.",
    "Siman ת״א · Level 3 Magisterial Synthesis — %s | Hilchos Techumin" % EN_S,
    "Level 3 (Synthesis) of Siman ת״א — one who was asleep on the way when night fell, and the shevisah of objects"),
   'nav': [["<em>סימן שצ״ז · Level 3", "<em>סימן ת״א · Level 3"], ["← Siman 396", "← Siman 400"]]},
}
for l in cfg.values():
    for _, v in l['champs']:
        if re.search(r'content="[^"]*"[^>]*"', v):
            raise SystemExit('guillemet ASCII : %s' % v[:80])
(pathlib.Path(__file__).resolve().parent / 'n3-meta.json').write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding='utf-8')
print('n3-meta.json écrit ; chapeau :', CHAP)
