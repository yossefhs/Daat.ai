#!/usr/bin/env python3
"""Assemble le niveau 4 du siman 401 (FR, HE, EN).

Charpente (head, header, fil d'Ariane, section 3, navigation, pied) : siman-397 (publié,
Hilkhot Te'houmin ; CSS de 365 à l'octet). Formes des sections 1, 2 et 4 : 400 / 397.
Tout l'hébreu de source est EXTRAIT par scripts/sefaria-extrait.py (q401n4.py) ; rien
n'est retapé. Le contenu rédigé est dans contenu401n4.py.
"""
import os, re, sys

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import q401n4  # noqa: E402

WT = q401n4.WT
SRC = os.path.join(WT, 'sources', 'shabbat', 'siman-397')
DST = os.path.join(WT, 'sources', 'shabbat', 'siman-401')
N = 401

Q = q401n4.charger()


def q(s):
    def rep(m):
        return Q[m.group(1)]
    out = re.sub(r'\[\[(\w+)\]\]', rep, s)
    assert '[[' not in out, out
    return out


# ---------------------------------------------------------------- section 1 : le texte du Rav
SEIFS = []
for k in range(1, 3):
    t = q401n4.seif('SAH', k)
    t = t.replace('<b>', '').replace('</b>', '')
    t = t.replace('<br>', '<br><br>')
    SEIFS.append(t)
PREV_N = [20, 10]
LETTRES = ['א', 'ב']


def apercu(t, n):
    plain = re.sub(r'<[^>]+>', ' ', t)
    mots = plain.split()
    pris = mots[:n]
    pris[-1] = pris[-1].rstrip(',;:.—')
    return ' '.join(pris) + '…'


PREVIEWS = [apercu(SEIFS[i], PREV_N[i]) for i in range(len(SEIFS))]
CHAPEAU = SEIFS[0].split(':<br>')[0]
CHAP_SANS_COMPTE = CHAPEAU.rsplit(' וּבוֹ ', 1)[0]
COMPTE = 'וּבוֹ ' + CHAPEAU.rsplit(' וּבוֹ ', 1)[1]

exec(open(os.path.join(ICI, 'contenu401n4.py'), encoding='utf-8').read())


def bloc(i, trad_cls, trad):
    ouvert = ' open' if i == 0 else ''
    s = ('    <details class="seif-details"%s>\n'
         '      <summary class="seif-summary">\n'
         '        <span class="seif-num">סעיף %s</span>\n'
         '        <span class="seif-preview">%s</span>\n'
         '      </summary>\n'
         '      <div class="sa-block">\n'
         '        <p class="sa-he">%s</p>\n') % (ouvert, LETTRES[i], PREVIEWS[i], SEIFS[i])
    if trad_cls:
        s += '        <p class="%s">%s</p>\n' % (trad_cls, trad)
    s += '      </div>\n    </details>\n'
    return s


def points(lang, pts):
    out = []
    h3font = "'Frank Ruhl Libre', serif" if lang == 'he' else "'Cormorant Garamond', serif"
    lab = LABELS[lang]
    for p in pts:
        s = '    <div class="sa-block">\n'
        s += '      <p class="sa-he" style="font-size: 19px; font-weight: 700; margin-bottom: 12px; color: var(--habad-deep);">%s</p>\n' % p['he_t']
        if lang != 'he':
            s += '      <p class="sa-%s">%s</p>\n' % (lang, p['t'])
        s += ('      <h3 style="font-family: %s; font-size: 19px; font-weight: 600; color: var(--navy); margin-bottom: 10px;" id="%s">%s</h3>\n'
              % (h3font, p['id'], p['h3']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['rama' if p.get('rama') else 'meh'], q(p['meh']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['rav'], q(p['rav']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['diff'], q(p['diff']))
        if p.get('comm'):
            s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['comm'], q(p['comm']))
        s += '    </div>\n'
        out.append(s)
    return ''.join(out)


def construire(lang):
    suf = {'fr': '', 'he': '-he', 'en': '-en'}[lang]
    C = CONTENU[lang]
    T = open(os.path.join(SRC, 'niveau-4-daat-harav%s.html' % suf), encoding='utf-8').read()
    i_hero = T.index('<div class="page-hero">')
    m3 = re.search(r'\n  <!-- 3\. ', T)
    i_s3 = m3.start() + 1
    i_s4 = T.index('    <!-- 4. LEMAASEH')
    i_nav = T.index('<nav class="niveau-nav"')
    A, B, Cc = T[:i_hero], T[i_s3:i_s4], T[i_nav:]

    def fix(x):
        x = x.replace('/oh/397/', '/oh/401/').replace('/oh/396/', '/oh/400/')
        x = x.replace('siman-397', 'siman-401')
        x = x.replace('Siman 397', 'Siman 401').replace('Siman 396', 'Siman 400')
        x = x.replace('סימן שצ״ו · 396', 'סימן ת׳ · 400')
        x = x.replace('סימן שצ״ז · 397', 'סימן ת״א · 401')
        x = x.replace('שצ״ז', 'ת״א').replace('שצ-ז', 'ת-א')
        return x

    A = fix(A)
    A = re.sub(r'<title>.*?</title>', '<title>%s</title>' % C['title'], A, count=1)
    A = re.sub(r'<meta name="description" content="[^"]*">', '<meta name="description" content="%s">' % C['desc'], A, count=1)
    A = re.sub(r'<meta property="og:description" content="[^"]*">', '<meta property="og:description" content="%s">' % C['og'], A, count=1)
    A = re.sub(r'<meta name="twitter:description" content="[^"]*">', '<meta name="twitter:description" content="%s">' % C['tw'], A, count=1)
    A = re.sub(r'"headline": "[^"]*"', '"headline": "%s"' % C['title'], A, count=1)
    A = re.sub(r'"description": "[^"]*"', '"description": "%s"' % C['ld'], A, count=1)
    A = re.sub(r'"datePublished": "[^"]*"', '"datePublished": "2026-11-26"', A, count=1)
    A = re.sub(r'"dateModified": "[^"]*"', '"dateModified": "2026-11-26"', A, count=1)
    B = fix(B)
    Cc = fix(Cc)

    s1 = ''.join(bloc(i, C['trad_cls'], C['trads'][i] if C['trad_cls'] else None) for i in range(len(SEIFS)))
    corps = C['hero'] + '\n<main>\n\n' + C['intro'] + '\n' + C['s1_head'] + '\n' + s1 + '\n' + C['s1_source'] + '\n  </section>\n\n'
    corps += C['s2_head'] + '\n' + points(lang, C['points']) + '\n  </section>\n\n'
    s4 = C['s4_head'] + '\n' + '\n'.join('        <li>%s</li>' % q(li) for li in C['s4']) + '\n' + C['s4_foot']
    out = A + corps + B + s4 + '\n' + Cc
    os.makedirs(DST, exist_ok=True)
    with open(os.path.join(DST, 'niveau-4-daat-harav%s.html' % suf), 'w', encoding='utf-8') as f:
        f.write(out)
    for mot in ('397', 'שצ״ז', '396', 'שצ״ו', '[[', ']]', 'שצ-ז', '399', '400', 'ת׳'):
        for m in re.finditer(re.escape(mot), out):
            ligne = out[max(0, m.start() - 60):m.end() + 30].replace('\n', ' ')
            print('RESIDU?', lang, mot, '…', ligne)
    print('écrit', lang, len(out))


for L in ('fr', 'he', 'en'):
    construire(L)
