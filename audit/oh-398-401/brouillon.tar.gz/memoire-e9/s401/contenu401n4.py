# Contenu rédigé du niveau 4 du siman 401 — lu par build401n4.py (exec).
# Les marqueurs [[clé]] sont remplacés par l'extraction de Sefaria (q401n4.py).
# Variables attendues du builder : CHAP_SANS_COMPTE, COMPTE.

LABELS = {
    'fr': {'meh': "Ce qu'écrit le Mehaber :", 'rama': "Ce qu'écrit le Rama :", 'rav': "Ce qu'écrit le Rav :",
           'diff': 'La différence :', 'comm': 'Ce qui se lit ailleurs :'},
    'he': {'meh': 'דברי המחבר:', 'rama': 'דברי הרמ״א:', 'rav': 'דברי הרב:',
           'diff': 'ההבדל:', 'comm': 'מה שכתוב במקום אחר:'},
    'en': {'meh': 'What the Mechaber writes:', 'rama': 'What the Rema writes:', 'rav': 'What the Rav writes:',
           'diff': 'The difference:', 'comm': 'What is found elsewhere:'},
}

SAH1 = '(שו״ע הרב ת״א:א)'
SAH2 = '(שו״ע הרב ת״א:ב)'
SA = '(שו״ע או״ח ת״א:א)'
RAMA = '(רמ״א או״ח ת״א:א)'
BY = '(בית יוסף או״ח ת״א)'
MA = '(מגן אברהם ת״א ס״ק א)'
TAZ = '(ט״ז או״ח ת״א ס״ק ב)'


def Qt(k, ref):
    return '«&nbsp;[[%s]]&nbsp;» %s' % (k, ref)


def MB(n):
    return '(משנה ברורה ת״א ס״ק %s)' % n


CHAP_STRONG = 'סימן ת״א — %s — %s' % (CHAP_SANS_COMPTE, COMPTE)

HE_T = [
    'נקודה א — כל אדם קונה שביתה במקום שקידש עליו היום, ומי שישן בדרך (שו״ע הרב ת״א:א)',
    'נקודה ב — חפצי הפקר (שו״ע הרב ת״א:א)',
    'נקודה ג — חפצי הנכרי (שו״ע הרב ת״א:א)',
    'נקודה ד — עיר המוקפת לדירה (שו״ע הרב ת״א:א)',
    'נקודה ה — כלים שהשאיל ישראל לנכרי והוחזרו לו בשבת (שו״ע הרב ת״א:ב)',
    'נקודה ו — חצר, ומבואות המתוקנים בצורת פתח (שו״ע הרב ת״א:ב)',
]

# ============================================================================ FR
FR = {}
FR['title'] = "Siman ת״א · Niveau 4 — Chitah de l'Admour HaZaken : celui qui dort en chemin à la tombée de la nuit, et la chevita des objets | Hilkhot Te'houmin"
FR['desc'] = ("Niveau 4 (Daat HaRav) du Siman ת״א — tout homme acquiert son lieu de repos (chevita) à l'endroit où le jour s'est sanctifié sur lui, "
              "même sans l'avoir dit ; même celui qui dort en chemin, s'il est hors de la limite de la ville, l'acquiert à sa place, et ses objets "
              "sont comme lui ; puis les objets sans propriétaire, ceux d'un non-Juif, la ville entourée pour l'habitation, et les objets qu'un Juif "
              "a prêtés à un non-Juif et qui lui sont rendus le Chabbat. Le texte intégral des deux séifim du Choulhan Aroukh de l'Admour HaZaken, "
              "leur traduction, ce en quoi le texte du Rav diffère du Mehaber et du Rama, la conduite pratique.")
FR['og'] = ("La chitah de l'Admour HaZaken sur celui qui dort en chemin à la tombée de la nuit : tout homme acquiert son lieu de repos là où le "
            "jour s'est sanctifié sur lui ; puis les objets sans propriétaire, ceux d'un non-Juif, et les objets prêtés à un non-Juif et rendus "
            "le Chabbat.")
FR['tw'] = "Chitah de l'Admour HaZaken sur celui qui dort en chemin à la tombée de la nuit, et sur la chevita des objets."
FR['ld'] = ("Niveau 4 (Daat HaRav) du Siman ת״א : celui qui dort en chemin à la tombée de la nuit, et la chevita des objets, dans le "
            "Choulhan Aroukh de l'Admour HaZaken.")
FR['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">Orah Haïm ת״א · Niveau 4 · שיטת אדמו״ר הזקן</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">Daat HaRav — Le Choulhan Aroukh de l'Admour HaZaken sur le Siman ת״א</h1>
    <p class="hero-subtitle">Tout homme acquiert son lieu de repos (<em>chevita</em>) à l'endroit où le jour s'est sanctifié sur lui, même sans avoir dit « mon lieu de repos est à ma place » ; même celui qui dort en chemin, s'il est hors de la limite (<em>te'houm</em>) de la ville, l'acquiert à sa place, et ses objets sont comme lui. Puis les objets sans propriétaire, ceux du non-Juif, la ville entourée pour l'habitation, et, au séif ב, les objets qu'un Juif a prêtés à un non-Juif et qui lui sont rendus le Chabbat. Les deux séifim du Choulhan Aroukh de l'Admour HaZaken, comparés au séif unique du Mehaber et à la glose du Rama.</p>
  </div>
</div>
'''
FR['intro'] = '''  <div class="intro-block">
    <p><strong>Pourquoi un niveau 4 dédié à l'Admour HaZaken ?</strong> Le <strong>Choulhan Aroukh de l'Admour HaZaken</strong> n'est pas un commentaire sur le Mehaber (מחבר) : c'est un Choulhan Aroukh à part entière, écrit par l'Admour HaZaken, avec sa propre découpe et sa propre numérotation des séifim. Ici, le Choulhan Aroukh HaRav compte deux séifim, et le Choul'han Aroukh du Mehaber un seul, à la fin duquel vient une glose du Rama introduite par הגה ; le séif ב du Rav traite du sujet de cette glose. Les renvois de cette page suivent la numérotation du Rav, sauf quand le Choul'han Aroukh du Mehaber est nommé.</p>
    <p>Cette page rassemble, pour le siman ת״א, le texte intégral du Rav et sa traduction, ce en quoi son texte diffère de celui du Mehaber et du Rama, et la conduite pratique qui en découle.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken.html" style="color:var(--habad);font-weight:600;">→ Lire la préface générale sur la chitah de l'Admour HaZaken</a></p>
  </div>
'''
FR['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · טקסט אדמו״ר הזקן</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-ת-א">שלחן ערוך הרב — סימן ת״א</h2>
    <h2 class="section-title-fr" id="le-texte-integral-du-choulhan-aroukh-de-l-admour-hazaken-שולחן-ערוך-הרב">Le texte intégral du Choulhan Aroukh de l'Admour HaZaken (שולחן ערוך הרב)</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 15px;">
      <strong>%s</strong><br>
      <em>Source : édition Kehot, telle que reproduite sur Sefaria. 2 séifim (le Choul'han Aroukh du Mehaber en compte 1, sous sa propre numérotation).</em>
    </p>
''' % CHAP_STRONG
FR['trad_cls'] = 'sa-fr'
FR['trads'] = [
    "Celui qui dort en chemin et sur qui la nuit est tombée acquiert deux mille amot dans chaque direction ; il contient deux séifim :<br><br>"
    "Tout homme acquiert son lieu de repos (<em>chevita</em>) à l'endroit où le jour s'est sanctifié sur lui, et il a de là deux mille [amot] dans chaque direction, bien qu'il n'ait pas dit « mon lieu de repos est à ma place » (<em>chevitati bimkomi</em>) ; car, puisque, s'il l'avait voulu, il l'aurait dit, c'est comme s'il l'avait dit. Et même celui qui dort en chemin et sur qui la nuit est tombée a acquis son lieu de repos à sa place, s'il est hors de la limite (<em>te'houm</em>) de la ville, et il a de là deux mille [amot] dans chaque direction, bien qu'il n'ait pas du tout eu l'intention d'acquérir un lieu de repos ; car, puisque, s'il avait été éveillé, il aurait acquis, il acquiert aussi quand il dort. Et tous ses objets sont comme lui. <br><br>"
    "Mais les objets sans propriétaire (<em>hefker</em>), qui n'ont pas de propriétaires qui puissent leur faire acquérir un lieu de repos, n'ont pas acquis de lieu de repos d'eux-mêmes ; ils sont au contraire comme les pieds de celui qui les acquiert le premier : il peut les emporter à l'endroit où il va, lui, et même hors de la limite de la ville, s'il a fait un érouv vers cet endroit.<br><br>"
    "Mais les objets du non-Juif acquièrent un lieu de repos à leur place, bien que leurs propriétaires ne soient pas sujets au lieu de repos (<em>lav benei chevita</em>), car on a décrété sur les objets du non-Juif un décret à cause des objets du Juif ; et si le non-Juif les a sortis hors de la limite, ils n'ont que quatre amot. Sauf que, s'il les a apportés dans la ville, leur loi est comme [celle de celui] que des non-Juifs ont fait sortir hors de la limite et ont placé dans la ville, pour qui toute la ville compte comme quatre amot, puisqu'il est sorti par contrainte (<em>be'ones</em>), comme il sera expliqué au siman 405.<br><br>"
    "Et cela, pourvu que la ville soit entourée de cloisons (<em>me'hitsot</em>) pour l'habitation ; car tout endroit qui n'est pas entouré pour l'habitation ne compte pas comme quatre amot, comme il a été expliqué au siman 396.<br><br>"
    "(Et cela n'est pas semblable à [celui qui] a fait son repos (<em>chavat</em>) dans une ville, pour qui toute [la ville] compte comme quatre amot bien qu'elle ne soit pas du tout entourée de cloisons, parce qu'on ne commence à lui mesurer les deux mille [amot] qu'à partir de la maison extérieure, puisque toutes les maisons de la ville sont incluses (<em>mouvla'im</em>) l'une dans les soixante-dix [amot] et une fraction (<em>chirayim</em>) de l'autre. Mais néanmoins, toute la ville ne compte pas pour lui comme quatre amot à proprement parler, mais seulement sa maison, dans laquelle il a acquis son lieu de repos ; et les autres maisons sont incluses l'une dans les soixante-dix amot et une fraction de l'autre, et on ne commence pas la mesure à partir d'elles. Mais pour celui qui sort hors de la limite, toute la ville ne compte pas comme quatre amot, à moins qu'elle ne soit entourée de cloisons pour l'habitation.)<br><br>"
    "Et les villes ordinaires (<em>stam 'ayarot</em>) sont entourées pour l'habitation, car on construit d'abord les maisons et ensuite on les entoure. Mais les forteresses ordinaires (<em>stam mivtsarim</em>) ne sont pas entourées pour l'habitation :",
    "C'est pourquoi il faut prendre garde (<em>yech lizaher</em>), quand un Juif a prêté ses objets à un non-Juif et qu'ils lui ont été rendus le Chabbat, de ne pas les déplacer dans la ville au-delà de quatre amot depuis l'endroit où le non-Juif les a posés, si la ville n'est pas entourée de cloisons ; par exemple, si l'un les a déplacés de deux amot, le second ne les déplacera pas de plus de deux amot. <br><br>"
    "Mais s'il les a posés dans une cour, il est permis de les déplacer dans toute [la cour], car toute [la cour] est comme quatre amot. Et de même, nos ruelles (<em>mevo'ot</em>) aménagées par une forme de porte (<em>tsourat hapéta'h</em>) sont dites entourées pour l'habitation, puisqu'on construit d'abord les maisons et ensuite on fait la forme de porte (et il en va de même si elles sont aménagées par un montant (<em>le'hi</em>) ou une poutre (<em>kora</em>) : elles sont comme quatre amot pour ce qui est de celui qui sort hors de la limite, comme elles sont comme quatre amot pour ce qui est du déplacement [des objets] (<em>tiltoul</em>), puisqu'il est permis de déplacer [des objets] dans toutes) :",
]
FR['s1_source'] = '''    <p style="margin-top: 20px; font-size: 13px; color: var(--text-muted); font-style: italic;">
      Source : <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.401" target="_blank" style="color: var(--habad);">Sefaria — Shulchan Arukh HaRav, Orach Chayim ת״א</a>. Sefaria ne donne aucune entrée de Kountress Aharon pour ce siman.
    </p>'''
FR['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · לשון הרב ולשון המחבר</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ-א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="ou-le-texte-du-rav-differe-du-seif-du-mehaber-et-du-rama">Où le texte du Rav diffère du séif du Mehaber et du Rama</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid);">
      Chaque point met côte à côte le séif unique du Choul'han Aroukh du Mehaber, ou la glose du Rama, et un séif du Choulhan Aroukh de l'Admour HaZaken, dans l'ordre du texte du Rav, et ne relève que ce que la comparaison des deux textes montre. Un point relevé n'est pas propre au Rav pour autant : la page en nomme parfois la source, ou le commentateur qui le lit déjà dans les mots du Mehaber ; elle ne relève ni toutes les sources ni toutes les divergences (voir aussi le niveau 2).
    </p>'''
FR['points'] = [
    {
        'he_t': HE_T[0],
        't': "Point א — tout homme acquiert son lieu de repos là où le jour s'est sanctifié sur lui, et celui qui dort en chemin (Choulhan Aroukh HaRav 401:1)",
        'id': 'le-lieu-ou-le-jour-s-est-sanctifie',
        'h3': "Le lieu où le jour s'est sanctifié, et celui qui dort en chemin",
        'meh': ("le séif s'ouvre sur celui qui dort en chemin et sur qui la nuit est tombée : " + Qt('m1', SA) +
                " — il a acquis son lieu de repos à sa place, et il a deux mille amot dans chaque direction ; et cela seulement pour un homme, "
                "parce que, puisque, s'il avait été éveillé, il aurait acquis, endormi aussi il acquiert."),
        'rav': Qt('r1', SAH1) + '. Puis : ' + Qt('r2', SAH1) + '.',
        'diff': ("le texte du Rav ouvre le séif par une règle générale que le séif du Mehaber n'écrit pas ici : tout homme acquiert son lieu "
                 "de repos à l'endroit où le jour s'est sanctifié sur lui, bien qu'il n'ait pas dit « mon lieu de repos est à ma place », puisque, "
                 "s'il l'avait voulu, il l'aurait dit ; et il amène ensuite celui qui dort en chemin par « et même ». Pour celui qui dort, il ajoute " +
                 Qt('r2a', SAH1) + " (s'il est hors de la limite de la ville) et " + Qt('r2b', SAH1) +
                 " (bien qu'il n'ait pas du tout eu l'intention d'acquérir un lieu de repos). Le Mehaber écrit " + Qt('m1a', SA) +
                 " (et cela seulement pour un homme) ; le Rav n'écrit pas ces mots, mais écrit, après la raison, " + Qt('r2c', SAH1) +
                 " (et tous ses objets sont comme lui), puis oppose, comme le Mehaber, les objets sans propriétaire (point ב)."),
        'comm': ("le Beit Yossef, avant le Rav, rapporte que, dans la Guemara, Rabbi Yehochoua ben Lévi dit que la halakha est comme Rabbi "
                 "Yo'hanan ben Nouri, et qu'elle est comme celui qui est indulgent en matière d'érouv, puis cette explication de Rachi : " + Qt('byr', BY) +
                 " — c'est pour l'homme que la halakha est comme lui [Rabbi Yo'hanan ben Nouri] : puisque, éveillé, il acquiert, endormi aussi il "
                 "acquiert ; mais pour les objets, la halakha n'est pas comme lui. La Michna Beroura, après le Rav, explique la raison du "
                 "Mehaber : " + Qt('mb1', MB('א')) +
                 " — c'est-à-dire : bien qu'au crépuscule, qui est le moment de l'acquisition du lieu de repos, il dormît et n'eût pas "
                 "l'intention d'y acquérir son lieu de repos, il y a néanmoins acquis son lieu de repos, pour avoir de là deux mille amot dans "
                 "chaque direction ; et elle écrit sur les objets : " + Qt('mb2a', MB('ב')) +
                 " — car les objets d'un Juif, qui ont des propriétaires, sont comme les pieds des propriétaires."),
    },
    {
        'he_t': HE_T[1],
        't': "Point ב — les objets sans propriétaire (Choulhan Aroukh HaRav 401:1)",
        'id': 'les-objets-sans-proprietaire',
        'h3': 'Les objets sans propriétaire',
        'meh': (Qt('m2', SA) + " — mais les objets sans propriétaire n'acquièrent pas de lieu de repos, et ils sont comme les pieds de celui "
                "qui les acquiert le premier, qui peut les emporter à l'endroit où il va, lui."),
        'rav': Qt('r3', SAH1) + '.',
        'diff': ("la règle est la même dans les deux textes. Le Rav en écrit la raison, " + Qt('r3a', SAH1) +
                 " (ils n'ont pas de propriétaires qui puissent leur faire acquérir un lieu de repos : ils n'ont pas acquis de lieu de repos "
                 "d'eux-mêmes) ; et il ajoute " + Qt('r3b', SAH1) +
                 " (et même hors de la limite de la ville, s'il a fait un érouv vers cet endroit)."),
        'comm': ("la Michna Beroura, après le Rav, écrit : " + Qt('mb2b', MB('ב')) +
                 " — mais les objets sans propriétaire, qui n'ont pas de propriétaires, n'ont pas d'eux-mêmes acquis de lieu de repos à leur "
                 "place, parce qu'ils ne sont jamais doués de pensée (<em>benei da'at</em>), et ils ne ressemblent pas à un homme endormi ; et sur "
                 "les mots du Mehaber " + Qt('m2a', SA) + " : " + Qt('mb3', MB('ג')) +
                 " — et même si c'est au-delà des deux mille [amot] de l'endroit où les objets étaient posés au départ. Sur le cas où deux "
                 "personnes les ont acquis ensemble, que n'écrivent ni le séif du Mehaber ni celui du Rav, les avis divergent : voir le niveau 2."),
    },
    {
        'he_t': HE_T[2],
        't': "Point ג — les objets du non-Juif (Choulhan Aroukh HaRav 401:1)",
        'id': 'les-objets-du-non-juif',
        'h3': 'Les objets du non-Juif',
        'meh': (Qt('m3', SA) + " — mais les objets du non-Juif acquièrent un lieu de repos à leur place, bien que leurs propriétaires ne "
                "soient pas sujets au lieu de repos : décret sur les objets du non-Juif à cause des objets du Juif ; et si un non-Juif les a "
                "sortis hors de leur limite et les a apportés dans une ville, on peut les déplacer dans toute [la ville], car elle compte tout "
                "entière comme quatre amot."),
        'rav': Qt('r4', SAH1) + '.',
        'diff': ("la règle et sa raison, le décret, sont les mêmes dans les deux textes. Le Rav écrit en toutes lettres " + Qt('r4a', SAH1) +
                 " (et si le non-Juif les a sortis hors de la limite, ils n'ont que quatre amot), ce que le séif du Mehaber n'écrit pas en ces "
                 "mots. Pour les objets apportés dans la ville, là où le Mehaber écrit " + Qt('m3a', SA) +
                 ", le Rav écrit que leur loi est comme [celle de celui] que des non-Juifs ont fait sortir hors de la limite et ont placé dans la "
                 "ville, pour qui toute la ville compte comme quatre amot, " + Qt('r4c', SAH1) +
                 " (puisqu'il est sorti par contrainte), et il renvoie au siman 405 ; la condition que la ville soit entourée pour l'habitation "
                 "suit, dans les deux textes (point ד)."),
        'comm': ("le Beit Yossef, avant le Rav, rapporte que c'est une discussion de Chemouel et de Rabbi Yo'hanan, et écrit : " +
                 Qt('by2', BY) + " — et il a été tranché là, dans la Guemara : la halakha est comme Rabbi Yo'hanan. La Michna Beroura, après "
                 "le Rav, explique le décret : " + Qt('mb5', MB('ה')) +
                 " — puisque, de toute façon, ils ont des propriétaires, si nous disions qu'ils n'ont pas acquis de lieu de repos, on en viendrait "
                 "à dire, aussi pour des objets dont les propriétaires sont juifs, qu'ils n'ont pas non plus acquis de lieu de repos, et on "
                 "permettrait de les sortir au-delà des deux mille [amot] ; et elle lit dans les mots du Mehaber " + Qt('m3b', SA) +
                 " ce que le Rav écrit en toutes lettres : " + Qt('mb6', MB('ו')) +
                 " — selon la loi, des objets qu'on a sortis hors de leur limite, il est interdit de les déplacer sinon dans quatre amot ; "
                 "néanmoins, dans cette ville, qui est entourée de cloisons, il est permis de [les] déplacer dans toute [la ville], car elle "
                 "compte tout entière comme quatre amot. Sur la portée de « à leur place » quand le non-Juif lui-même se trouvait ailleurs, "
                 "les avis divergent : voir le niveau 2."),
    },
    {
        'he_t': HE_T[3],
        't': "Point ד — la ville entourée pour l'habitation (Choulhan Aroukh HaRav 401:1)",
        'id': 'la-ville-entouree-pour-l-habitation',
        'h3': "La ville entourée pour l'habitation",
        'meh': (Qt('m4', SA) + " — pourvu qu'elle soit entourée pour l'habitation ; et les villes ordinaires sont entourées pour "
                "l'habitation, car on construit d'abord les maisons et ensuite on les entoure ; mais les forteresses ordinaires ne sont pas "
                "entourées pour l'habitation."),
        'rav': Qt('r5', SAH1) + '. Puis, entre parenthèses : ' + Qt('r6', SAH1) + '. Et : ' + Qt('r7', SAH1) + '.',
        'diff': ("la condition est dans les deux textes. Le Rav écrit que la ville doit être entourée de cloisons pour l'habitation, et il "
                 "en donne la raison, " + Qt('r5a', SAH1) +
                 " (tout endroit qui n'est pas entouré pour l'habitation ne compte pas comme quatre amot), en renvoyant au siman 396. Il ajoute "
                 "entre parenthèses ce que le séif du Mehaber n'écrit pas : celui qui a fait son repos dans une ville n'est pas comparable, car "
                 "pour lui toute la ville compte comme quatre amot même si elle n'est pas du tout entourée de cloisons, parce qu'on ne commence "
                 "à lui mesurer les deux mille [amot] qu'à partir de la maison extérieure ; mais même pour lui, à proprement parler, seule sa "
                 "maison compte comme quatre amot ; tandis que, pour celui qui sort hors de la limite, toute la ville ne compte comme quatre amot "
                 "que si elle est entourée de cloisons pour l'habitation. La phrase sur les villes et les forteresses ordinaires est la même "
                 "dans les deux textes."),
        'comm': ("le Beit Yossef, avant le Rav, explique la condition : " + Qt('by4', BY) +
                 " — c'est-à-dire : mais si elle n'était pas entourée, ou entourée non pour l'habitation, par exemple entourée [d'abord] et "
                 "habitée à la fin, elle ne compte pas tout entière comme quatre amot, selon la loi du <em>karpef</em> de plus de deux "
                 "<em>beit séa</em> qui n'a pas été entouré pour l'habitation, expliquée au siman 358. La Michna Beroura, après le Rav : " +
                 Qt('mb7', MB('ז')) +
                 " — qu'on a d'abord bâti des maisons pour l'habitation, et ensuite on les a entourées d'une muraille tout autour ; ce qui "
                 "n'est pas le cas si l'enceinte était antérieure : on n'y déplace [des objets] que dans quatre amot, si l'enceinte était de "
                 "plus de deux <em>beit séa</em> ; et sur les forteresses : " + Qt('mb8', MB('ח')) +
                 " — car l'usage est de faire d'abord la forteresse, et ensuite des gens s'y installent pour y habiter. Sur la condition de "
                 "l'enceinte elle-même, les avis divergent : voir le niveau 2."),
    },
    {
        'rama': True,
        'he_t': HE_T[4],
        't': "Point ה — les objets qu'un Juif a prêtés à un non-Juif et qui lui sont rendus le Chabbat (Choulhan Aroukh HaRav 401:2)",
        'id': 'les-objets-pretes-a-un-non-juif',
        'h3': 'Les objets prêtés à un non-Juif',
        'meh': ("dans sa glose, introduite par הגה à la fin du séif א du Mehaber : " + Qt('rama', RAMA) +
                " — c'est pourquoi il faut prendre garde, quand un Juif a prêté ses objets à un non-Juif et qu'ils lui ont été rendus le "
                "Chabbat, de ne pas les déplacer au-delà de quatre amot si la ville n'est pas entourée d'une cloison, car les objets ont acquis "
                "leur lieu de repos chez le non-Juif (Or Zaroua)."),
        'rav': Qt('r8', SAH2) + '.',
        'diff': ("le Rav écrit cette règle dans un séif à part, le séif ב, avec le même degré, « il faut prendre garde » (<em>yech "
                 "lizaher</em>), et, comme la glose, il l'ouvre par " + Qt('r8d', SAH2) +
                 " (c'est pourquoi) ; il n'écrit pas la raison que donne le Rama, " + Qt('ramat', RAMA) + ". Il précise " +
                 Qt('r8a', SAH2) +
                 " (de ne pas les déplacer dans la ville au-delà de quatre amot depuis l'endroit où le non-Juif les a posés), et ajoute un "
                 "exemple : " + Qt('r8c', SAH2) +
                 " (si l'un les a déplacés de deux amot, le second ne les déplacera pas de plus de deux amot)."),
        'comm': ("la Michna Beroura, après le Rav, écrit sur le cas du prêt : " + Qt('mb9', MB('ט')) +
                 " — la veille du Chabbat, et [le non-Juif] les a emportés dans sa maison, qui est hors de la limite : car, bien que les objets "
                 "soient au Juif, néanmoins, puisqu'il les lui a prêtés, ils ont acquis leur lieu de repos chez lui ; et à plus forte raison "
                 "celui qui emprunte des objets à un non-Juif le Chabbat ; et sur l'interdit de les déplacer : " + Qt('mb10', MB('י')) +
                 " — c'est-à-dire pour des vêtements ; car les autres objets, de toute façon, il est interdit de [les] déplacer le Chabbat "
                 "au-delà de quatre amot, puisqu'il n'y a pas d'érouv ; et le jour de fête (<em>Yom Tov</em>), le cas se présente même pour "
                 "les autres objets, puisqu'il n'y a pas [ce jour-là] d'interdit de transport (<em>hotsaa</em>). Ces précisions sont de la "
                 "Michna Beroura ; le séif du Rav ne les écrit pas."),
    },
    {
        'rama': True,
        'he_t': HE_T[5],
        't': "Point ו — la cour, et les ruelles aménagées par une forme de porte (Choulhan Aroukh HaRav 401:2)",
        'id': 'la-cour-et-les-ruelles',
        'h3': 'La cour, et les ruelles aménagées',
        'meh': ("la glose du Rama s'arrête sur la ville qui n'est pas entourée d'une cloison (point ה) ; elle n'écrit ni la cour ni les "
                "ruelles (<em>mevo'ot</em>)."),
        'rav': Qt('r9', SAH2) + '.',
        'diff': ("le texte du Rav ajoute que, s'il les a posés dans une cour, il est permis de les déplacer dans toute la cour, qui compte "
                 "comme quatre amot ; que nos ruelles aménagées par une forme de porte (<em>tsourat hapéta'h</em>) sont dites entourées pour "
                 "l'habitation, puisqu'on construit d'abord les maisons et ensuite on fait la forme de porte ; et, entre parenthèses, qu'il en "
                 "va de même si elles sont aménagées par un montant (<em>le'hi</em>) ou une poutre (<em>kora</em>)."),
        'comm': ("le Magen Avraham, avant le Rav, écrit sur les mots du Mehaber " + Qt('m4a', SA) + " : " + Qt('ma1', MA) +
                 " — et les habitants de villes ouvertes (<em>perazim</em>) qui ont aménagé les ruelles selon leur loi par une forme de porte "
                 "comptent comme entourés pour l'habitation, puisqu'on construit d'abord les maisons et ensuite on fait la forme de porte, comme "
                 "il est écrit au siman 358, séif 2 ; et voir là, au séif 1, dans la glose, que, si ce n'est pas entouré pour l'habitation, "
                 "l'érouv ne sert pas, car même [celui] d'une seule personne est interdit. Le Taz, avant le Rav, écrit sur la glose du Rama : " +
                 Qt('taz2a', TAZ) +
                 " — il me semble que, s'il l'a apporté dans une ruelle de Juifs où l'on fait notre érouv, c'est-à-dire une forme de porte, "
                 "toute [la ruelle] est comme quatre amot : car par là il est permis de déplacer [des objets] d'un domaine à l'autre et dans la "
                 "ruelle elle-même, puisque nous considérons toute la ruelle comme un seul domaine ; de même pour ce qui vient de hors de la "
                 "limite, toute [la ruelle] est comme quatre amot, et il est permis de le déplacer dans toute la ruelle ; il ajoute que c'est ce "
                 "qui ressort du Rashal, qu'il cite, et conclut : " + Qt('taz2b', TAZ) +
                 " — et cette ruelle, permise par une forme de porte, est comparable à une seule cour ; ainsi il me paraît clair, selon mon "
                 "humble avis. La Michna Beroura, après le Rav : " + Qt('mb7b', MB('ז')) +
                 " — et nos villes ouvertes, puisqu'on a aménagé les ruelles selon leur loi par une forme de porte, comptent tout entières comme "
                 "entourées pour l'habitation : les maisons sont comme des cloisons, et les endroits ouverts ont été aménagés par une forme de "
                 "porte, ce qui les fait [entourés] pour l'habitation, puisqu'on construit d'abord les maisons et ensuite on fait la forme de "
                 "porte ; et une cour compte toujours comme quatre amot. Ces passages parlent de la forme de porte ; le montant et la poutre, "
                 "que le Rav ajoute entre parenthèses, n'y sont pas nommés."),
    },
]
FR['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · למעשה</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="la-conduite-habad-pratique">La conduite Habad pratique</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      Points de conduite halakhique qui découlent directement du Choulhan Aroukh de l'Admour HaZaken siman ת״א, dans la sensibilité Habad. Chaque point renvoie à son séif du Rav, dans l'ordre du texte.
    </p>

    <div class="lemaaseh-block">
      <h3 id="pour-le-hassid-חסיד-habad-siman-ת-א">Pour le Hassid (חסיד) Habad — Siman ת״א</h3>
      <ul>'''
FR['s4'] = [
    ("<strong>① Le lieu où le jour s'est sanctifié :</strong> tout homme acquiert son lieu de repos à l'endroit où le jour s'est sanctifié sur "
     "lui, et il a de là deux mille [amot] dans chaque direction, même s'il n'a pas dit « mon lieu de repos est à ma place » ; et même celui "
     "qui dort en chemin et sur qui la nuit est tombée a acquis son lieu de repos à sa place, s'il est hors de la limite de la ville, bien qu'il "
     "n'ait pas du tout eu l'intention d'en acquérir un ; et tous ses objets sont comme lui (401:1). <em>Référence : Choulhan Aroukh de "
     "l'Admour HaZaken ת״א:1.</em>"),
    ("<strong>② Les objets sans propriétaire :</strong> ils n'acquièrent pas de lieu de repos d'eux-mêmes ; ils sont comme les pieds de celui "
     "qui les acquiert le premier : il peut les emporter là où il va, et même hors de la limite de la ville, s'il a fait un érouv vers cet "
     "endroit (401:1). Sur le cas où deux personnes les ont acquis ensemble, les avis divergent : voir le niveau 2. <em>Référence : Choulhan "
     "Aroukh de l'Admour HaZaken ת״א:1.</em>"),
    ("<strong>③ Les objets du non-Juif :</strong> ils acquièrent un lieu de repos à leur place, par décret, à cause des objets du Juif (sur la "
     "portée de « à leur place » quand le non-Juif lui-même se trouvait ailleurs, les avis divergent : voir le niveau 2) ; si le non-Juif les a "
     "sortis hors de la limite, ils n'ont que quatre amot ; s'il les a apportés dans la ville, toute la ville compte comme quatre amot, comme "
     "pour celui que des non-Juifs ont fait sortir hors de la limite et ont placé dans la ville — pourvu que la ville soit entourée de cloisons "
     "pour l'habitation (sur cette condition, les avis divergent : voir le niveau 2) ; les villes ordinaires sont entourées pour l'habitation, "
     "les forteresses ordinaires ne le sont pas (401:1). <em>Référence : Choulhan Aroukh de l'Admour HaZaken ת״א:1.</em>"),
    ("<strong>④ Les objets prêtés à un non-Juif :</strong> quand un Juif a prêté ses objets à un non-Juif et qu'ils lui ont été rendus le "
     "Chabbat, il faut prendre garde de ne pas les déplacer dans la ville au-delà de quatre amot depuis l'endroit où le non-Juif les a posés, si "
     "la ville n'est pas entourée de cloisons (sur la condition de l'enceinte, les avis divergent : voir le niveau 2) ; si l'un les a déplacés "
     "de deux amot, le second ne les déplacera pas de plus de deux amot (401:2). Ce qu'écrit la Michna Beroura, après le Rav, sur ce cas : "
     "section 2, point ה. <em>Référence : Choulhan Aroukh de l'Admour HaZaken ת״א:2.</em>"),
    ("<strong>⑤ La cour et les ruelles :</strong> s'il les a posés dans une cour (les objets du point ④), il est permis de les déplacer dans toute la cour, qui compte "
     "comme quatre amot ; nos ruelles aménagées par une forme de porte sont dites entourées pour l'habitation, et il en va de même si elles "
     "sont aménagées par un montant ou une poutre : elles sont comme quatre amot pour ce qui est de celui qui sort hors de la limite (401:2). "
     "<em>Référence : Choulhan Aroukh de l'Admour HaZaken ת״א:2.</em>"),
]
FR['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 13px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ Cette section présente la conduite halakhique Habad. Pour toute question concrète : <strong>consulter ton Rav</strong>.
      </p>
    </div>
  </section>
'''

# ============================================================================ HE
HE = {}
HE['title'] = 'סימן ת״א · רמה 4 — שיטת אדמו״ר הזקן: מי שישן בדרך וחשכה לו, ושביתת החפצים | דעת'
HE['desc'] = ('רמה 4 (דעת הרב) של סימן ת״א — כל אדם קונה שביתה במקום שקידש עליו היום, אף על פי שלא אמר שביתתי במקומי; ואפילו מי '
              'שישן בדרך וחשכה לו קנה שביתה במקומו אם הוא חוץ לתחום העיר, וכל חפציו כמוהו; ואחר כך חפצי הפקר, חפצי הנכרי, עיר המוקפת '
              'לדירה, וכלים שהשאיל ישראל לנכרי והוחזרו לו בשבת. הטקסט המלא של שני הסעיפים של שולחן ערוך אדמו״ר הזקן, במה שונה לשון '
              'הרב מדברי המחבר והרמ״א, ההנהגה המעשית.')
HE['og'] = ('שיטת אדמו״ר הזקן במי שישן בדרך וחשכה לו: כל אדם קונה שביתה במקום שקידש עליו היום; ואחר כך חפצי הפקר, חפצי הנכרי, '
            'וכלים שהשאיל ישראל לנכרי והוחזרו לו בשבת.')
HE['tw'] = 'שיטת אדמו״ר הזקן במי שישן בדרך וחשכה לו, ובשביתת החפצים.'
HE['ld'] = 'רמה 4 (דעת הרב) של סימן ת״א: מי שישן בדרך וחשכה לו, ושביתת החפצים, בשולחן ערוך אדמו״ר הזקן.'
HE['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">דעת · רמה 4 — דעת הרב · שיטת אדמו״ר הזקן</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">דעת הרב — שולחן ערוך אדמו״ר הזקן על סימן ת״א</h1>
    <p class="hero-subtitle">כל אדם קונה שביתה במקום שקידש עליו היום, אף על פי שלא אמר שביתתי במקומי; ואפילו מי שישן בדרך וחשכה לו, אם הוא חוץ לתחום העיר, קנה שביתה במקומו, וכל חפציו כמוהו. ואחר כך חפצי הפקר, חפצי הנכרי, עיר המוקפת לדירה, ובסעיף ב — כלים שהשאיל ישראל לנכרי והוחזרו לו בשבת. שני הסעיפים של שולחן ערוך אדמו״ר הזקן, מושווים לסעיף היחיד של המחבר ולהגהת הרמ״א.</p>
  </div>
</div>
'''
HE['intro'] = '''  <div class="intro-block">
    <p><strong>מדוע רמה 4 מוקדשת לאדמו״ר הזקן?</strong> <strong>שולחן ערוך אדמו״ר הזקן</strong> אינו פירוש על המחבר: זהו שולחן ערוך בפני עצמו, שנכתב על ידי אדמו״ר הזקן, בחלוקה ובמספור סעיפים משלו. כאן יש בשולחן ערוך הרב שני סעיפים, ובשולחן ערוך של המחבר סעיף אחד, ובסופו הגהת הרמ״א הפותחת במלה הגה; סעיף ב של הרב עוסק בעניינה של הגהה זו. ההפניות בעמוד זה הולכות לפי מספור הרב, אלא אם כן נזכר בפירוש השולחן ערוך של המחבר.</p>
    <p>עמוד זה מקבץ, לסימן ת״א, את הטקסט המלא של הרב, את מה ששונה בלשונו מדברי המחבר והרמ״א, ואת ההנהגה המעשית העולה מדבריו.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken-he.html" style="color:var(--habad);font-weight:600;">← קרא את ההקדמה הכללית על שיטת אדמו״ר הזקן</a></p>
  </div>
'''
HE['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · טקסט אדמו״ר הזקן</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-ת״א">שלחן ערוך הרב — סימן ת״א</h2>
    <h2 class="section-title-fr" id="הטקסט-המלא-של-שולחן-ערוך-אדמו״ר-הזקן-שולחן-ערוך-הרב">הטקסט המלא של שולחן ערוך אדמו״ר הזקן (שולחן ערוך הרב)</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 16px;">
      <strong>%s</strong><br>
      <em>מקור: מהדורת קה״ת, כפי שמופיע בספריא. שני סעיפים (בשולחן ערוך של המחבר סעיף אחד, במספור שלו).</em>
    </p>
''' % CHAP_STRONG
HE['trad_cls'] = None
HE['trads'] = None
HE['s1_source'] = '''    <p style="margin-top: 20px; font-size: 14px; color: var(--text-muted); font-style: italic;">
      מקור: <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.401" target="_blank" style="color: var(--habad);">ספריא — שולחן ערוך הרב, אורח חיים ת״א</a>. בספריא לא מופיעים ערכי קונטרס אחרון לסימן זה.
    </p>'''
HE['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · לשון הרב ולשון המחבר</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="במה-שונה-לשון-הרב-מסעיף-המחבר-והרמ״א">במה שונה לשון הרב מסעיף המחבר והרמ״א</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid);">
      כל נקודה מעמידה זה לצד זה את הסעיף היחיד של שולחן ערוך המחבר, או את הגהת הרמ״א, וסעיף של שולחן ערוך אדמו״ר הזקן, לפי סדר לשון הרב, ואינה מציינת אלא מה שעולה מהשוואת שני הטקסטים. אין בכך שנקודה מסוימת מיוחדת לרב: הדף מזכיר לפעמים את מקורה, או את המפרש שכבר קורא אותה בדברי המחבר; אין הוא מציין את כל המקורות ולא את כל המחלוקות (ראה גם רמה 2).
    </p>'''
HE['points'] = [
    {
        'he_t': HE_T[0],
        'id': 'המקום-שקידש-עליו-היום',
        'h3': 'המקום שקידש עליו היום, ומי שישן בדרך',
        'meh': 'הסעיף פותח במי שישן בדרך וחשכה לו: ' + Qt('m1', SA) + '.',
        'rav': Qt('r1', SAH1) + '. ואחר כך: ' + Qt('r2', SAH1) + '.',
        'diff': ('לשון הרב פותחת את הסעיף בכלל שאין סעיף המחבר כותב כאן: כל אדם קונה שביתה במקום שקידש עליו היום, אף על פי שלא אמר '
                 'שביתתי במקומי, כיון שאם היה רוצה היה אומר; ואחריו מביאה את הישן בדרך בלשון ואפילו. בישן היא מוסיפה ' +
                 Qt('r2a', SAH1) + ', וכן ' + Qt('r2b', SAH1) + '. המחבר כותב ' + Qt('m1a', SA) + '; הרב אינו כותב מלים אלה, אלא כותב, אחרי הטעם, ' +
                 Qt('r2c', SAH1) + ', ואחר כך מביא, כמו המחבר, את חפצי ההפקר (נקודה ב).'),
        'comm': ('הבית יוסף, שקדם לרב, מביא שבגמרא אמר ריב״ל הלכה כרבי יוחנן בן נורי, ואמר הלכה כדברי המיקל בעירוב, ואת פירוש רש״י: ' + Qt('byr', BY) +
                 '. המשנה ברורה, אחרי הרב, מבאר את טעם המחבר: ' + Qt('mb1', MB('א')) + '; וכותב על החפצים: ' + Qt('mb2a', MB('ב')) + '.'),
    },
    {
        'he_t': HE_T[1],
        'id': 'חפצי-הפקר',
        'h3': 'חפצי הפקר',
        'meh': Qt('m2', SA) + '.',
        'rav': Qt('r3', SAH1) + '.',
        'diff': ('הדין שווה בשני הטקסטים. הרב כותב את טעמו: ' + Qt('r3a', SAH1) + '; ומוסיף: ' + Qt('r3b', SAH1) + '.'),
        'comm': ('המשנה ברורה, אחרי הרב, כותב: ' + Qt('mb2b', MB('ב')) + '; ועל דברי המחבר ' + Qt('m2a', SA) + ': ' + Qt('mb3', MB('ג')) +
                 '. במקרה שזכו בהם שניים יחד, שאין סעיף המחבר ולא סעיף הרב כותבים אותו, הדעות חלוקות: ראה רמה 2.'),
    },
    {
        'he_t': HE_T[2],
        'id': 'חפצי-הנכרי',
        'h3': 'חפצי הנכרי',
        'meh': Qt('m3', SA) + '.',
        'rav': Qt('r4', SAH1) + '.',
        'diff': ('הדין וטעמו, הגזירה, שווים בשני הטקסטים. הרב כותב בפירוש ' + Qt('r4a', SAH1) +
                 ', מה שאין סעיף המחבר כותב בלשון זו. ובחפצים שהביאם לעיר, במקום שהמחבר כותב ' + Qt('m3a', SA) +
                 ', הרב כותב שדינם כמי שהוציאוהו נכרים חוץ לתחום ונתנוהו בעיר, שכל העיר נחשבת לו כד׳ אמות, ' + Qt('r4c', SAH1) +
                 ', ומפנה לסימן ת״ה; התנאי שתהא העיר מוקפת לדירה בא אחר כך, בשני הטקסטים (נקודה ד).'),
        'comm': ('הבית יוסף, שקדם לרב, מביא שזו מחלוקת שמואל ורבי יוחנן, וכותב: ' + Qt('by2', BY) +
                 '. המשנה ברורה, אחרי הרב, מבאר את הגזירה: ' + Qt('mb5', MB('ה')) + '; וקורא בדברי המחבר ' + Qt('m3b', SA) +
                 ' את מה שהרב כותב בפירוש: ' + Qt('mb6', MB('ו')) +
                 '. בהיקף המלה במקומן, כשהנכרי עצמו היה במקום אחר, הדעות חלוקות: ראה רמה 2.'),
    },
    {
        'he_t': HE_T[3],
        'id': 'עיר-המוקפת-לדירה',
        'h3': 'עיר המוקפת לדירה',
        'meh': Qt('m4', SA) + '.',
        'rav': Qt('r5', SAH1) + '. ואחר כך, בסוגריים: ' + Qt('r6', SAH1) + '. ועוד: ' + Qt('r7', SAH1) + '.',
        'diff': ('התנאי כתוב בשני הטקסטים. הרב כותב שהעיר צריכה להיות מוקפת מחיצות לדירה, ונותן את הטעם: ' + Qt('r5a', SAH1) +
                 ', ומפנה לסימן שצ״ו. ומוסיף בסוגריים מה שאין סעיף המחבר כותב: אין לדמות זאת לשבת בעיר, שכל העיר נחשבת לו כד׳ אמות '
                 'אף על פי שאינה מוקפת מחיצות כלל, לפי שאין מתחילין למדוד לו אלפים אלא מן הבית החיצון; אבל אף לו אין כל העיר נחשבת '
                 'כד׳ אמות ממש, אלא ביתו בלבד; וליוצא חוץ לתחום אין כל העיר נחשבת כד׳ אמות עד שתהא מוקפת מחיצות לדירה. דין סתם עיירות '
                 'וסתם מבצרים שווה בשני הטקסטים.'),
        'comm': ('הבית יוסף, שקדם לרב, מבאר את התנאי: ' + Qt('by4', BY) + '. המשנה ברורה, אחרי הרב: ' + Qt('mb7', MB('ז')) +
                 '; ועל המבצרים: ' + Qt('mb8', MB('ח')) + '. בתנאי ההיקף עצמו הדעות חלוקות: ראה רמה 2.'),
    },
    {
        'rama': True,
        'he_t': HE_T[4],
        'id': 'כלים-שהשאיל-לנכרי',
        'h3': 'כלים שהשאיל ישראל לנכרי',
        'meh': 'בהגהתו, הפותחת במלה הגה בסוף סעיף א של המחבר: ' + Qt('rama', RAMA) + '.',
        'rav': Qt('r8', SAH2) + '.',
        'diff': ('הרב כותב דין זה בסעיף בפני עצמו, סעיף ב, באותה מדרגה, יש לזהר, ופותח אותו, כמו ההגהה, במלה ' + Qt('r8d', SAH2) +
                 '; ואינו כותב את הטעם שכותב הרמ״א, ' + Qt('ramat', RAMA) + '. הוא מפרש ' + Qt('r8a', SAH2) + ', ומוסיף דוגמה: ' +
                 Qt('r8c', SAH2) + '.'),
        'comm': ('המשנה ברורה, אחרי הרב, כותב על מקרה ההשאלה: ' + Qt('mb9', MB('ט')) + '; ועל איסור הטלטול: ' + Qt('mb10', MB('י')) +
                 '. פירושים אלה הם של המשנה ברורה; סעיף הרב אינו כותב אותם.'),
    },
    {
        'rama': True,
        'he_t': HE_T[5],
        'id': 'חצר-ומבואות',
        'h3': 'חצר, ומבואות המתוקנים',
        'meh': 'הגהת הרמ״א מסתיימת בעיר שאינה מוקפת מחיצה (נקודה ה); אינה כותבת לא חצר ולא מבואות.',
        'rav': Qt('r9', SAH2) + '.',
        'diff': ('לשון הרב מוסיפה: שאם הניחם בחצר מותר לטלטלם בכולה, שכולה כד׳ אמות; שמבואות שלנו המתוקנים בצורת פתח נקראים מוקפים '
                 'לדירה, שהרי בונים בתים תחילה ואחר כך עושים צורת פתח; ובסוגריים, שהוא הדין אם מתוקנים בלחי או קורה.'),
        'comm': ('המגן אברהם, שקדם לרב, כותב על דברי המחבר ' + Qt('m4a', SA) + ': ' + Qt('ma1', MA) + '. הט״ז, שקדם לרב, כותב על הגהת הרמ״א: ' +
                 Qt('taz2a', TAZ) + '; ומביא שכן משמע מדברי רש״ל, ומסיים: ' + Qt('taz2b', TAZ) + '. המשנה ברורה, אחרי הרב: ' +
                 Qt('mb7b', MB('ז')) + '. מקורות אלה מדברים בצורת פתח; הלחי והקורה, שהרב מוסיף בסוגריים, אינם נזכרים בהם.'),
    },
]
HE['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · למעשה</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="ההנהגה-המעשית-לחב״ד">ההנהגה המעשית לחב״ד</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      נקודות הנהגה הלכתית הנובעות ישירות משולחן ערוך אדמו״ר הזקן סימן ת״א, ברגישות החב״דית. כל נקודה מפנה לסעיף שלה בשולחן ערוך הרב, לפי סדר הלשון.
    </p>

    <div class="lemaaseh-block">
      <h3 id="לחסיד-חב״ד-סימן-ת״א">לחסיד חב״ד — סימן ת״א</h3>
      <ul>'''
HE['s4'] = [
    ('<strong>① המקום שקידש עליו היום:</strong> כל אדם קונה שביתה במקום שקידש עליו היום, ויש לו משם אלפים לכל רוח, אף על פי שלא אמר '
     'שביתתי במקומי; ואפילו מי שישן בדרך וחשכה לו קנה שביתה במקומו, אם הוא חוץ לתחום העיר, אף על פי שלא נתכוון לקנות שביתה כלל; וכל '
     'חפציו כמוהו (שו״ע הרב ת״א:א). <em>הפניה: שולחן ערוך אדמו״ר הזקן ת״א:א.</em>'),
    ('<strong>② חפצי הפקר:</strong> אינם קונים שביתה מאליהם, אלא הרי הם כרגלי הזוכה בהם תחילה: יכול להוליכם למקום שילך הוא, ואפילו חוץ '
     'לתחום העיר אם עירב לשם (שו״ע הרב ת״א:א). במקרה שזכו בהם שניים יחד, הדעות חלוקות: ראה רמה 2. <em>הפניה: שולחן ערוך אדמו״ר הזקן '
     'ת״א:א.</em>'),
    ('<strong>③ חפצי הנכרי:</strong> קונים שביתה במקומן, גזירה משום חפצי ישראל (בהיקף המלה במקומן, כשהנכרי עצמו היה במקום אחר, הדעות '
     'חלוקות: ראה רמה 2); אם הוציאם הנכרי חוץ לתחום, אין להם אלא ד׳ אמות; ואם הביאם לעיר, כל העיר נחשבת כד׳ אמות, כמו מי שהוציאוהו '
     'נכרים חוץ לתחום ונתנוהו בעיר — והוא שתהא העיר מוקפת מחיצות לדירה (בתנאי זה הדעות חלוקות: ראה רמה 2); סתם עיירות מוקפות לדירה, '
     'סתם מבצרים אינם מוקפים לדירה (שו״ע הרב ת״א:א). <em>הפניה: שולחן ערוך אדמו״ר הזקן ת״א:א.</em>'),
    ('<strong>④ כלים שהשאיל ישראל לנכרי:</strong> ישראל שהשאיל כליו לנכרי והוחזרו לו בשבת — יש לזהר שלא לטלטלם בעיר חוץ לד׳ אמות מן '
     'המקום שהניחם שם הנכרי, אם אין העיר מוקפת מחיצות (בתנאי ההיקף הדעות חלוקות: ראה רמה 2); ואם טלטלם אחד ב׳ אמות, לא יטלטלם השני יותר '
     'מב׳ אמות (שו״ע הרב ת״א:ב). מה שכותב המשנה ברורה, אחרי הרב, במקרה זה: פרק 2, נקודה ה. <em>הפניה: שולחן ערוך אדמו״ר הזקן ת״א:ב.</em>'),
    ('<strong>⑤ חצר ומבואות:</strong> אם הניחם בחצר (הכלים שבנקודה ④), מותר לטלטלם בכולה, שכולה כד׳ אמות; מבואות שלנו המתוקנים בצורת פתח נקראים מוקפים '
     'לדירה, והוא הדין אם מתוקנים בלחי או קורה: הם כד׳ אמות לעניין יוצא חוץ לתחום (שו״ע הרב ת״א:ב). <em>הפניה: שולחן ערוך אדמו״ר הזקן '
     'ת״א:ב.</em>'),
]
HE['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 14px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ סעיף זה מציג את ההנהגה ההלכתית של חב״ד. לכל שאלה ממשית: <strong>להיוועץ ברב שלך</strong>.
      </p>
    </div>
  </section>
'''

# ============================================================================ EN
EN = {}
EN['title'] = 'Siman ת״א · Level 4 — Shitah of the Alter Rebbe: one who is asleep on the road when night falls, and the shevisah of objects | Hilchos Techumin'
EN['desc'] = ("Level 4 (Daat HaRav) of Siman ת״א — every person acquires his place of rest (shevisah) at the place where the day became "
              "sanctified upon him, even without saying so; even one who is asleep on the road, if he is outside the techum of the city, "
              "acquires it where he is, and his belongings are like him; then ownerless objects, those of a non-Jew, the city enclosed for "
              "dwelling, and belongings a Jew lent to a non-Jew that are returned to him on Shabbos. The full text of the two seifim of the "
              "Shulchan Aruch HaRav, their translation, where the Rav's text differs from the Mechaber's and the Rema's, and the practical "
              "conduct.")
EN['og'] = ("The shitah of the Alter Rebbe on one who is asleep on the road when night falls: every person acquires his place of rest where "
            "the day became sanctified upon him; then ownerless objects, those of a non-Jew, and belongings lent to a non-Jew and returned "
            "on Shabbos.")
EN['tw'] = 'Shitah of the Alter Rebbe on one who is asleep on the road when night falls, and on the shevisah of objects.'
EN['ld'] = ('Level 4 (Daat HaRav) of Siman ת״א: one who is asleep on the road when night falls, and the shevisah of objects, in the '
            'Shulchan Aruch HaRav.')
EN['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">DAAT · LEVEL 4 — DAAT HARAV · Shitah of the Alter Rebbe</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">Daat HaRav — The Shulchan Aruch HaRav on Siman 401</h1>
    <p class="hero-subtitle">Every person acquires his place of rest (<em>shevisah</em>) at the place where the day became sanctified upon him, even without having said “my place of rest is where I am”; even one who is asleep on the road, if he is outside the <em>techum</em> of the city, acquires it where he is, and his belongings are like him. Then ownerless objects, those of the non-Jew, the city enclosed for dwelling, and, in seif ב, belongings a Jew lent to a non-Jew that are returned to him on Shabbos. The two seifim of the Shulchan Aruch HaRav, compared with the Mechaber's single seif and the Rema's gloss.</p>
  </div>
</div>
'''
EN['intro'] = '''  <div class="intro-block">
    <p><strong>Why a Level 4 dedicated to the Alter Rebbe?</strong> The <strong>Shulchan Aruch HaRav</strong> is not a commentary on the Mechaber: it is a Shulchan Aruch in its own right, written by the Alter Rebbe, with its own division and its own numbering of the seifim. Here the Shulchan Aruch HaRav has two seifim, and the Mechaber's Shulchan Aruch a single one, at the end of which comes a gloss of the Rema introduced by הגה; the Rav's seif ב deals with the subject of that gloss. The references on this page follow the Rav's numbering, except where the Mechaber's Shulchan Aruch is named.</p>
    <p>This page gathers, for Siman 401, the full text of the Rav with its translation, where his text differs from the Mechaber's and the Rema's, and the practical conduct that follows from it.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken-en.html" style="color:var(--habad);font-weight:600;">→ Read the general preface on the shitah of the Alter Rebbe</a></p>
  </div>
'''
EN['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · Text of the Alter Rebbe</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-ת״א">שלחן ערוך הרב — סימן ת״א</h2>
    <h2 class="section-title-fr" id="the-full-text-of-the-shulchan-aruch-harav-of-the-alter-rebbe">The full text of the Shulchan Aruch HaRav of the Alter Rebbe</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 15px;">
      <strong>%s</strong><br>
      <em>Source: Kehot edition, as reproduced on Sefaria. 2 seifim (the Mechaber's Shulchan Aruch has 1, under its own numbering).</em>
    </p>
''' % CHAP_STRONG
EN['trad_cls'] = 'sa-en'
EN['trads'] = [
    "One who is asleep on the road and night falls on him acquires two thousand <em>amos</em> in every direction; it contains two seifim:<br><br>"
    "Every person acquires his place of rest (<em>shevisah</em>) at the place where the day became sanctified upon him, and he has from there two thousand [<em>amos</em>] in every direction, although he did not say “my place of rest is where I am” (<em>shevisasi bimkomi</em>); for, since had he wanted he would have said it, it is as though he said it. And even one who is asleep on the road and night falls on him has acquired his place of rest where he is, if he is outside the <em>techum</em> of the city, and he has from there two thousand [<em>amos</em>] in every direction, although he had no intention at all of acquiring a place of rest; for, since had he been awake he would have acquired, he also acquires when he is asleep. And all his belongings are like him. <br><br>"
    "But ownerless (<em>hefker</em>) objects, which have no owners who could make them acquire a place of rest, have not acquired a place of rest of themselves; rather, they are like the feet of the one who first takes possession of them: he may carry them to the place where he himself goes, and even outside the <em>techum</em> of the city, if he made an <em>eruv</em> to there.<br><br>"
    "But the objects of the non-Jew acquire a place of rest where they are, although their owners are not subject to <em>shevisah</em> (<em>lav bnei shevisah</em>), for [the Sages] decreed a decree on the objects of the non-Jew on account of the objects of a Jew; and if the non-Jew took them out beyond the <em>techum</em>, they have only four <em>amos</em>. Except that, if he brought them into the city, their law is as [that of one whom] non-Jews took out beyond the <em>techum</em> and placed in the city, for whom the whole city is reckoned as four <em>amos</em>, since he went out under duress (<em>be'ones</em>), as will be explained in Siman 405.<br><br>"
    "And this is provided that the city is enclosed by partitions (<em>mechitzos</em>) for dwelling; for any place that is not enclosed for dwelling is not reckoned as four <em>amos</em>, as was explained in Siman 396.<br><br>"
    "(And this is not like [one who] rested (<em>shavas</em>) in a city, for whom all of it is reckoned as four <em>amos</em> even though it is not enclosed by partitions at all, because the two thousand are measured for him only from the outermost house, since all the houses of the city are absorbed (<em>muvla'im</em>) one within the seventy [<em>amos</em>] and a fraction (<em>shirayim</em>) of the other. But nevertheless the whole city is not reckoned for him as four <em>amos</em> in the strict sense, but only his house in which he acquired his place of rest; and the other houses are absorbed one within the seventy <em>amos</em> and a fraction of the other, and the measurement is not begun from them. But for one who goes out beyond the <em>techum</em>, the whole city is not reckoned as four <em>amos</em> unless it is enclosed by partitions for dwelling.)<br><br>"
    "And ordinary towns (<em>stam ayaros</em>) are enclosed for dwelling, for houses are built first and afterwards they are enclosed. But ordinary fortresses (<em>stam mivtzarim</em>) are not enclosed for dwelling:",
    "Therefore one must take care (<em>yesh lizaher</em>), when a Jew lent his belongings to a non-Jew and they were returned to him on Shabbos, not to move them in the city beyond four <em>amos</em> from the place where the non-Jew put them down, if the city is not enclosed by partitions; for example, if one person moved them two <em>amos</em>, the second shall not move them more than two <em>amos</em>. <br><br>"
    "But if he put them down in a courtyard, it is permitted to move them in all of it, for all of it is as four <em>amos</em>. And likewise our alleys (<em>mevo'os</em>) that are fitted with a form of a doorway (<em>tzuras hapesach</em>) are called enclosed for dwelling, since houses are built first and afterwards the form of a doorway is made (and the same applies if they are fitted with a side-post (<em>lechi</em>) or a crossbeam (<em>korah</em>): they are as four <em>amos</em> with regard to one who goes out beyond the <em>techum</em>, just as they are as four <em>amos</em> with regard to moving [objects] (<em>tiltul</em>), for it is permitted to move [objects] in all of them):",
]
EN['s1_source'] = '''    <p style="margin-top: 20px; font-size: 13px; color: var(--text-muted); font-style: italic;">
      Source: <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.401" target="_blank" style="color: var(--habad);">Sefaria — Shulchan Arukh HaRav, Orach Chayim 401</a>. Sefaria gives no Kuntres Acharon entry for this siman.
    </p>'''
EN['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · The Rav's text and the Mechaber's</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="where-the-rav-s-text-differs-from-the-mechaber-s-seif-and-the-rema-s">Where the Rav's text differs from the Mechaber's seif and the Rema's</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid);">
      Each point sets side by side the single seif of the Mechaber's Shulchan Aruch, or the Rema's gloss, and a seif of the Shulchan Aruch HaRav, in the order of the Rav's text, and notes only what the comparison of the two texts shows. A point noted is not thereby unique to the Rav: the page sometimes names its source, or the commentator who already reads it in the Mechaber's words; it notes neither all the sources nor all the divergences (see also Level 2).
    </p>'''
EN['points'] = [
    {
        'he_t': HE_T[0],
        't': "Point א — every person acquires his place of rest where the day became sanctified upon him, and one who is asleep on the road (Shulchan Aruch HaRav 401:1)",
        'id': 'the-place-where-the-day-became-sanctified',
        'h3': 'The place where the day became sanctified, and one who is asleep on the road',
        'meh': ("the seif opens with one who is asleep on the road when night falls on him: " + Qt('m1', SA) +
                " — he has acquired his place of rest where he is, and he has two thousand <em>amos</em> in every direction; and this only for a "
                "person, because, since had he been awake he would have acquired, asleep he also acquires."),
        'rav': Qt('r1', SAH1) + '. Then: ' + Qt('r2', SAH1) + '.',
        'diff': ("the Rav's text opens the seif with a general rule that the Mechaber's seif does not write here: every person acquires his "
                 "place of rest at the place where the day became sanctified upon him, although he did not say “my place of rest is where I "
                 "am”, since had he wanted he would have said it; and it then brings one who is asleep on the road with “and even”. For one "
                 "who is asleep, it adds " + Qt('r2a', SAH1) + " (if he is outside the <em>techum</em> of the city) and " + Qt('r2b', SAH1) +
                 " (although he had no intention at all of acquiring a place of rest). The Mechaber writes " + Qt('m1a', SA) +
                 " (and this only for a person); the Rav does not write these words, but writes, after the reason, " + Qt('r2c', SAH1) +
                 " (and all his belongings are like him), then sets against it, as the Mechaber does, ownerless objects (point ב)."),
        'comm': ("the Beis Yosef, before the Rav, reports that in the Gemara Rabbi Yehoshua ben Levi says that the halachah follows Rabbi Yochanan "
                 "ben Nuri, and that it follows the lenient view in matters of <em>eruv</em>, then this explanation of Rashi: " + Qt('byr', BY) +
                 " — it is for a person that the halachah follows him [Rabbi Yochanan ben Nuri]: since awake he acquires, asleep he also "
                 "acquires; but for objects, the halachah does not follow him. The Mishnah Berurah, after the Rav, explains the Mechaber's "
                 "reason: " + Qt('mb1', MB('א')) +
                 " — that is: although at twilight, which is the time of acquiring the place of rest, he was asleep and did not intend to "
                 "acquire his place of rest there, he nevertheless acquired his place of rest there, so as to have from there two thousand "
                 "<em>amos</em> in every direction; and it writes on belongings: " + Qt('mb2a', MB('ב')) +
                 " — for the belongings of a Jew, which have owners, are like the feet of the owners."),
    },
    {
        'he_t': HE_T[1],
        't': "Point ב — ownerless objects (Shulchan Aruch HaRav 401:1)",
        'id': 'ownerless-objects',
        'h3': 'Ownerless objects',
        'meh': (Qt('m2', SA) + " — but ownerless objects do not acquire a place of rest, and they are like the feet of the one who first "
                "takes possession of them, who may carry them to the place where he himself goes."),
        'rav': Qt('r3', SAH1) + '.',
        'diff': ("the ruling is the same in both texts. The Rav writes its reason, " + Qt('r3a', SAH1) +
                 " (they have no owners who could make them acquire a place of rest: they have not acquired a place of rest of themselves); "
                 "and he adds " + Qt('r3b', SAH1) + " (and even outside the <em>techum</em> of the city, if he made an <em>eruv</em> to there)."),
        'comm': ("the Mishnah Berurah, after the Rav, writes: " + Qt('mb2b', MB('ב')) +
                 " — but ownerless objects, which have no owners, did not of themselves acquire a place of rest where they are, because they "
                 "are never possessed of understanding (<em>bnei da'as</em>), and they are not like a sleeping person; and on the Mechaber's "
                 "words " + Qt('m2a', SA) + ": " + Qt('mb3', MB('ג')) +
                 " — and even if it is beyond the two thousand [<em>amos</em>] from the place where the objects were first lying. On the case "
                 "where two people took possession of them together, which neither the Mechaber's seif nor the Rav's writes, the views "
                 "diverge: see Level 2."),
    },
    {
        'he_t': HE_T[2],
        't': "Point ג — the objects of the non-Jew (Shulchan Aruch HaRav 401:1)",
        'id': 'the-objects-of-the-non-jew',
        'h3': 'The objects of the non-Jew',
        'meh': (Qt('m3', SA) + " — but the objects of the non-Jew acquire a place of rest where they are, although their owners are not "
                "subject to <em>shevisah</em>: a decree on the objects of the non-Jew on account of the objects of a Jew; and if a non-Jew "
                "took them out beyond their <em>techum</em> and brought them into a city, one may move them in all of it, for all of it is as "
                "four <em>amos</em>."),
        'rav': Qt('r4', SAH1) + '.',
        'diff': ("the ruling and its reason, the decree, are the same in both texts. The Rav writes explicitly " + Qt('r4a', SAH1) +
                 " (and if the non-Jew took them out beyond the <em>techum</em>, they have only four <em>amos</em>), which the Mechaber's seif "
                 "does not write in these words. For objects brought into the city, where the Mechaber writes " + Qt('m3a', SA) +
                 ", the Rav writes that their law is as [that of one whom] non-Jews took out beyond the <em>techum</em> and placed in the city, "
                 "for whom the whole city is reckoned as four <em>amos</em>, " + Qt('r4c', SAH1) +
                 " (since he went out under duress), and he refers to Siman 405; the condition that the city be enclosed for dwelling follows, "
                 "in both texts (point ד)."),
        'comm': ("the Beis Yosef, before the Rav, reports that this is a dispute of Shmuel and Rabbi Yochanan, and writes: " + Qt('by2', BY) +
                 " — and it was ruled there, in the Gemara: the halachah follows Rabbi Yochanan. The Mishnah Berurah, after the Rav, explains "
                 "the decree: " + Qt('mb5', MB('ה')) +
                 " — since in any case they have owners, if we said that they did not acquire a place of rest, people would come to say, also "
                 "of belongings whose owners are Jews, that they too did not acquire a place of rest, and would permit taking them out beyond "
                 "the two thousand [<em>amos</em>]; and it reads in the Mechaber's words " + Qt('m3b', SA) +
                 " what the Rav writes explicitly: " + Qt('mb6', MB('ו')) +
                 " — by law, objects that were taken out beyond their <em>techum</em> may be moved only within four <em>amos</em>; "
                 "nevertheless, in this city, which is enclosed by partitions, it is permitted to move [them] in all of it, for all of it is "
                 "reckoned as four <em>amos</em>. On the scope of “where they are” when the non-Jew himself was elsewhere, the views diverge: "
                 "see Level 2."),
    },
    {
        'he_t': HE_T[3],
        't': "Point ד — the city enclosed for dwelling (Shulchan Aruch HaRav 401:1)",
        'id': 'the-city-enclosed-for-dwelling',
        'h3': 'The city enclosed for dwelling',
        'meh': (Qt('m4', SA) + " — provided that it is enclosed for dwelling; and ordinary towns are enclosed for dwelling, for houses are "
                "built first and afterwards they are enclosed; but ordinary fortresses are not enclosed for dwelling."),
        'rav': Qt('r5', SAH1) + '. Then, in parentheses: ' + Qt('r6', SAH1) + '. And: ' + Qt('r7', SAH1) + '.',
        'diff': ("the condition is in both texts. The Rav writes that the city must be enclosed by partitions for dwelling, and he gives the "
                 "reason, " + Qt('r5a', SAH1) +
                 " (any place that is not enclosed for dwelling is not reckoned as four <em>amos</em>), referring to Siman 396. He adds in "
                 "parentheses what the Mechaber's seif does not write: one who rested in a city is not comparable, for whom the whole city is "
                 "reckoned as four <em>amos</em> even if it is not enclosed by partitions at all, because the two thousand [<em>amos</em>] are "
                 "measured for him only from the outermost house; but even for him, in the strict sense, only his house is reckoned as four "
                 "<em>amos</em>; whereas for one who goes out beyond the <em>techum</em>, the whole city is reckoned as four <em>amos</em> "
                 "only if it is enclosed by partitions for dwelling. The sentence on ordinary towns and fortresses is the same in both texts."),
        'comm': ("the Beis Yosef, before the Rav, explains the condition: " + Qt('by4', BY) +
                 " — that is: but if it was not enclosed, or enclosed not for dwelling, for example enclosed [first] and settled at the end, "
                 "it is not reckoned in its entirety as four <em>amos</em>, like the law of a <em>karpef</em> of more than two <em>beis "
                 "se'ah</em> that was not enclosed for dwelling, explained in Siman 358. The Mishnah Berurah, after the Rav: " +
                 Qt('mb7', MB('ז')) +
                 " — that houses were first built for dwelling, and afterwards they were enclosed with a wall all around; which is not so if "
                 "the enclosure came first: one may then move [objects] there only within four <em>amos</em>, if the enclosure was more than "
                 "two <em>beis se'ah</em>; and on fortresses: " + Qt('mb8', MB('ח')) +
                 " — for the way is to make the fortress first, and afterwards people settle in it to dwell. On the condition of the "
                 "enclosure itself, the views diverge: see Level 2."),
    },
    {
        'rama': True,
        'he_t': HE_T[4],
        't': "Point ה — belongings a Jew lent to a non-Jew that are returned to him on Shabbos (Shulchan Aruch HaRav 401:2)",
        'id': 'belongings-lent-to-a-non-jew',
        'h3': 'Belongings lent to a non-Jew',
        'meh': ("in his gloss, introduced by הגה at the end of the Mechaber's seif א: " + Qt('rama', RAMA) +
                " — therefore one must take care, when a Jew lent his belongings to a non-Jew and they were returned to him on Shabbos, not to "
                "move them beyond four <em>amos</em> if the city is not enclosed by a partition, for the belongings acquired their place of "
                "rest with the non-Jew (Or Zarua)."),
        'rav': Qt('r8', SAH2) + '.',
        'diff': ("the Rav writes this ruling in a seif of its own, seif ב, with the same degree, “one must take care” (<em>yesh "
                 "lizaher</em>), and, like the gloss, he opens it with " + Qt('r8d', SAH2) +
                 " (therefore); he does not write the reason the Rema gives, " + Qt('ramat', RAMA) + ". He specifies " + Qt('r8a', SAH2) +
                 " (not to move them in the city beyond four <em>amos</em> from the place where the non-Jew put them down), and adds an "
                 "example: " + Qt('r8c', SAH2) +
                 " (if one person moved them two <em>amos</em>, the second shall not move them more than two <em>amos</em>)."),
        'comm': ("the Mishnah Berurah, after the Rav, writes on the case of the loan: " + Qt('mb9', MB('ט')) +
                 " — on Erev Shabbos, and [the non-Jew] took them to his house, which is outside the <em>techum</em>: for although the "
                 "belongings are the Jew's, nevertheless, since he lent them to him, they acquired their place of rest with him; and all the "
                 "more so one who borrows belongings from a non-Jew on Shabbos; and on the prohibition of moving them: " +
                 Qt('mb10', MB('י')) +
                 " — that is, with clothing; for other belongings, in any case it is forbidden to move [them] on Shabbos beyond four "
                 "<em>amos</em>, since there is no <em>eruv</em>; and on Yom Tov the case arises even with other belongings, since there is "
                 "no prohibition of carrying out (<em>hotza'ah</em>) on it. These clarifications are the Mishnah Berurah's; the Rav's seif "
                 "does not write them."),
    },
    {
        'rama': True,
        'he_t': HE_T[5],
        't': "Point ו — the courtyard, and alleys fitted with a form of a doorway (Shulchan Aruch HaRav 401:2)",
        'id': 'the-courtyard-and-the-alleys',
        'h3': 'The courtyard, and fitted alleys',
        'meh': ("the Rema's gloss ends with the city that is not enclosed by a partition (point ה); it writes neither the courtyard nor the "
                "alleys (<em>mevo'os</em>)."),
        'rav': Qt('r9', SAH2) + '.',
        'diff': ("the Rav's text adds that, if he put them down in a courtyard, it is permitted to move them in all of the courtyard, which "
                 "is reckoned as four <em>amos</em>; that our alleys fitted with a form of a doorway (<em>tzuras hapesach</em>) are called "
                 "enclosed for dwelling, since houses are built first and afterwards the form of a doorway is made; and, in parentheses, that "
                 "the same applies if they are fitted with a side-post (<em>lechi</em>) or a crossbeam (<em>korah</em>)."),
        'comm': ("the Magen Avraham, before the Rav, writes on the Mechaber's words " + Qt('m4a', SA) + ": " + Qt('ma1', MA) +
                 " — and residents of open towns (<em>perazim</em>) who fitted the alleys according to their law with a form of a doorway "
                 "count as enclosed for dwelling, since houses are built first and afterwards the form of a doorway is made, as written in "
                 "Siman 358, seif 2; and see there, in seif 1, in the gloss, that if it is not enclosed for dwelling an <em>eruv</em> does "
                 "not help, for even [that] of a single person is forbidden. The Taz, before the Rav, writes on the Rema's gloss: " +
                 Qt('taz2a', TAZ) +
                 " — it seems to me that, if he brought it into an alley of Jews where our <em>eruv</em> is made, that is, a form of a "
                 "doorway, all of [the alley] is as four <em>amos</em>: for through this it is permitted to move [objects] from domain to "
                 "domain and in the alley itself, since we regard the whole alley as one domain; so too regarding what comes from outside the "
                 "<em>techum</em>, all of it is as four <em>amos</em>, and it is permitted to move it in the whole alley; he adds that this is "
                 "what emerges from the Rashal, whom he quotes, and concludes: " + Qt('taz2b', TAZ) +
                 " — and this alley, permitted by a form of a doorway, is like a single courtyard; so it seems clear in my humble opinion. "
                 "The Mishnah Berurah, after the Rav: " + Qt('mb7b', MB('ז')) +
                 " — and our open towns, since the alleys were fitted according to their law with a form of a doorway, are reckoned in their "
                 "entirety as enclosed for dwelling: the houses are like partitions, and the open places were fitted with a form of a "
                 "doorway, which makes them [enclosed] for dwelling, since houses are built first and afterwards the form of a doorway is "
                 "made; and a courtyard is always reckoned as four <em>amos</em>. These passages speak of the form of a doorway; the "
                 "side-post and the crossbeam, which the Rav adds in parentheses, are not named in them."),
    },
]
EN['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · Lemaaseh</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="the-practical-chabad-conduct">The practical Chabad conduct</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      Points of halachic conduct that flow directly from the Shulchan Aruch HaRav Siman 401, in the Chabad sensibility. Each point refers to its seif of the Rav, in the order of the text.
    </p>

    <div class="lemaaseh-block">
      <h3 id="for-the-chabad-chassid-siman-401">For the Chabad Chassid — Siman 401</h3>
      <ul>'''
EN['s4'] = [
    ("<strong>① The place where the day became sanctified:</strong> every person acquires his place of rest at the place where the day became "
     "sanctified upon him, and he has from there two thousand [<em>amos</em>] in every direction, even if he did not say “my place of rest is "
     "where I am”; and even one who is asleep on the road when night falls on him has acquired his place of rest where he is, if he is outside "
     "the <em>techum</em> of the city, although he had no intention at all of acquiring one; and all his belongings are like him (401:1). "
     "<em>Reference: Shulchan Aruch HaRav 401:1.</em>"),
    ("<strong>② Ownerless objects:</strong> they do not acquire a place of rest of themselves; they are like the feet of the one who first "
     "takes possession of them: he may carry them where he goes, and even outside the <em>techum</em> of the city, if he made an <em>eruv</em> "
     "to there (401:1). On the case where two people took possession of them together, the views diverge: see Level 2. <em>Reference: "
     "Shulchan Aruch HaRav 401:1.</em>"),
    ("<strong>③ The objects of the non-Jew:</strong> they acquire a place of rest where they are, by decree, on account of the objects of a "
     "Jew (on the scope of “where they are” when the non-Jew himself was elsewhere, the views diverge: see Level 2); if the non-Jew took them "
     "out beyond the <em>techum</em>, they have only four <em>amos</em>; if he brought them into the city, the whole city is reckoned as four "
     "<em>amos</em>, as for one whom non-Jews took out beyond the <em>techum</em> and placed in the city — provided that the city is enclosed "
     "by partitions for dwelling (on this condition, the views diverge: see Level 2); ordinary towns are enclosed for dwelling, ordinary "
     "fortresses are not (401:1). <em>Reference: Shulchan Aruch HaRav 401:1.</em>"),
    ("<strong>④ Belongings lent to a non-Jew:</strong> when a Jew lent his belongings to a non-Jew and they were returned to him on Shabbos, "
     "one must take care not to move them in the city beyond four <em>amos</em> from the place where the non-Jew put them down, if the city is "
     "not enclosed by partitions (on the condition of the enclosure, the views diverge: see Level 2); if one person moved them two "
     "<em>amos</em>, the second shall not move them more than two <em>amos</em> (401:2). What the Mishnah Berurah, after the Rav, writes on "
     "this case: section 2, point ה. <em>Reference: Shulchan Aruch HaRav 401:2.</em>"),
    ("<strong>⑤ The courtyard and the alleys:</strong> if he put them down in a courtyard (the belongings of point ④), it is permitted to move them in all of the "
     "courtyard, which is reckoned as four <em>amos</em>; our alleys fitted with a form of a doorway are called enclosed for dwelling, and the "
     "same applies if they are fitted with a side-post or a crossbeam: they are as four <em>amos</em> with regard to one who goes out beyond "
     "the <em>techum</em> (401:2). <em>Reference: Shulchan Aruch HaRav 401:2.</em>"),
]
EN['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 13px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ This section presents the Chabad halachic conduct. For any concrete question: <strong>consult your Rav</strong>.
      </p>
    </div>
  </section>
'''

CONTENU = {'fr': FR, 'he': HE, 'en': EN}
