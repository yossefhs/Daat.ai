#!/usr/bin/env python3
"""Assemble index{,-he,-en}.html du siman 401 : index publié de 397 (Te'houmin), champs remplacés un à un.
Chaque motif doit apparaître exactement le nombre de fois attendu ; l'hébreu des chapeaux est extrait de Sefaria.
Dérivé de s400/build400idx.py."""
import importlib.util, re, sys, pathlib
WT = pathlib.Path('/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9')
spec = importlib.util.spec_from_file_location('se', WT / 'scripts' / 'sefaria-extrait.py')
se = importlib.util.module_from_spec(spec); spec.loader.exec_module(se)

def extrait(w, s, k, frag):
    t = se.nettoyer(se.segments(w, s)[2][k - 1])
    occ = se.trouver(t, frag)
    if len(occ) != 1:
        raise SystemExit('extrait %s %s:%d « %s » : %d' % (w, s, k, frag, len(occ)))
    a, b = occ[0]
    return re.sub(r'<[^>]+>', '', t[a:b]).strip()

CHAP = extrait('SA', '401', 1, 'מי שישן בדרך וחשכה לו קונה אלפים אמה לכל רוח')
CHAP400 = extrait('SA', '400', 1, 'מי שישב לו בדרך לנוח ולא ידע אם הוא בתחום אם לאו')

C = {}
C[''] = dict(
 title="Siman 401 — Celui qui dormait en chemin à la tombée de la nuit, et la chevita des objets | Hilkhot Te'houmin",
 desc="Étude du Siman 401 du Choulhan Aroukh, Orah Haïm, Hilkhot Te'houmin : celui qui dormait en chemin quand la nuit est tombée a acquis la chevita à sa place, avec deux mille coudées dans chaque direction — et cela pour une personne seulement ; les objets sans propriétaire n'acquièrent pas la chevita : ils sont comme les pieds de celui qui les acquiert le premier (si deux les acquièrent ensemble, les avis divergent : niveau 2) ; les objets d'un non-Juif acquièrent la chevita, par décret (si le non-Juif lui-même se trouvait ailleurs, les avis divergent : niveau 2) ; sortis par un non-Juif hors de leur te'houm et apportés dans une ville, ils s'y déplacent dans toute la ville, pourvu qu'elle soit entourée pour l'habitation (sur cette condition, les avis divergent : niveau 2) ; la glose du Rama : il faut prendre garde de ne pas déplacer au-delà de quatre coudées les objets qu'un Juif a prêtés à un non-Juif et qui lui ont été rendus le Chabbat, si la ville n'est pas entourée d'une cloison (sur la condition de l'enceinte : niveau 2). 1 séif dans le Choul'han Aroukh du Mehaber, avec une glose du Rama introduite par הגה, et 2 dans le Choulhan Aroukh HaRav.",
 kw="siman 401, choulhan aroukh, hilkhot te'houmin, te'houm chabbat, chevita, kana chevita, deux mille coudées, celui qui dort en chemin, objets sans propriétaire, hefker, objets d'un non-Juif, ville entourée pour l'habitation, daat harav, admour hazaken, habad",
 sujet="Celui qui dormait en chemin à la tombée de la nuit, et la chevita des objets",
 og_suffix=" (Choulhan Aroukh)",
 sub="1 séif dans le Choul'han Aroukh du Mehaber, avec une glose du Rama introduite par הגה ; 2 dans le Choulhan Aroukh HaRav, sous sa propre numérotation (niveau 4). Celui qui dormait en chemin quand la nuit est tombée a acquis la chevita à sa place, avec deux mille coudées dans chaque direction — selon la Michna Beroura, bien qu'il n'eût pas l'intention de l'y acquérir — ; et cela pour une personne seulement, puisque, éveillée, elle l'aurait acquise. Les objets sans propriétaire n'acquièrent pas la chevita : ils sont comme les pieds de celui qui les acquiert le premier (si deux les acquièrent ensemble, les avis divergent : niveau 2). Les objets d'un non-Juif acquièrent la chevita, par décret, à cause des objets d'un Juif (si le non-Juif lui-même se trouvait ailleurs, les avis divergent : niveau 2) ; si un non-Juif les a sortis hors de leur te'houm et apportés dans la ville, on peut les y déplacer dans toute la ville, pourvu qu'elle soit entourée pour l'habitation (sur cette condition, les avis divergent : niveau 2). Le Rama ajoute : il faut prendre garde de ne pas déplacer au-delà de quatre coudées les objets qu'un Juif a prêtés à un non-Juif et qui lui ont été rendus le Chabbat, si la ville n'est pas entourée d'une cloison (sur la condition de l'enceinte : niveau 2).",
 n4="Le Choulhan Aroukh de l'Admour HaZaken sur ce siman : 2 séifim.",
 n4_old="Le Choulhan Aroukh de l'Admour HaZaken sur ce siman : 20 séifim.",
 prev='<a href="/oh/400/" class="prev">← Siman 400 — Celui qui s\'est assis en chemin sans savoir qu\'il était dans le te\'houm de la ville</a>',
 label_old='Siman 397', label_new='Siman 401',
)
C['-he'] = dict(
 title="סימן ת״א — %s | הלכות תחומין" % CHAP,
 desc="לימוד סימן ת״א בשולחן ערוך, אורח חיים, הלכות תחומין: מי שישן בדרך וחשכה לו קנה שביתה במקומו, ויש לו אלפים אמה לכל רוח — ודוקא באדם; חפצי הפקר אינם קונים שביתה: הם כרגלי הזוכה בהם תחילה (אם זכו בהם שנים יחד — הדעות חלוקות: רמה 2); חפצי העכו״ם קונים שביתה, גזירה (אם העכו״ם עצמו היה במקום אחר — הדעות חלוקות: רמה 2); הוציאם עכו״ם חוץ לתחומם והביאם לעיר — מטלטלים אותם בכל העיר, ובלבד שתהא מוקפת לדירה (בתנאי זה הדעות חלוקות: רמה 2); הגהת הרמ״א: יש ליזהר שלא לטלטל חוץ לארבע אמות כלים שהשאילם ישראל לעכו״ם והוחזרו לו בשבת, אם אין העיר מוקפת מחיצה (בתנאי ההיקף: רמה 2). סעיף אחד בשולחן ערוך של המחבר, עם הגהת רמ״א הפותחת במילה הגה, ושני סעיפים בשולחן ערוך הרב.",
 kw="סימן ת״א, שולחן ערוך, הלכות תחומין, תחום שבת, שביתה, קנה שביתה, אלפים אמה, ישן בדרך, חפצי הפקר, חפצי עכו״ם, מוקפת לדירה, דעת הרב, אדמו״ר הזקן, חב״ד",
 sujet=CHAP,
 og_suffix=" (שולחן ערוך)",
 h1="מי שישן בדרך וחשכה לו, ושביתת החפצים",
 sub="סעיף אחד בשולחן ערוך של המחבר, עם הגהת רמ״א הפותחת ב«הגה»; שני סעיפים בשולחן ערוך הרב, במספור משלו (רמה 4). מי שישן בדרך וחשכה לו קנה שביתה במקומו, ויש לו אלפים אמה לכל רוח — לפי המשנה ברורה, אף שלא נתכוון לקנות שם —; ודוקא באדם, שהרי אילו היה ער היה קונה. חפצי הפקר אינם קונים שביתה: הם כרגלי הזוכה בהם תחילה (אם זכו בהם שנים יחד — הדעות חלוקות: רמה 2). חפצי העכו״ם קונים שביתה, גזירה מפני חפצי ישראל (אם העכו״ם עצמו היה במקום אחר — הדעות חלוקות: רמה 2); ואם הוציאם עכו״ם חוץ לתחומם והביאם לעיר, מטלטלים אותם בכל העיר, ובלבד שתהא מוקפת לדירה (בתנאי זה הדעות חלוקות: רמה 2). הרמ״א מוסיף: יש ליזהר שלא לטלטל חוץ לארבע אמות כלים שהשאילם ישראל לעכו״ם והוחזרו לו בשבת, אם אין העיר מוקפת מחיצה (בתנאי ההיקף: רמה 2).",
 n4="שולחן ערוך הרב על סימן זה: שני סעיפים.",
 n4_old="שולחן ערוך הרב על סימן זה: כ׳ סעיפים.",
 prev='<a href="/oh/400/he" class="prev">סימן ת׳ · 400 — %s →</a>' % CHAP400,
 label_old='סימן שצ״ז', label_new='סימן ת״א',
)
C['-en'] = dict(
 title="Siman 401 — One who was asleep on the way when night fell, and the shevisah of objects | Hilchos Techumin",
 desc="Study of Siman 401 of the Shulchan Aruch, Orach Chaim, Hilchos Techumin: one who was asleep on the way when night fell acquired his shevisah in his place, with two thousand amos in every direction — and this only for a person; ownerless objects do not acquire shevisah: they are like the feet of the one who first acquires them (if two acquire them together, the opinions differ: Level 2); the objects of a non-Jew acquire shevisah, by decree (if the non-Jew himself was elsewhere, the opinions differ: Level 2); taken out by a non-Jew beyond their techum and brought into a city, they may be moved in the whole city, provided that it is enclosed for dwelling (on this condition, the opinions differ: Level 2); the Rema's gloss: one must take care not to move beyond four amos objects that a Jew lent to a non-Jew and that were returned to him on Shabbos, if the city is not enclosed by a partition (on the condition of the enclosure: Level 2). 1 seif in the Shulchan Aruch of the Mechaber, with a gloss of the Rema introduced by הגה, and 2 in the Shulchan Aruch HaRav.",
 kw="siman 401, shulchan aruch, hilchos techumin, techum shabbos, shevisah, kanah shevisah, two thousand amos, asleep on the way, ownerless objects, hefker, objects of a non-Jew, enclosed for dwelling, daat harav, alter rebbe, chabad",
 sujet="One who was asleep on the way when night fell, and the shevisah of objects",
 og_suffix=" (Shulchan Aruch)",
 sub="1 seif in the Shulchan Aruch of the Mechaber, with a gloss of the Rema introduced by הגה; 2 in the Shulchan Aruch HaRav, under its own numbering (Level 4). One who was asleep on the way when night fell acquired his shevisah in his place, with two thousand amos in every direction — according to the Mishnah Berurah, even though he did not intend to acquire it there —; and this only for a person, since, awake, he would have acquired it. Ownerless objects do not acquire shevisah: they are like the feet of the one who first acquires them (if two acquire them together, the opinions differ: Level 2). The objects of a non-Jew acquire shevisah, by decree, on account of the objects of a Jew (if the non-Jew himself was elsewhere, the opinions differ: Level 2); if a non-Jew took them out beyond their techum and brought them into the city, they may be moved in the whole city, provided that it is enclosed for dwelling (on this condition, the opinions differ: Level 2). The Rema adds: one must take care not to move beyond four amos objects that a Jew lent to a non-Jew and that were returned to him on Shabbos, if the city is not enclosed by a partition (on the condition of the enclosure: Level 2).",
 n4="The Shulchan Aruch HaRav of the Alter Rebbe on this siman: 2 seifim.",
 n4_old="The Shulchan Aruch HaRav of the Alter Rebbe on this siman: 20 seifim.",
 prev='<a href="/oh/400/en" class="prev">← Siman 400 — One who sat on the road without knowing he was within the city\'s techum</a>',
 label_old='Siman 397', label_new='Siman 401',
)

def sub1(t, motif, valeur, n=1):
    k = len(re.findall(motif, t))
    if k != n:
        raise SystemExit('motif %r : %d (attendu %d)' % (motif, k, n))
    return re.sub(motif, lambda m: valeur, t)

def construire(suf):
    c = C[suf]
    for v in c.values():
        if '"' in v and not v.startswith('<a '):
            raise SystemExit('guillemet ASCII dans %r' % v[:60])
    t = (WT / 'sources/shabbat/siman-397' / ('index%s.html' % suf)).read_text(encoding='utf-8')
    sujet = c['sujet']
    lab = c['label_new'] if suf == '-he' else 'Siman 401'
    t = sub1(t, r'<title>[^<]*</title>', '<title>%s</title>' % c['title'])
    t = sub1(t, r'<meta name="description" content="[^"]*">', '<meta name="description" content="%s">' % c['desc'])
    t = sub1(t, r'<meta name="keywords" content="[^"]*">', '<meta name="keywords" content="%s">' % c['kw'])
    t = sub1(t, r'<meta property="og:title" content="[^"]*">', '<meta property="og:title" content="%s — %s%s">' % (lab, sujet, c['og_suffix']))
    t = sub1(t, r'<meta property="og:description" content="[^"]*">', '<meta property="og:description" content="%s">' % c['desc'])
    t = sub1(t, r'<meta name="twitter:title" content="[^"]*">', '<meta name="twitter:title" content="%s — %s">' % (lab, sujet))
    t = sub1(t, r'<meta name="twitter:description" content="[^"]*">', '<meta name="twitter:description" content="%s">' % c['desc'])
    t = sub1(t, r'"headline": "[^"]*"', '"headline": "%s — %s"' % (lab, sujet))
    t = sub1(t, r'"alternativeHeadline": "[^"]*"', '"alternativeHeadline": "%s"' % CHAP)
    t = sub1(t, r'"description": "(?:Étude du Siman|לימוד סימן|Study of Siman)[^"]*"', '"description": "%s"' % c['desc'])
    t = sub1(t, r'"keywords": "[^"]*"', '"keywords": "%s"' % c['kw'])
    t = sub1(t, r'<div class="daat-hero-siman"><span class="daat-hero-siman-he">[^<]*</span><span class="daat-hero-siman-num">[^<]*</span></div>',
             '<div class="daat-hero-siman"><span class="daat-hero-siman-he">סימן ת״א</span><span class="daat-hero-siman-num">Siman 401</span></div>')
    t = sub1(t, r'<p class="daat-hero-title-he" aria-hidden="true">[^<]*</p>', '<p class="daat-hero-title-he" aria-hidden="true">%s</p>' % CHAP)
    t = sub1(t, r'<h1 class="daat-hero-title-fr" style="margin: 0;">[^<]*</h1>', '<h1 class="daat-hero-title-fr" style="margin: 0;">%s</h1>' % c.get('h1', sujet))
    t = sub1(t, r'<p class="daat-hero-subtitle">[^<]*</p>', '<p class="daat-hero-subtitle">%s</p>' % c['sub'])
    if t.count(c['n4_old']) != 1:
        raise SystemExit('carte N4 : %r' % c['n4_old'])
    t = t.replace(c['n4_old'], c['n4'])
    t = sub1(t, r'<a href="/oh/396/[^"]*" class="prev">[^<]*</a>', c['prev'])
    t = t.replace('/oh/397/', '/oh/401/').replace('siman-397.png', 'siman-401.png')
    t = t.replace('"%s"' % c['label_old'], '"%s"' % c['label_new'])
    t = t.replace('<span class="current">%s</span>' % c['label_old'], '<span class="current">%s</span>' % c['label_new'])
    for ln, l in enumerate(t.split('\n'), 1):
        if re.search(r'39[6-9]|שצ״[זוחט]|\b400\b|ת׳', l):
            print('  [voisin] %s l.%d : %s' % (suf or 'fr', ln, l.strip()[:160]), file=sys.stderr)
    out = WT / 'sources/shabbat/siman-401' / ('index%s.html' % suf)
    out.write_text(t, encoding='utf-8')
    print('écrit', out, len(t))

if __name__ == '__main__':
    for suf in [x if x != 'fr' else '' for x in (sys.argv[1:] or ['fr', '-he', '-en'])]:
        construire(suf)
