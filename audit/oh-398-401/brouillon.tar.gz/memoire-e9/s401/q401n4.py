# Extraits de source du niveau 4 du siman 401 (rien n'est retapé : sefaria-extrait.py).
import os, subprocess, sys
WT = '/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9'
EX = os.path.join(WT, 'scripts', 'sefaria-extrait.py')
N = 401


def run(args):
    r = subprocess.run([sys.executable, EX] + args, capture_output=True, text=True, cwd=WT)
    if r.returncode != 0:
        raise SystemExit('ECHEC extraction %r : %s %s' % (args, r.stdout, r.stderr))
    return r.stdout.strip()


def seif(w, k, siman=None):
    return run(['seif', w, str(siman or N), str(k)])


def ex(w, k, debut=None, fin=None, frag=None, ref=None):
    siman = ref if ref else str(N)
    a = ['extrait', w, siman, str(k)]
    if frag:
        a.append(frag)
    else:
        a += ['--debut', debut, '--fin', fin]
    s = run(a)
    if s.count('(') > s.count(')'):
        s += ')'
    return s


SPEC = {
    # Mehaber et Rama (Maginei Eretz)
    'm1': ('SA', 1, 'קנה שביתה במקומו', 'ישן נמי קונה'),
    'm1a': ('SA', 1, None, None, 'ודוקא באדם'),
    'm2': ('SA', 1, 'אבל חפצי הפקר', 'למקום שילך הוא'),
    'm2a': ('SA', 1, None, None, 'למקום שילך הוא'),
    'm3': ('SA', 1, 'אבל חפצי העכו״ם', 'שכולה כארבע אמות'),
    'm3a': ('SA', 1, None, None, 'יכולים לטלטל בכולה שכולה כארבע אמות'),
    'm3b': ('SA', 1, None, None, 'שכולה כארבע אמות'),
    'm4a': ('SA', 1, None, None, 'ובלבד שתהא מוקפת לדירה'),
    'm4': ('SA', 1, 'ובלבד שתהא', 'אינם מוקפים לדירה'),
    'rama': ('SA', 1, 'ולכן יש ליזהר', 'א״ז'),
    'ramat': ('SA', 1, None, None, 'שהרי הכלים קנו שביתה אצל העכו״ם'),
    # Rav (Kehot vocalisée)
    'r1': ('SAH', 1, 'כל אדם קונה', 'כמו שאמר'),
    'r2': ('SAH', 1, 'ואפלו מי שישן', 'וכל חפציו כמהו'),
    'r2a': ('SAH', 1, None, None, 'אם הוא חוץ לתחום העיר'),
    'r2b': ('SAH', 1, 'אף על פי שלא נתכון', 'לקנות שביתה כלל'),
    'r2c': ('SAH', 1, None, None, 'וכל חפציו כמהו'),
    'r3': ('SAH', 1, 'אבל חפצי הפקר', 'אם ערב לשם'),
    'r3a': ('SAH', 1, 'שאין להם בעלים', 'לא קנו שביתה מאליהם'),
    'r3b': ('SAH', 1, None, None, 'ואפלו חוץ לתחום העיר אם ערב לשם'),
    'r4': ('SAH', 1, 'אבל חפצי הנכרי', 'בסמן ת״ה'),
    'r4a': ('SAH', 1, 'ואם הוציאם הנכרי', "אלא ד' אמות"),
    'r4b': ('SAH', 1, 'אלא שאם הביאם לעיר', 'בסמן ת״ה'),
    'r4c': ('SAH', 1, None, None, 'הואיל ויצא באנס'),
    'r5': ('SAH', 1, 'והוא שתהא העיר', 'בסמן שצ״ו'),
    'r5a': ('SAH', 1, 'שכל מקום שאינו', "אינו נחשב כד' אמות"),
    'r6': ('SAH', 1, 'ואינו דומה לשבת בעיר', 'עד שתהא מקפת מחצות לדירה'),
    'r7': ('SAH', 1, 'וסתם עירות', 'אינן מקפים לדירה'),
    'r8': ('SAH', 2, 'ולכן יש לזהר', "יותר מב' אמות"),
    'r8a': ('SAH', 2, 'שלא לטלטלם בעיר', 'שהניחם שם הנכרי'),
    'r8c': ('SAH', 2, 'כגון אם טלטלם', "יותר מב' אמות"),
    'r8d': ('SAH', 2, None, None, 'ולכן'),
    'r9': ('SAH', 2, 'אבל אם הניחם בחצר', 'שמתר לטלטל בכלם'),
    # Commentateurs
    'mb1': ('MB', 1, 'ר״ל דאף', 'אלפים אמה לכל רוח'),
    'mb2a': ('MB', 2, None, None, 'דחפצי ישראל שיש להם בעלים הם כרגלי הבעלים'),
    'mb2b': ('MB', 2, 'אבל חפצי הפקר', 'ולא דמו לאדם ישן'),
    'mb3': ('MB', 3, 'ואף שהוא חוץ', 'מתחלה'),
    'mb5': ('MB', 5, 'כיון דעכ״פ', 'חוץ לאלפים'),
    'mb6': ('MB', 6, 'דמן הדין', 'דנחשבת כולה כד״א'),
    'mb7': ('MB', 7, 'שבנו תחלה', 'יותר מבית סאתים'),
    'mb7b': ('MB', 7, 'וערים הפרזים', 'וחצר לעולם חשוב כד״א'),
    'mb8': ('MB', 8, 'דדרך הוא', 'אנשים לדור'),
    'mb9': ('MB', 9, 'מערב שבת', 'מן העכו״ם בשבת'),
    'mb10': ('MB', 10, 'היינו במלבושים', 'איסור הוצאה'),
    'byr': ('BY', 1, 'באדם הוא דהלכתא', 'לית הלכתא כוותיה'),
    'by2': ('BY', 2, None, None, 'ואיפסיקא שם בגמרא הלכתא כר״י'),
    'by4': ('BY', 4, 'כלומר אבל אם', 'שנתבאר בסימן שנ״ח'),
    'ma1': ('MA', 1, 'ויושבי פרזים', 'אסור'),
    'taz2a': ('TAZ', 2, 'נ״ל דאם הביאו', 'ומותר לטלטלו בכל המבוי'),
    'taz2b': ('TAZ', 2, 'וזה המבוי', 'כנלע״ד ברור'),
}


def charger():
    Q = {}
    for k, v in SPEC.items():
        if len(v) == 5:
            Q[k] = ex(v[0], v[1], frag=v[4])
        else:
            Q[k] = ex(v[0], v[1], v[2], v[3])
    return Q


if __name__ == '__main__':
    for k, v in charger().items():
        print(k, '=>', v)
