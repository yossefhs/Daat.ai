#!/usr/bin/env python3
"""Assemble le niveau 4 du siman 399 (FR, HE, EN) sur la charpente du 398 (CSS de 365 à l'octet).
Tout l'hébreu de source est EXTRAIT par scripts/sefaria-extrait.py ; rien n'est retapé."""
import os, re, subprocess, sys

WT = '/tmp/claude-0/-home-user-Daat-ai/7d493fdf-7647-52e4-bf6b-12b6742d003b/scratchpad/wt-e9'
EX = os.path.join(WT, 'scripts', 'sefaria-extrait.py')
SRC = os.path.join(WT, 'sources', 'shabbat', 'siman-398')
DST = os.path.join(WT, 'sources', 'shabbat', 'siman-399')
N = 399


def run(args):
    r = subprocess.run([sys.executable, EX] + args, capture_output=True, text=True, cwd=WT)
    if r.returncode != 0:
        raise SystemExit('ECHEC extraction %r : %s %s' % (args, r.stdout, r.stderr))
    return r.stdout.strip()


def seif(w, k):
    return run(['seif', w, str(N), str(k)])


def ex(w, k, debut=None, fin=None, frag=None, ref=None):
    siman = ref if ref else str(N)
    a = ['extrait', w, siman, str(k)]
    if frag:
        a.append(frag)
    else:
        a += ['--debut', debut, '--fin', fin]
    s = run(a)
    if s.count('(') > s.count(')'):
        s += ')'
    return s


Q = {
    'm_a': ex('SA', 1, 'אין מודדין', 'כראוי'),
    'r_a': ex('SAH', 1, 'לא פחות', 'מדת התחום'),
    'm_b': ex('SA', 2, 'אם יש נהר', 'עד הנהר'),
    'r_b': ex('SAH', 2, 'נהר שהוא רחב', 'חמשים מהעיר'),
    'mb_c': ex('MB', 3, frag='שהוא רחב יותר מכ״ה אמה'),
    'm_c': ex('SA', 3, 'ישים החבל', 'בכל כחו'),
    'r_c1': ex('SAH', 3, 'לא ימדוד', 'מתמעטין'),
    'r_c2': ex('SAH', 4, 'מפני שהוא', 'באמצעיתו'),
    'mish_c': ex('REF', 4, frag='ולא ימדוד אלא כנגד לבו', ref='Mishnah_Eruvin.5'),
    'm_d': ex('SA', 4, 'לא ימדוד אלא כנגד', 'אלא ימדוד כנגד העיר'),
    'r_d': ex('SAH', 5, 'אלא ימדוד כנגד העיר', 'שיתבאר'),
    'm_e': ex('SA', 4, 'אז אין צריך', 'אינו מודד כלל'),
    'r_e': ex('SAH', 6, 'אין צריך למדוד כלל', 'אף על פי שיכול להבליעו בחבל של נ\' אמה'),
    'mb_e': ex('MB', 10, frag='ר״ל שימדוד המישור שלמעלה לבד'),
    'm_f': ex('SA', 4, 'ואם חוט מתרחק', 'עשרה טפחי\''),
    'r_f': ex('SAH', 6, 'ואם חוט המשקלת', 'י\' טפחים בגבה'),
    'm_g': ex('SA', 4, 'ואם הוא משופע', 'של ארבע אמות'),
    'r_g': ex('SAH', 7, 'כיון שאם לא היה', 'כלו בחבל של ד\' אמות'),
    'm_h': ex('SA', 5, 'הגיע לגיא', 'ואפי\' אם עמוק יותר מאלפים'),
    'r_h1': ex('SAH', 8, 'וכל זה בהר', 'ונעשה כהר'),
    'r_h2': ex('SAH', 8, 'צריך להבליעו ולא', 'עצים כלל'),
    'm_i': ex('SA', 6, 'אבל אם אינו יכול', 'כדי להבליעו'),
    'r_i': ex('SAH', 9, 'לא יתרחק יותר', 'באה לכאן'),
    'm_j': ex('SA', 8, 'שומעין לו', 'אף בתחום שריבה'),
    'r_j': ex('SAH', 11, 'שומעים לו אף', 'בכל כחו'),
    'm_k': ex('SA', 8, 'מדד ומצא', 'שריבה בו'),
    'r_k1': ex('SAH', 12, 'ואין אומרים', 'שיש שם'),
    'r_k2': ex('SAH', 12, 'ויש אומרים', 'כסברא הראשונה'),
    'r_k3': ex('SAH', 12, frag='והעקר כסברא הראשונה'),
    'r_yo': ex('SAH', 12, frag='ויש אומרים'),
    'm_l': ex('SA', 9, 'שומעין למרב', 'אלכסונה של עיר'),
    'r_l1': ex('SAH', 13, 'שומעין למרבה', 'קרן העיר'),
    'r_l2': ex('SAH', 13, 'ולפיכך אם רבה', 'אין שומעים לו'),
    'r_l3': ex('SAH', 13, 'אבל לפי חשבון', 'אמה בקרוב'),
    'm_m': ex('SA', 10, 'שא״כ מפסיד', 'אלף ותכ״ח'),
    'r_m': ex('SAH', 14, 'וגם לא יהיה', 'ותט״ו'),
    'm_n': ex('SA', 11, 'אפילו עבד', 'על עדותו'),
    'r_n1': ex('SAH', 15, 'אפלו עבד', 'נאמנים'),
    'r_n2': ex('SAH', 15, 'שלא אמרו', 'אלא להקל'),
    'mish_n': ex('REF', 5, 'שלא אמרו', 'אלא להקל', ref='Mishnah_Eruvin.5'),
    'mb_29': ex('MB', 29, 'ופשוט דמיירי', 'ולא כשממעט'),
    'mb_39': ex('MB', 39, 'ואם אירע', 'ולברר הדבר'),
    'w_misof': ex('SAH', 13, frag='חוט מסוף').split()[-1],
    'w_metsela': ex('SAH', 13, frag='מצלע העיר').split()[0],
}


assert "עשרה טפחי'" in seif('SA', 4)
Q['m_f'] += "'"


def q(s):
    def rep(m):
        return Q[m.group(1)]
    out = re.sub(r'\[\[(\w+)\]\]', rep, s)
    assert '[[' not in out, out
    return out


# ---------------------------------------------------------------- section 1 : le texte du Rav
SEIFS = []
for k in range(1, 16):
    t = seif('SAH', k)
    t = t.replace('<b>', '').replace('</b>', '')
    t = t.replace('<br>', '<br><br>')
    SEIFS.append(t)
PREV_N = [14, 7, 5, 5, 5, 8, 10, 5, 4, 7, 5, 5, 7, 6, 4]
LETTRES = ['א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ז', 'ח', 'ט', 'י', 'יא', 'יב', 'יג', 'יד', 'טו']


def apercu(t, n):
    plain = re.sub(r'<[^>]+>', ' ', t)
    mots = plain.split()
    pris = mots[:n]
    pris[-1] = pris[-1].rstrip(',;:.—')
    return ' '.join(pris) + '…'


PREVIEWS = [apercu(SEIFS[i], PREV_N[i]) for i in range(15)]
CHAPEAU = SEIFS[0].split(':<br>')[0]  # « בַּמֶּה … וּבוֹ ט״ו סְעִיפִים »
CHAP_SANS_COMPTE = CHAPEAU.rsplit(' וּבוֹ ', 1)[0]
COMPTE = 'וּבוֹ ' + CHAPEAU.rsplit(' וּבוֹ ', 1)[1]

exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'contenu399n4.py'), encoding='utf-8').read())


def bloc(i, trad_cls, trad):
    ouvert = ' open' if i == 0 else ''
    s = ('    <details class="seif-details"%s>\n'
         '      <summary class="seif-summary">\n'
         '        <span class="seif-num">סעיף %s</span>\n'
         '        <span class="seif-preview">%s</span>\n'
         '      </summary>\n'
         '      <div class="sa-block">\n'
         '        <p class="sa-he">%s</p>\n') % (ouvert, LETTRES[i], PREVIEWS[i], SEIFS[i])
    if trad_cls:
        s += '        <p class="%s">%s</p>\n' % (trad_cls, trad)
    s += '      </div>\n    </details>\n'
    return s


def points(lang, pts):
    out = []
    h3font = "'Frank Ruhl Libre', serif" if lang == 'he' else "'Cormorant Garamond', serif"
    lab = LABELS[lang]
    for p in pts:
        s = '    <div class="sa-block">\n'
        s += '      <p class="sa-he" style="font-size: 19px; font-weight: 700; margin-bottom: 12px; color: var(--habad-deep);">%s</p>\n' % p['he_t']
        if lang != 'he':
            s += '      <p class="sa-%s">%s</p>\n' % (lang, p['t'])
        s += ('      <h3 style="font-family: %s; font-size: 19px; font-weight: 600; color: var(--navy); margin-bottom: 10px;" id="%s">%s</h3>\n'
              % (h3font, p['id'], p['h3']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['rama' if p.get('rama') else 'meh'], q(p['meh']))
        s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['rav'], q(p['rav']))
        if p.get('comm'):
            s += '      <p style="margin-bottom: 10px;"><strong>%s</strong> %s</p>\n' % (lab['diff'], q(p['diff']))
            s += '      <p><strong>%s</strong> %s</p>\n' % (lab['comm'], q(p['comm']))
        else:
            s += '      <p><strong>%s</strong> %s</p>\n' % (lab['diff'], q(p['diff']))
        s += '    </div>\n'
        out.append(s)
    return '\n'.join(out)


def construire(lang):
    suf = {'fr': '', 'he': '-he', 'en': '-en'}[lang]
    C = CONTENU[lang]
    T = open(os.path.join(SRC, 'niveau-4-daat-harav%s.html' % suf), encoding='utf-8').read()
    i_hero = T.index('<div class="page-hero">')
    m3 = re.search(r'\n  <!-- 3\. ', T)
    i_s3 = m3.start() + 1
    i_s4 = T.index('    <!-- 4. LEMAASEH')
    i_nav = T.index('<nav class="niveau-nav"')
    A, B, Cc = T[:i_hero], T[i_s3:i_s4], T[i_nav:]

    def fix(x):
        x = x.replace('/oh/398/', '/oh/399/').replace('/oh/397/', '/oh/398/')
        x = x.replace('siman-398.png', 'siman-399.png')
        x = x.replace('Siman 398', 'Siman 399').replace('Siman 397', 'Siman 398')
        x = x.replace('siman-398', 'siman-399')
        x = x.replace('סימן שצ״ח · 398', 'סימן שצ״ט · 399')
        x = x.replace('שצ״ח', 'שצ״ט').replace('שצ-ח', 'שצ-ט')
        x = x.replace('סימן שצ״ז · 397', 'סימן שצ״ח · 398')
        x = x.replace('שצ״ז', 'שצ״ח')
        return x

    A = fix(A)
    A = re.sub(r'<title>.*?</title>', '<title>%s</title>' % C['title'], A, count=1)
    A = re.sub(r'<meta name="description" content="[^"]*">', '<meta name="description" content="%s">' % C['desc'], A, count=1)
    A = re.sub(r'<meta property="og:description" content="[^"]*">', '<meta property="og:description" content="%s">' % C['og'], A, count=1)
    A = re.sub(r'<meta name="twitter:description" content="[^"]*">', '<meta name="twitter:description" content="%s">' % C['tw'], A, count=1)
    A = re.sub(r'"headline": "[^"]*"', '"headline": "%s"' % C['title'], A, count=1)
    A = re.sub(r'"description": "[^"]*"', '"description": "%s"' % C['ld'], A, count=1)
    B = fix(B)
    Cc = fix(Cc)

    s1 = ''.join(bloc(i, C['trad_cls'], C['trads'][i] if C['trad_cls'] else None) for i in range(15))
    corps = C['hero'] + '\n<main>\n\n' + C['intro'] + '\n' + C['s1_head'] + '\n' + s1 + '\n' + C['s1_source'] + '\n  </section>\n\n'
    corps += C['s2_head'] + '\n' + points(lang, C['points']) + '\n  </section>\n\n'
    s4 = C['s4_head'] + '\n' + '\n'.join('        <li>%s</li>' % q(li) for li in C['s4']) + '\n' + C['s4_foot']
    out = A + corps + B + s4 + '\n' + Cc
    os.makedirs(DST, exist_ok=True)
    with open(os.path.join(DST, 'niveau-4-daat-harav%s.html' % suf), 'w', encoding='utf-8') as f:
        f.write(out)
    # résidus
    for mot in ('398', 'שצ״ח', '397', 'שצ״ז', '[[', ']]'):
        for m in re.finditer(re.escape(mot), out):
            ligne = out[max(0, m.start() - 60):m.end() + 30].replace('\n', ' ')
            if 'nav-prev' in ligne:
                continue
            print('RESIDU', lang, mot, '…', ligne)
    print('écrit', lang, len(out))


for L in ('fr', 'he', 'en'):
    construire(L)
