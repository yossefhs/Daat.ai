# Contenu du niveau 4 du siman 399 — exécuté par build399n4.py (CHAP_SANS_COMPTE, COMPTE, Q disponibles).
# Aucun mot d'hébreu de source n'est tapé ici : les citations sont des [[clés]] de Q (extraites de Sefaria).

LABELS = {
    'fr': {'meh': "Ce qu'écrit le Mehaber :", 'rama': "Ce qu'écrit le Rama :", 'rav': "Ce qu'écrit le Rav :",
           'diff': 'La différence :', 'comm': 'Chez les commentateurs :'},
    'he': {'meh': 'דברי המחבר:', 'rama': 'דברי הרמ״א:', 'rav': 'דברי הרב:', 'diff': 'ההבדל:', 'comm': 'אצל המפרשים:'},
    'en': {'meh': 'What the Mechaber writes:', 'rama': 'What the Rema writes:', 'rav': 'What the Rav writes:',
           'diff': 'The difference:', 'comm': 'Among the commentators:'},
}

NB = '&nbsp;'


def g(k):
    """citation entre guillemets français, espaces insécables"""
    return '«' + NB + '[[' + k + ']]' + NB + '»'


CHAP_LIGNE = 'סימן שצ״ט — ' + CHAP_SANS_COMPTE + ' — ' + COMPTE

# ============================================================================ FRANÇAIS
FR = {}
FR['title'] = "Siman שצ״ט · Niveau 4 — Chitah de l'Admour HaZaken : avec quoi l'on mesure les limites, où l'on mesure et qui mesure | Hilkhot Te'houmin"
FR['desc'] = ("Niveau 4 (Daat HaRav) du Siman שצ״ט — avec quoi l'on mesure les limites (te'houmin) de Chabbat, où l'on mesure et qui mesure : "
              "le cordeau de lin de cinquante amot, le fleuve, le cordeau au niveau du cœur et tendu de toute sa force, la mesure face à la ville, "
              "la montagne et sa pente, le mur et la vallée, la mesure sur le côté, l'expert et les limites établies, la ligne oblique, deux experts, "
              "la limite carrée et ses angles, qui est cru sur la limite. Le texte intégral des 15 séifim du Choulhan Aroukh de l'Admour HaZaken, "
              "leur traduction, ce en quoi le texte du Rav diffère des séifim du Mehaber et du Rama, la conduite pratique.")
FR['og'] = ("La chitah de l'Admour HaZaken sur la mesure des limites de Chabbat : le cordeau, la montagne, le mur et la vallée, "
            "l'expert qui mesure, la limite carrée et le témoignage sur la limite.")
FR['tw'] = "Chitah de l'Admour HaZaken : avec quoi l'on mesure les limites de Chabbat, où l'on mesure et qui mesure."
FR['ld'] = ("Niveau 4 (Daat HaRav) du Siman שצ״ט : avec quoi l'on mesure les limites de Chabbat, où l'on mesure et qui mesure, "
            "dans le Choulhan Aroukh de l'Admour HaZaken.")
FR['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">Orah Haïm שצ״ט · Niveau 4 · שיטת אדמו״ר הזקן</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">Daat HaRav — Le Choulhan Aroukh de l'Admour HaZaken sur le Siman שצ״ט</h1>
    <p class="hero-subtitle">Avec quoi l'on mesure les limites (<em>te'houmin</em>), où l'on mesure et qui mesure : le cordeau de lin de cinquante amot ; le fleuve au bout de soixante-quinze amot ; le cordeau au niveau du cœur, tendu de toute sa force ; la mesure face à la ville ; la montagne escarpée, la pente et la mesure au cordeau de quatre amot ; le mur et la vallée ; la montagne ou la vallée qu'on absorbe sur le côté ; l'expert, les limites établies et la ligne oblique ; deux experts qui ne s'accordent pas ; la limite carrée et ses angles ; qui est cru sur la limite. Les 15 séifim du Choulhan Aroukh de l'Admour HaZaken ; le Choul'han Aroukh du Mehaber en compte 11.</p>
  </div>
</div>
'''
FR['intro'] = '''  <div class="intro-block">
    <p><strong>Pourquoi un niveau 4 dédié à l'Admour HaZaken ?</strong> Le <strong>Choulhan Aroukh de l'Admour HaZaken</strong> n'est pas un commentaire sur le Mehaber (מחבר) : c'est un Choulhan Aroukh à part entière, écrit par l'Admour HaZaken, avec sa propre découpe et sa propre numérotation des séifim. Ici, le Choulhan Aroukh HaRav annonce 15 séifim en tête du siman, et le Choul'han Aroukh du Mehaber en compte 11. Sefaria sert le texte du Rav en 15 blocs, que cette page reproduit et numérote tels quels (section 1). Les séifim 1 et 2 du Rav répondent aux séifim א et ב du Mehaber ; les séifim 3 et 4 du Rav se partagent le séif ג du Mehaber (le cordeau au niveau du cœur, puis tendu de toute sa force) ; les séifim 5, 6 et 7 du Rav se partagent le séif ד du Mehaber (la mesure face à la ville, la montagne, puis la pente de dix tefa'him sur quatre amot) ; le séif 8 du Rav répond au séif ה du Mehaber (la vallée), et commence par étendre au mur ce qui a été dit de la montagne ; les séifim 9 et 10 du Rav répondent aux séifim ו et ז du Mehaber ; le séif 11 du Rav répond au séif ח du Mehaber, et le séif 12 du Rav à la glose introduite par הגה à la fin de ce séif ; les séifim 13, 14 et 15 du Rav répondent aux séifim ט, י et יא du Mehaber. Dans le texte français de cette page, les séifim du Rav sont désignés par leur chiffre (399:4, séif 4), ceux du Mehaber par leur lettre hébraïque (séif ד du Mehaber) ; dans les adresses hébraïques entre parenthèses, les deux numérotations sont en lettres, et l'adresse nomme toujours l'ouvrage (שו״ע או״ח pour le Mehaber, שו״ע הרב pour le Rav).</p>
    <p>Cette page rassemble, pour le siman שצ״ט, le texte intégral du Rav et sa traduction, ce en quoi son texte diffère de celui du Mehaber et du Rama, et la conduite pratique qui en découle.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken.html" style="color:var(--habad);font-weight:600;">→ Lire la préface générale sur la chitah de l'Admour HaZaken</a></p>
  </div>
'''
FR['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · טקסט אדמו״ר הזקן</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-שצ-ט">שלחן ערוך הרב — סימן שצ״ט</h2>
    <h2 class="section-title-fr" id="le-texte-integral-du-choulhan-aroukh-de-l-admour-hazaken-שולחן-ערוך-הרב">Le texte intégral du Choulhan Aroukh de l'Admour HaZaken (שולחן ערוך הרב)</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 15px;">
      <strong>''' + CHAP_LIGNE + '''</strong><br>
      <em>Source : édition Kehot, telle que reproduite sur Sefaria. Le chapeau annonce 15 séifim ; Sefaria en sert le texte en 15 blocs (le Choul'han Aroukh du Mehaber compte 11 séifim, sous sa propre numérotation).</em>
    </p>
'''
FR['s1_source'] = '''    <p style="margin-top: 20px; font-size: 13px; color: var(--text-muted); font-style: italic;">
      Source : <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.399" target="_blank" style="color: var(--habad);">Sefaria — Shulchan Arukh HaRav, Orach Chayim שצ״ט</a>. Sefaria ne donne aucune entrée de Kountress Aharon pour ce siman. Le texte est recopié tel que Sefaria le sert. Au séif 13, les mots ''' + Q['w_misof'] + ''' et ''' + Q['w_metsela'] + ''' sont vocalisés ainsi dans le texte servi ; ils sont laissés tels quels.
    </p>'''
FR['trad_cls'] = 'sa-fr'
FR['trads'] = [
    # 1
    "Avec quoi l'on mesure les limites (<em>te'houmin</em>), le lieu de la mesure, et qui est celui qui mesure ; il contient 15 <em>séifim</em> :<br><br>"
    "On ne mesure la limite (<em>te'houm</em>) de la ville qu'avec un cordeau de lin de cinquante amot. Pas moins, parce que, quand il est court, il s'étire davantage et allonge la mesure sans nécessité (et de même, celui d'autres sortes s'étire davantage) ; et pas plus long, parce qu'il ne s'étire pas comme il faut : son poids le fait ployer, il se raccourcit en son milieu et raccourcit la mesure de la limite :",
    # 2
    "S'il y a devant lui, au bout de soixante-quinze amot depuis la ville, un fleuve plus large que vingt-cinq amot, qu'il ne peut pas absorber (<em>lehavli'o</em>) dans un cordeau de cinquante amot quand il mesure avec lui à partir du bout des cinquante [amot] depuis la ville — l'endroit où le cordeau s'est achevé une [première] fois —, comment fera-t-il ? Après avoir mesuré cinquante amot depuis la ville, il revient en arrière de vingt-cinq amot, afin que le cordeau de cinquante amot s'achève jusqu'au fleuve :",
    # 3
    "Il ne mesurera qu'au niveau de son cœur, car les Sages lui ont fixé un endroit en face duquel placer le bout du cordeau, afin que l'un ne le place pas au niveau de son cou et l'autre au niveau de ses pieds, [car alors] le cordeau se raccourcit et les limites diminuent :",
    # 4
    "Et il doit tendre le cordeau de toute sa force, parce qu'il pèse en son milieu :",
    # 5
    "Il ne mesurera que face à la ville. Même s'il y a face à elle des montagnes et des vallées, il n'ira pas, de face à elle, sur son côté, là où c'est droit, pour mesurer là, puis revenir ensuite face à la ville selon la mesure qu'il a mesurée là ; mais il mesurera face à la ville, pour absorber les montagnes et les vallées qui sont face à elle, ou pour la mesurer de la manière qui sera expliquée :",
    # 6
    "S'il est arrivé à une montagne : si elle est escarpée au point que, si l'on faisait descendre le fil à plomb de son sommet, il ne s'éloignerait pas, en bas, à sa base, de quatre amot de l'endroit qui lui fait face, il n'a pas du tout besoin de mesurer la descente et la montée ; mais s'il y a un plateau (<em>mishor</em>) à son sommet, il le mesure, et s'il n'y a pas de plateau à son sommet, il ne la mesure pas du tout, mais la saute entièrement, même s'il peut l'absorber dans un cordeau de cinquante amot.<br><br>"
    "Et si le fil à plomb s'éloigne de quatre amot de l'endroit qui lui fait face, et qu'elle s'élève (<em>mitlaket</em>) de dix tefa'him sur plus de quatre amot — c'est-à-dire qu'en parcourant plus de quatre amot de pente, on monte de dix tefa'him en hauteur —, alors on regarde : s'il n'y a d'un bord à l'autre que cinquante amot en ligne droite — si on la perçait à sa base, près de son bord, et qu'on mesurait par le trou —, alors il doit l'absorber dans un cordeau de cinquante amot : il dresse un poteau haut sur son bord d'un côté, et un autre poteau en face, sur son bord de l'autre côté, et tend un cordeau de l'un à l'autre.<br><br>"
    "Et s'il ne peut pas l'absorber dans un cordeau de cinquante amot, il la mesure avec un cordeau de quatre amot, et il fera ainsi : l'un se tient au pied de la montagne, en bas, et l'autre au-dessus de lui, à une distance de quatre amot ; celui d'en bas place le cordeau au niveau de son cœur, et celui d'en haut au niveau de ses pieds ; celui d'en bas monte à l'endroit où se tient celui d'en haut, et celui d'en haut monte de quatre amot, et ils mesurent comme au début ; et il fera ainsi jusqu'à ce qu'ils aient mesuré toute la montagne, de ses deux côtés. Il se trouve que sa pente est diminuée, à chaque [mesure de] quatre amot, de plus d'une demi-taille d'homme, comme de son cœur à ses pieds :",
    # 7
    "Et si elle est plus pentue, de sorte qu'elle s'élève de dix tefa'him sur quatre amot : puisque sa marche n'est pas d'un usage commode, et que c'est une peine de monter et de tendre un cordeau du poteau qui est sur son bord d'un côté au poteau qui lui fait face, les Sages ne lui ont pas imposé cette peine ; mais il évaluera par estimation combien il y aurait dans le cordeau qu'on tendrait au-dessus d'elle d'un poteau à l'autre, si on les dressait sur ses bords de part et d'autre, et il s'en va mesurer plus loin pour compléter la mesure de sa limite.<br><br>"
    "Et s'il a évalué dans son esprit qu'il y aurait plus de cinquante amot : puisque, si elle n'était pas aussi pentue, il aurait dû mesurer toute sa pente avec un cordeau de quatre amot, même quand elle est aussi pentue on n'a pas allégé en cela pour évaluer par l'estimation de son esprit combien il y aurait dans le cordeau tendu ; mais il doit la mesurer tout entière avec un cordeau de quatre amot :",
    # 8
    "Et tout cela [vaut] pour la montagne, et de même pour un mur, qu'il soit debout ou qu'il soit tombé et devenu comme une montagne. Mais s'il est arrivé à une vallée (<em>gaï</em>) : s'il peut l'absorber dans un cordeau de cinquante amot, il doit l'absorber, et non évaluer par l'estimation de son esprit, même si elle s'élève de dix [tefa'him] sur quatre amot, parce qu'il peut facilement l'absorber : l'un se tient d'un côté et l'autre de l'autre côté, et il n'a pas du tout besoin de dresser des poteaux. Et pour cette raison, même si le fil à plomb ne s'éloigne pas, en bas, de quatre amot de l'endroit qui lui fait face, il doit l'absorber.<br><br>"
    "Mais s'il ne peut pas l'absorber dans un cordeau de cinquante amot : si le fil à plomb s'éloigne de quatre amot de l'endroit qui lui fait face, il la mesure tout entière avec un cordeau de quatre amot, comme pour la montagne.<br><br>"
    "Et cela, à condition qu'elle ne soit pas profonde de plus de deux mille [amot]. Mais si elle est profonde de plus de deux mille, il mesure la descente et la montée de toute la pente d'une mesure pleine (<em>medida yafa</em>), comme un sol plat, même s'il peut l'absorber dans un cordeau de cinquante amot.<br><br>"
    "Et si le fil ne s'éloigne pas de quatre amot de l'endroit qui lui fait face, il ne mesure pas du tout la pente de la descente et de la montée, mais seulement le plat d'en bas, s'il ne peut pas l'absorber ; et même si elle est profonde de plus de deux mille :",
    # 9
    "S'il est arrivé à une montagne ou à une vallée, et que toute la partie qui en est face à la ville est plus large que cinquante amot, de sorte qu'il ne peut pas l'absorber, et que sur le côté elle va en se rétrécissant — par exemple, elle est à l'est de la ville, et sur toute la longueur de l'est il ne peut pas l'absorber — : s'il peut l'absorber à l'intérieur des deux mille [amot] du côté nord ou sud, il ira là et l'absorbera, puisque c'est encore à l'intérieur de la limite du côté de la ville, et il reviendra ensuite face à la ville selon la mesure qu'il a mesurée là. Mais s'il ne peut pas l'absorber à l'intérieur des deux mille du côté de la ville, il ne s'éloignera pas davantage pour l'absorber : c'est un décret (<em>guezera</em>), de peur que ceux qui le voient ne disent que la mesure des limites arrive jusqu'ici :",
    # 10
    "On ne s'appuie que sur la mesure d'un homme expert (<em>moum'he</em>), qui connaît la mesure du terrain :",
    # 11
    "Nous avions des limites de Chabbat établies (<em>mou'hzakin</em>), et un expert est venu et a mesuré : il a augmenté la limite de certaines et diminué la limite d'autres. On l'écoute même pour la limite qu'il a augmentée, bien que ce soit pour alléger, parce qu'on attribue [l'écart], en disant que les premiers n'ont pas tendu le cordeau autant qu'il le fallait, car il faut le tendre de toute sa force :",
    # 12
    "S'il a mesuré et trouvé sa mesure au nord-est (<em>mizra'hit tsefonit</em>) plus longue que celle qui lui fait face au sud-est (<em>mizra'hit deromit</em>), il tend le fil de la marque de la limite de l'une à l'autre en oblique (<em>alakhson</em>). Et on ne dit pas qu'il s'est trompé dans l'une d'elles ; mais on attribue [l'écart] au fait que celle qui s'est raccourcie l'est à cause de montagnes et de vallées qui s'y trouvent, et qu'il a dû les mesurer d'une manière qui a raccourci la limite. Et certains disent (<em>yech omrim</em>) qu'on attribue [l'écart] à son erreur, et qu'on va dans le sens de l'allègement, en disant qu'il s'est trompé dans celle qui s'est raccourcie chez lui, et on la fait sortir plus loin, jusqu'au niveau de la longue (et l'essentiel est selon le premier avis) :",
    # 13
    "Si deux experts sont venus et ont mesuré la limite, l'un a augmenté et l'autre a diminué : on écoute celui qui augmente, pour alléger dans [ce qui relève] des paroles des Sofrim, à condition qu'il n'augmente pas plus que la mesure de la diagonale de l'angle de la ville. Comment ? Quand celui-ci augmente, nous dirons : peut-être le premier a-t-il mesuré les deux mille [amot] depuis l'angle de la diagonale de la ville, lui aussi en diagonale, et de même depuis l'angle qui lui fait face ; et il se trouve, quand on tend un fil du bout de la limite [mesurée] depuis cet angle-ci au bout de la limite [mesurée] depuis cet angle-là, qu'il y a entre ce fil et la ville moins de deux mille [amot] ; et le dernier a mesuré comme il se doit, depuis le côté de la ville. Et on ne présume pas que le premier se soit trompé de plus que cette mesure. C'est pourquoi, si le dernier a augmenté de plus que cette mesure, on ne l'écoute pas.<br><br>"
    "Et cette mesure est celle de l'excédent d'un côté long de deux mille sur le côté d'un carré dont la diagonale est de deux mille ; car, de la ville jusqu'au fil tendu depuis le bout des deux mille [mesurés] en diagonale, c'est le côté d'un carré dont la diagonale est de deux mille. Et la mesure de ce côté est de 1 428 amot environ, selon le calcul des Sages du Talmud — qui est approché et non précis —, [selon lequel], en toute diagonale, elle excède les côtés de son carré de deux cinquièmes de la longueur du côté ; il se trouve que, sur 1 428, sa diagonale excède de 2 856 cinquièmes, qui font 572 amot moins quatre cinquièmes ; ajoute-les à 1 428 : il y aura deux mille amot moins quatre cinquièmes. Mais selon le calcul des savants de la mesure (<em>hakhmei hamidot</em>), qui ont rendu le calcul exact et précis pour toute diagonale, cet excédent sera de 585 amot environ :",
    # 14
    "On fait les limites autour de la ville comme une tablette carrée : c'est-à-dire qu'on mesure, sur toute la longueur de la ville, deux mille amot vers l'extérieur à l'est, et de même au nord ; et ensuite on voit comme s'il y avait, dans l'angle, une tablette carrée de deux mille sur deux mille pour le remplir ; il se trouve que la limite, dans l'angle, est de deux mille et [leur] diagonale, qui font 2 800 ; et il fera de même aux autres angles. Mais il ne mesurera pas, du milieu de l'angle, deux mille en diagonale, et de même à l'angle qui lui fait face, pour tendre le fil de l'un à l'autre, car alors il perd les huit cents qui sont dans l'angle, et de plus la limite face à la ville ne sera que de 1 428, et selon le calcul des savants de la mesure, de 1 415 :",
    # 15
    "Même un esclave et une servante cananéens, qui ont accepté sur eux les commandements auxquels la femme est astreinte, sont crus pour dire « jusqu'ici [va] la limite de Chabbat », car les Sages n'ont pas dit la chose pour rendre plus strict, mais pour alléger.<br><br>"
    "Mais un enfant n'est pas cru tant qu'il est enfant. Mais l'adulte est cru pour dire « je me souviens que, jusqu'ici, nous venions le Chabbat quand j'étais enfant », et on s'appuie sur son témoignage :",
]
FR['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · לשון הרב ולשון המחבר</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="ou-le-texte-du-rav-differe-du-seif-du-mehaber-et-du-rama">Où le texte du Rav diffère du séif du Mehaber et du Rama</h2>
    <div class="section-divider"></div>
    <p style="margin-bottom: 24px; color: var(--text-mid);">
      Chaque point met côte à côte un séif du Choul'han Aroukh du Mehaber (sa numérotation, 11 séifim, désignés par leur lettre), ou la glose du Rama, et le séif correspondant du Choulhan Aroukh de l'Admour HaZaken (sa propre numérotation, 15 séifim), dans l'ordre des séifim du Rav, et ne relève que ce que la comparaison des deux textes montre. Un point relevé n'est pas propre au Rav pour autant : la page en nomme parfois la source ; elle ne relève ni toutes les sources ni toutes les divergences. Là où elle relève que les commentateurs divergent sur un cas, elle renvoie au niveau 2.
    </p>
'''
FR['points'] = [
    dict(he_t='נקודה א — חבל של פשתן (שו״ע הרב שצ״ט:א)', t="Point א — le cordeau de lin (Choulhan Aroukh HaRav 399:1)",
         id='ni-plus-court-ni-plus-long', h3='Ni plus court ni plus long',
         meh=g('m_a') + ' (שו״ע או״ח שצ״ט:א).',
         rav=g('r_a') + ' (שו״ע הרב שצ״ט:א).',
         diff="le Mehaber écrit que le cordeau plus court s'étire davantage et que le plus long ne s'étire pas comme il faut ; le texte du Rav en dit l'effet : le cordeau court allonge la mesure sans nécessité ; le long, son poids le fait ployer, il se raccourcit en son milieu et raccourcit la mesure de la limite. Il ajoute, entre parenthèses, que celui d'autres sortes s'étire lui aussi davantage."),
    dict(he_t='נקודה ב — נהר (שו״ע הרב שצ״ט:ב)', t='Point ב — le fleuve (Choulhan Aroukh HaRav 399:2)',
         id='un-fleuve-plus-large-que-vingt-cinq-amot', h3='Un fleuve plus large que vingt-cinq amot',
         meh=g('m_b') + ' (שו״ע או״ח שצ״ט:ב).',
         rav=g('r_b') + ' (שו״ע הרב שצ״ט:ב).',
         diff="le séif ב du Mehaber ne dit pas la largeur du fleuve ; le texte du Rav la précise : un fleuve plus large que vingt-cinq amot, qu'on ne peut pas absorber dans le cordeau de cinquante amot mesuré à partir du bout des cinquante premières. La Michna Beroura lit de même le séif du Mehaber : " + g('mb_c') + ' (משנה ברורה שצ״ט ס״ק ג).'),
    dict(he_t='נקודה ג — כנגד לבו (שו״ע הרב שצ״ט:ג, ד)', t='Point ג — le cordeau au niveau du cœur, tendu de toute sa force (Choulhan Aroukh HaRav 399:3, 4)',
         id='deux-seifim-deux-raisons', h3='Deux séifim, deux raisons',
         meh=g('m_c') + ' (שו״ע או״ח שצ״ט:ג).',
         rav='au séif 3, ' + g('r_c1') + ' (שו״ע הרב שצ״ט:ג) ; au séif 4, ' + g('r_c2') + ' (שו״ע הרב שצ״ט:ד).',
         diff="le Rav fait deux séifim du séif ג du Mehaber, et donne la raison de chacune des deux instructions. Au séif 3, sa formule est celle de la Michna : " + g('mish_c') + ' (משנה עירובין ה:ד).'),
    dict(he_t='נקודה ד — כנגד העיר (שו״ע הרב שצ״ט:ה)', t='Point ד — la mesure face à la ville (Choulhan Aroukh HaRav 399:5)',
         id='pour-absorber-les-montagnes', h3='Pour absorber les montagnes',
         meh=g('m_d') + ' (שו״ע או״ח שצ״ט:ד).',
         rav=g('r_d') + ' (שו״ע הרב שצ״ט:ה).',
         diff="le Mehaber écrit qu'on mesure face à la ville ; le texte du Rav en dit le but : absorber les montagnes et les vallées qui sont face à elle, ou la mesurer de la manière qui sera expliquée."),
    dict(he_t='נקודה ה — הגיע להר (שו״ע הרב שצ״ט:ו)', t='Point ה — la montagne (Choulhan Aroukh HaRav 399:6)',
         id='la-montagne-escarpee-et-la-pente', h3='La montagne escarpée et la pente',
         meh=g('m_e') + ' (שו״ע או״ח שצ״ט:ד) ; ' + g('m_f') + ' (שו״ע או״ח שצ״ט:ד).',
         rav=g('r_e') + ' (שו״ע הרב שצ״ט:ו) ; ' + g('r_f') + ' (שו״ע הרב שצ״ט:ו).',
         diff="pour la montagne escarpée, le séif ד du Mehaber écrit qu'on n'a pas besoin de mesurer la descente et la montée s'il y a un plateau au sommet, et qu'on ne mesure rien s'il n'y en a pas ; le texte du Rav écrit en toutes lettres qu'on mesure le plateau du sommet, et ajoute : même si l'on peut absorber la montagne dans un cordeau de cinquante amot. La Michna Beroura lit de même le séif du Mehaber : " + g('mb_e') + " (משנה ברורה שצ״ט ס״ק י). Pour la pente, le Mehaber écrit : dix [tefa'him] sur cinq [amot] ; le texte du Rav : dix tefa'him sur plus de quatre amot. Le texte du Rav explique aussi ce qu'est la mesure en ligne droite (comme si l'on perçait la montagne à sa base), et ce que la mesure au cordeau de quatre amot retire de la pente à chaque fois (plus d'une demi-taille d'homme).",
         comm="sur une pente plus douce, les commentateurs divergent : voir le niveau 2."),
    dict(he_t='נקודה ו — הר המשופע ביותר (שו״ע הרב שצ״ט:ז)', t="Point ו — la pente de dix tefa'him sur quatre amot (Choulhan Aroukh HaRav 399:7)",
         id='l-estimation-et-sa-limite', h3="L'estimation et sa limite",
         meh=g('m_g') + ' (שו״ע או״ח שצ״ט:ד).',
         rav=g('r_g') + ' (שו״ע הרב שצ״ט:ז).',
         diff="les deux textes écrivent qu'une pente de dix [tefa'him] sur quatre amot s'évalue par estimation si elle n'a que cinquante amot, et se mesure au cordeau de quatre amot si elle en a davantage. Le texte du Rav donne la raison de l'allègement (la marche n'y est pas d'un usage commode, et c'est une peine de monter tendre un cordeau d'un poteau à l'autre) et celle de sa limite (moins pentue, elle aurait dû être mesurée tout entière au cordeau de quatre amot).",
         comm="sur la pente de cette sorte plus large que cinquante amot, les commentateurs divergent : voir le niveau 2."),
    dict(he_t='נקודה ז — כותל וגיא (שו״ע הרב שצ״ט:ח)', t='Point ז — le mur et la vallée (Choulhan Aroukh HaRav 399:8)',
         id='la-vallee-s-absorbe-sans-poteaux', h3="La vallée s'absorbe sans poteaux",
         meh=g('m_h') + ' (שו״ע או״ח שצ״ט:ה).',
         rav=g('r_h1') + ' (שו״ע הרב שצ״ט:ח) ; ' + g('r_h2') + ' (שו״ע הרב שצ״ט:ח).',
         diff="le texte du Rav étend au mur, debout ou tombé, ce qui a été dit de la montagne. Pour la vallée, il pose d'abord la question de l'absorption : la vallée qu'on peut absorber dans le cordeau de cinquante amot s'absorbe sans estimation, même si elle s'élève de dix [tefa'him] sur quatre amot, et même si le fil à plomb ne s'éloigne pas de quatre amot, parce qu'on l'absorbe facilement, sans dresser de poteaux ; il traite ensuite de la vallée qu'on ne peut pas absorber, et de la vallée profonde de plus de deux mille [amot] (voir la traduction en section 1). Le séif ה du Mehaber pose d'abord la question du fil à plomb, et ne parle pas d'estimation pour la vallée."),
    dict(he_t='נקודה ח — הר או גיא המתקצר מן הצד (שו״ע הרב שצ״ט:ט)', t='Point ח — la montagne ou la vallée absorbée sur le côté (Choulhan Aroukh HaRav 399:9)',
         id='la-raison-de-la-limite', h3='La raison de la limite',
         meh=g('m_i') + ' (שו״ע או״ח שצ״ט:ו).',
         rav=g('r_i') + ' (שו״ע הרב שצ״ט:ט).',
         diff="le Mehaber écrit qu'on ne s'éloigne pas davantage ; le texte du Rav en donne la raison : un décret, de peur que ceux qui le voient ne disent que la mesure des limites arrive jusque-là. Il écrit aussi qu'après avoir absorbé sur le côté, on revient face à la ville selon la mesure prise là."),
    dict(he_t='נקודה ט — תחומין מוחזקין (שו״ע הרב שצ״ט:יא)', t='Point ט — les limites établies (Choulhan Aroukh HaRav 399:11)',
         id='pourquoi-on-ecoute-l-expert-qui-augmente', h3="Pourquoi on écoute l'expert qui augmente",
         meh=g('m_j') + ' (שו״ע או״ח שצ״ט:ח).',
         rav=g('r_j') + ' (שו״ע הרב שצ״ט:יא).',
         diff="le texte du Rav ajoute : bien que ce soit pour alléger ; et il en donne la raison : on attribue [l'écart] au fait que les premiers n'ont pas tendu le cordeau autant qu'il le fallait."),
    dict(he_t='נקודה י — מותח החוט באלכסון (שו״ע הרב שצ״ט:יב)', t='Point י — le fil tendu en oblique (Choulhan Aroukh HaRav 399:12)',
         id='l-oblique-et-l-avis-contraire', h3="L'oblique et l'avis contraire", rama=True,
         meh='la glose introduite par הגה à la fin du séif ח : ' + g('m_k') + ' (שו״ע או״ח שצ״ט:ח).',
         rav=g('r_k1') + ' (שו״ע הרב שצ״ט:יב) ; et ' + g('r_k2') + ' (שו״ע הרב שצ״ט:יב).',
         diff="la glose rapporte le fil tendu en oblique, puis, introduit par <em>וי״א</em>, l'avis de la mesure égale. Le texte du Rav donne la raison de chacun — pour le premier, la mesure plus courte vient des montagnes et des vallées qu'il a fallu mesurer ; pour le second, on attribue l'écart à une erreur dans la mesure raccourcie — et conclut, entre parenthèses, que l'essentiel est selon le premier avis. La glose n'a pas cette conclusion.",
         comm="sur ce cas, les commentateurs divergent : voir le niveau 2."),
    dict(he_t='נקודה יא — שני מומחים (שו״ע הרב שצ״ט:יג)', t='Point יא — deux experts (Choulhan Aroukh HaRav 399:13)',
         id='jusqu-ou-l-on-ecoute-celui-qui-augmente', h3="Jusqu'où l'on écoute celui qui augmente",
         meh=g('m_l') + ' (שו״ע או״ח שצ״ט:ט).',
         rav=g('r_l1') + ' (שו״ע הרב שצ״ט:יג) ; ' + g('r_l2') + ' (שו״ע הרב שצ״ט:יג) ; ' + g('r_l3') + ' (שו״ע הרב שצ״ט:יג).',
         diff="le texte du Rav donne la raison (alléger dans ce qui relève des paroles des Sofrim) ; il écrit <em>la diagonale de l'angle de la ville</em> là où le Mehaber écrit <em>la diagonale de la ville</em> ; il précise que le premier a pu mesurer en diagonale depuis deux angles opposés ; il écrit qu'on n'écoute pas le dernier s'il augmente de plus que cette mesure ; et il la chiffre : le côté d'un carré dont la diagonale est de deux mille fait environ 1 428 amot selon le calcul des Sages du Talmud, et l'excédent est d'environ 585 amot selon le calcul des savants de la mesure."),
    dict(he_t='נקודה יב — כטבלא מרובעת (שו״ע הרב שצ״ט:יד)', t='Point יב — la limite carrée (Choulhan Aroukh HaRav 399:14)',
         id='le-calcul-des-savants-de-la-mesure', h3='Le calcul des savants de la mesure',
         meh=g('m_m') + ' (שו״ע או״ח שצ״ט:י).',
         rav=g('r_m') + ' (שו״ע הרב שצ״ט:יד).',
         diff="le Mehaber écrit 1 428 ; le texte du Rav ajoute, selon le calcul des savants de la mesure, 1 415. Au séif 13, il appelle le premier calcul celui des Sages du Talmud, approché et non précis."),
    dict(he_t='נקודה יג — עבד ושפחה (שו״ע הרב שצ״ט:טו)', t='Point יג — qui est cru (Choulhan Aroukh HaRav 399:15)',
         id='l-esclave-cananeen-et-la-raison-de-la-michna', h3="L'esclave cananéen et la raison de la Michna",
         meh=g('m_n') + ' (שו״ע או״ח שצ״ט:יא).',
         rav=g('r_n1') + ' (שו״ע הרב שצ״ט:טו) ; ' + g('r_n2') + ' (שו״ע הרב שצ״ט:טו).',
         diff="le texte du Rav précise de quel esclave et de quelle servante il s'agit — cananéens, qui ont accepté les commandements auxquels la femme est astreinte — et donne la raison, qui est la formule de la Michna : " + g('mish_n') + ' (משנה עירובין ה:ה).'),
]
FR['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · למעשה</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="la-conduite-habad-pratique">La conduite Habad pratique</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      Points de conduite halakhique qui découlent directement du Choulhan Aroukh de l'Admour HaZaken siman שצ״ט, dans la sensibilité Habad. Chaque point renvoie à son séif du Rav, dans l'ordre du texte.
    </p>

    <div class="lemaaseh-block">
      <h3 id="pour-le-hassid-חסיד-habad-siman-שצ-ט">Pour le Hassid (חסיד) Habad — Siman שצ״ט</h3>
      <ul>'''
FR['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 13px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ Cette section présente la conduite halakhique Habad. Pour toute question concrète : <strong>consulter ton Rav</strong>.
      </p>
    </div>
  </section>
'''
R = lambda s: ' <em>Référence : Choulhan Aroukh de l\'Admour HaZaken שצ״ט:' + s + '.</em>'
FR['s4'] = [
    "<strong>① Le cordeau :</strong> on mesure la limite de la ville avec un cordeau de lin de cinquante amot, ni plus court ni plus long (399:1) ; on mesure au niveau du cœur (399:3), et on tend le cordeau de toute sa force (399:4)." + R('1, 3, 4'),
    "<strong>② Le fleuve :</strong> s'il y a, au bout de soixante-quinze amot depuis la ville, un fleuve plus large que vingt-cinq amot, après avoir mesuré cinquante amot depuis la ville on revient en arrière de vingt-cinq amot, afin que le cordeau de cinquante amot s'achève jusqu'au fleuve (399:2)." + R('2'),
    "<strong>③ Face à la ville :</strong> on mesure face à la ville, même s'il y a face à elle des montagnes et des vallées ; on ne va pas mesurer sur son côté, là où c'est droit, pour revenir ensuite face à la ville selon la mesure prise là (399:5). Pour la montagne ou la vallée qu'on ne peut pas absorber face à la ville, voir le point ⑦." + R('5'),
    "<strong>④ La montagne :</strong> si elle est escarpée au point que le fil à plomb ne s'éloigne pas de quatre amot, on ne mesure pas du tout la descente et la montée ; on mesure le plateau du sommet s'il y en a un, et sinon on saute la montagne entièrement, même si l'on peut l'absorber dans un cordeau de cinquante amot. Si le fil à plomb s'éloigne de quatre amot et qu'elle s'élève de dix tefa'him sur plus de quatre amot : s'il n'y a d'un bord à l'autre que cinquante amot en ligne droite, on l'absorbe dans un cordeau de cinquante amot tendu entre deux poteaux dressés sur ses bords ; sinon, on la mesure avec un cordeau de quatre amot, celui d'en bas le plaçant au niveau de son cœur et celui d'en haut au niveau de ses pieds (399:6) ; voir aussi le point ⑦. Sur une pente plus douce, les commentateurs divergent : voir la section 2, point ה, et le niveau 2." + R('6'),
    "<strong>⑤ La pente de dix tefa'him sur quatre amot :</strong> on évalue par estimation combien il y aurait dans le cordeau tendu d'un poteau à l'autre, sur ses bords ; si l'on estime qu'il y aurait plus de cinquante amot, on mesure toute la pente avec un cordeau de quatre amot (399:7). Sur la pente de cette sorte plus large que cinquante amot, les commentateurs divergent : voir la section 2, point ו, et le niveau 2 ; consulte ton Rav." + R('7'),
    "<strong>⑥ Le mur et la vallée :</strong> le mur, debout ou tombé, se mesure comme la montagne. La vallée qu'on peut absorber dans un cordeau de cinquante amot s'absorbe, sans estimation, même si elle s'élève de dix [tefa'him] sur quatre amot, et même si le fil à plomb ne s'éloigne pas de quatre amot. Si on ne peut pas l'absorber et que le fil à plomb s'éloigne de quatre amot, on la mesure tout entière avec un cordeau de quatre amot, comme la montagne (voir aussi le point ⑦), à condition qu'elle ne soit pas profonde de plus de deux mille [amot] ; si elle l'est, on mesure toute la pente, descente et montée, comme un sol plat, même si l'on peut l'absorber. Si le fil à plomb ne s'éloigne pas de quatre amot, on ne mesure pas la pente, mais seulement le plat d'en bas, si l'on ne peut pas l'absorber, même si elle est profonde de plus de deux mille (399:8)." + R('8'),
    "<strong>⑦ Absorber sur le côté :</strong> une montagne ou une vallée plus large que cinquante amot face à la ville, qui se rétrécit sur le côté : si l'on peut l'absorber à l'intérieur des deux mille [amot] du côté nord ou sud, on va l'y absorber, puis on revient face à la ville selon la mesure prise là ; si on ne peut pas l'absorber à l'intérieur des deux mille du côté de la ville, on ne s'éloigne pas davantage pour l'absorber, de peur que ceux qui le voient ne disent que la mesure des limites arrive jusque-là (399:9)." + R('9'),
    "<strong>⑧ L'expert :</strong> on ne s'appuie que sur la mesure d'un homme expert, qui connaît la mesure du terrain (399:10) ; quand des limites de Chabbat sont établies et qu'un expert, en les mesurant, en augmente certaines et en diminue d'autres, on l'écoute même là où il a augmenté (399:11). La Michna Beroura écrit, sur le séif ח du Mehaber : " + g('mb_29') + " (משנה ברורה שצ״ט ס״ק כ״ט) — il est simple que [le séif] parle du cas où nous ne savons pas que la première présomption s'est faite par la mesure d'un expert ; sinon, on n'écoute le second que lorsqu'il augmente, et non lorsqu'il diminue." + R('10, 11'),
    "<strong>⑨ Le fil tendu en oblique :</strong> si la mesure au nord-est est plus longue que celle qui lui fait face au sud-est, on tend le fil de la marque de la limite de l'une à l'autre en oblique. Le Rav rapporte un avis (<em>[[r_yo]]</em>) selon lequel on attribue l'écart à une erreur dans la mesure raccourcie, qu'on fait sortir jusqu'au niveau de la longue, et conclut : «&nbsp;[[r_k3]]&nbsp;» (שו״ע הרב שצ״ט:יב). Sur ce cas, les commentateurs divergent : voir la section 2, point י, et le niveau 2 ; consulte ton Rav." + R('12'),
    "<strong>⑩ Deux experts :</strong> si deux experts ont mesuré la limite, l'un en augmentant et l'autre en diminuant, on écoute celui qui augmente, à condition qu'il n'augmente pas plus que la mesure de la diagonale de l'angle de la ville ; s'il augmente de plus que cette mesure, on ne l'écoute pas (399:13). La Michna Beroura écrit, sur le séif ט du Mehaber : " + g('mb_39') + " (משנה ברורה שצ״ט ס״ק ל״ט) — et s'il arrive qu'ils diffèrent dans la mesure de plus que cette mesure, il est raisonnable qu'on ne suive la mesure d'aucun des deux, et qu'il faille mesurer à nouveau et clarifier la chose." + R('13'),
    "<strong>⑪ La limite carrée :</strong> on mesure deux mille amot vers l'extérieur sur toute la longueur de la ville, à l'est, et de même au nord, et on remplit l'angle comme d'une tablette carrée de deux mille sur deux mille ; de même aux autres angles. On ne mesure pas deux mille en diagonale depuis l'angle, et de même depuis l'angle qui lui fait face, pour tendre le fil de l'un à l'autre (399:14)." + R('14'),
    "<strong>⑫ Qui est cru :</strong> un esclave et une servante cananéens, qui ont accepté les commandements auxquels la femme est astreinte, sont crus pour dire <em>jusqu'ici [va] la limite de Chabbat</em> ; un enfant ne l'est pas tant qu'il est enfant ; un adulte est cru pour dire qu'il se souvient que, jusque-là, on venait le Chabbat quand il était enfant, et on s'appuie sur son témoignage (399:15)." + R('15'),
]

# ============================================================================ HÉBREU
HE = {}
HE['title'] = 'סימן שצ״ט · רמה 4 — שיטת אדמו״ר הזקן: במה מודדין התחומין, מקום המדידה ומי הוא המודד | דעת'
HE['desc'] = ('רמה 4 (דעת הרב) של סימן שצ״ט — במה מודדין תחומי שבת, מקום המדידה ומי הוא המודד: חבל של פשתן של חמשים אמה, הנהר, '
              'החבל כנגד הלב ומתיחתו בכל הכח, המדידה כנגד העיר, ההר ושיפועו, הכותל והגיא, ההבלעה מן הצד, המומחה ותחומין מוחזקין, '
              'מתיחת החוט באלכסון, שני מומחים, התחום כטבלא מרובעת וקרנותיו, מי נאמן על התחום. הטקסט המלא של חמשה עשר הסעיפים של '
              'שולחן ערוך אדמו״ר הזקן, במה שונה לשון הרב מסעיפי המחבר והרמ״א, וההנהגה המעשית.')
HE['og'] = 'שיטת אדמו״ר הזקן במדידת תחומי שבת: החבל, ההר, הכותל והגיא, המומחה המודד, התחום כטבלא מרובעת והעדות על התחום.'
HE['tw'] = 'שיטת אדמו״ר הזקן: במה מודדין תחומי שבת, מקום המדידה ומי הוא המודד.'
HE['ld'] = 'רמה 4 (דעת הרב) של סימן שצ״ט: במה מודדין תחומי שבת, מקום המדידה ומי הוא המודד, בשולחן ערוך אדמו״ר הזקן.'
HE['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">דעת · רמה 4 — דעת הרב · שיטת אדמו״ר הזקן</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">דעת הרב — שולחן ערוך אדמו״ר הזקן על סימן שצ״ט</h1>
    <p class="hero-subtitle">במה מודדין התחומין, מקום המדידה ומי הוא המודד: חבל של פשתן של חמשים אמה; נהר לסוף ע״ה אמה; החבל כנגד הלב, ומתיחתו בכל הכח; המדידה כנגד העיר; ההר הזקוף, השיפוע והמדידה בחבל של ד׳ אמות; הכותל והגיא; הר או גיא שמבליעים מן הצד; המומחה, תחומין מוחזקין ומתיחת החוט באלכסון; שני מומחים שאינם שוים; התחום כטבלא מרובעת וקרנותיו; מי נאמן על התחום. חמשה עשר הסעיפים של שולחן ערוך אדמו״ר הזקן; בשולחן ערוך של המחבר אחד עשר.</p>
  </div>
</div>
'''
HE['intro'] = '''  <div class="intro-block">
    <p><strong>מדוע רמה 4 מוקדשת לאדמו״ר הזקן?</strong> <strong>שולחן ערוך אדמו״ר הזקן</strong> אינו פירוש על המחבר: זהו שולחן ערוך בפני עצמו, שנכתב על ידי אדמו״ר הזקן, בחלוקה ובמספור סעיפים משלו. כאן מונה שולחן ערוך הרב חמשה עשר סעיפים בראש הסימן, ובשולחן ערוך של המחבר אחד עשר. ספריא מגישה את לשון הרב בחמשה עשר קטעים, והדף מביא וממספר אותם כמות שהם (פרק 1). סעיפים א ו־ב של הרב עומדים מול סעיפים א ו־ב של המחבר; סעיפים ג ו־ד של הרב מחלקים ביניהם את סעיף ג של המחבר (החבל כנגד הלב, ואחר כך מתיחתו בכל הכח); סעיפים ה, ו ו־ז של הרב מחלקים ביניהם את סעיף ד של המחבר (המדידה כנגד העיר, ההר, ואחר כך השיפוע המתלקט עשרה טפחים מתוך ארבע אמות); סעיף ח של הרב עומד מול סעיף ה של המחבר (הגיא), ופותח בכך שהכותל דינו כהר; סעיפים ט ו־י של הרב עומדים מול סעיפים ו ו־ז של המחבר; סעיף יא של הרב עומד מול סעיף ח של המחבר, וסעיף יב של הרב מול ההגה שבסוף סעיף זה; סעיפים יג, יד ו־טו של הרב עומדים מול סעיפים ט, י ו־יא של המחבר. בהפניות שבסוגריים שני המספורים באותיות, וההפניה מציינת תמיד את הספר (שו״ע או״ח למחבר, שו״ע הרב לרב).</p>
    <p>עמוד זה מקבץ, לסימן שצ״ט, את הטקסט המלא של הרב, את מה ששונה בלשונו מדברי המחבר והרמ״א, ואת ההנהגה המעשית העולה מדבריו.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken-he.html" style="color:var(--habad);font-weight:600;">← קרא את ההקדמה הכללית על שיטת אדמו״ר הזקן</a></p>
  </div>
'''
HE['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · טקסט אדמו״ר הזקן</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-שצ״ט">שלחן ערוך הרב — סימן שצ״ט</h2>
    <h2 class="section-title-fr" id="הטקסט-המלא-של-שולחן-ערוך-אדמו״ר-הזקן-שולחן-ערוך-הרב">הטקסט המלא של שולחן ערוך אדמו״ר הזקן (שולחן ערוך הרב)</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 16px;">
      <strong>''' + CHAP_LIGNE + '''</strong><br>
      <em>מקור: מהדורת קה״ת, כפי שמופיע בספריא. בכותרת: ט״ו סעיפים; ספריא מגישה את הלשון בחמשה עשר קטעים (בשולחן ערוך של המחבר אחד עשר סעיפים, במספור משלו).</em>
    </p>
'''
HE['s1_source'] = '''    <p style="margin-top: 20px; font-size: 14px; color: var(--text-muted); font-style: italic;">
      מקור: <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.399" target="_blank" style="color: var(--habad);">ספריא — שולחן ערוך הרב, אורח חיים שצ״ט</a>. בספריא לא מופיעים ערכי קונטרס אחרון לסימן זה. הטקסט מועתק כפי שספריא מגישה אותו. בסעיף יג המילים ''' + Q['w_misof'] + ''' ו־''' + Q['w_metsela'] + ''' מנוקדות כך בטקסט שספריא מגישה; הן מובאות כמות שהן.
    </p>'''
HE['trad_cls'] = None
HE['trads'] = None
HE['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · לשון הרב ולשון המחבר</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="במה-שונה-לשון-הרב-מסעיף-המחבר-והרמ״א">במה שונה לשון הרב מסעיף המחבר והרמ״א</h2>
    <div class="section-divider"></div>
    <p style="margin-bottom: 24px; color: var(--text-mid);">
      כל נקודה מעמידה זה לצד זה סעיף של שולחן ערוך המחבר (במספור שלו, אחד עשר סעיפים, המסומנים באותיותיהם), או את הגהת הרמ״א, ואת הסעיף המקביל בשולחן ערוך אדמו״ר הזקן (במספור שלו, חמשה עשר סעיפים), לפי סדר סעיפי הרב, ואינה מציינת אלא מה שעולה מהשוואת שני הלשונות. נקודה שצוינה אינה מיוחדת לרב בשל כך: הדף מציין לפעמים את מקורה; אין הוא מציין את כל המקורות ולא את כל המחלוקות. במקום שהדף מציין שנחלקו המפרשים בדין, הוא מפנה לרמה 2.
    </p>
'''
HE['points'] = [
    dict(he_t='נקודה א — חבל של פשתן (שו״ע הרב שצ״ט:א)', id='לא-פחות-ולא-יותר', h3='לא פחות ולא יותר',
         meh=g('m_a') + ' (שו״ע או״ח שצ״ט:א).', rav=g('r_a') + ' (שו״ע הרב שצ״ט:א).',
         diff='המחבר כותב שהקצר נמתח ביותר ושהארוך אינו נמתח כראוי; לשון הרב מפרשת את התוצאה: הקצר מאריך את המדה שלא לצורך, והארוך — כובדו מכפילו, והוא מתקצר באמצעיתו ומקצר את מדת התחום. ועוד מוסיפה, בסוגריים, שגם של שאר מינים נמתח ביותר.'),
    dict(he_t='נקודה ב — נהר (שו״ע הרב שצ״ט:ב)', id='נהר-הרחב-יותר-מכ״ה-אמה', h3='נהר הרחב יותר מכ״ה אמה',
         meh=g('m_b') + ' (שו״ע או״ח שצ״ט:ב).', rav=g('r_b') + ' (שו״ע הרב שצ״ט:ב).',
         diff='סעיף ב של המחבר אינו מפרש את רוחב הנהר; לשון הרב מפרשת: נהר הרחב יותר מכ״ה אמה, שאי אפשר להבליעו בחבל של נ׳ אמה כשמודדים בו מסוף החמשים הראשונות. וכן מפרש המשנה ברורה את סעיף המחבר: ' + g('mb_c') + ' (משנה ברורה שצ״ט ס״ק ג).'),
    dict(he_t='נקודה ג — כנגד לבו (שו״ע הרב שצ״ט:ג, ד)', id='שני-סעיפים-שני-טעמים', h3='שני סעיפים, שני טעמים',
         meh=g('m_c') + ' (שו״ע או״ח שצ״ט:ג).',
         rav='בסעיף ג, ' + g('r_c1') + ' (שו״ע הרב שצ״ט:ג); בסעיף ד, ' + g('r_c2') + ' (שו״ע הרב שצ״ט:ד).',
         diff='הרב עושה מסעיף ג של המחבר שני סעיפים, ונותן טעם לכל אחת משתי ההוראות. בסעיף ג לשונו היא לשון המשנה: ' + g('mish_c') + ' (משנה עירובין ה:ד).'),
    dict(he_t='נקודה ד — כנגד העיר (שו״ע הרב שצ״ט:ה)', id='כדי-להבליע-ההרים', h3='כדי להבליע את ההרים',
         meh=g('m_d') + ' (שו״ע או״ח שצ״ט:ד).', rav=g('r_d') + ' (שו״ע הרב שצ״ט:ה).',
         diff='המחבר כותב שמודדים כנגד העיר; לשון הרב מפרשת את התכלית: כדי להבליע את ההרים והגאיות שכנגדה, או למדדה בדרך שיתבאר להלן.'),
    dict(he_t='נקודה ה — הגיע להר (שו״ע הרב שצ״ט:ו)', id='ההר-הזקוף-והשיפוע', h3='ההר הזקוף והשיפוע',
         meh=g('m_e') + ' (שו״ע או״ח שצ״ט:ד); ' + g('m_f') + ' (שו״ע או״ח שצ״ט:ד).', rav=g('r_e') + ' (שו״ע הרב שצ״ט:ו); ' + g('r_f') + ' (שו״ע הרב שצ״ט:ו).',
         diff='בהר הזקוף, סעיף ד של המחבר כותב שאין צריך למדוד את הירידה והעליה אם יש מישור בראשו, ושאם אין מישור בראשו אינו מודד כלל; לשון הרב כותבת במפורש שמודדים את המישור שבראשו, ומוסיפה: אף על פי שיכול להבליע את ההר בחבל של נ׳ אמה. וכן מפרש המשנה ברורה את סעיף המחבר: ' + g('mb_e') + ' (משנה ברורה שצ״ט ס״ק י). בשיפוע, המחבר כותב: עשרה מתוך חמש; לשון הרב: עשרה טפחים מתוך יותר מארבע אמות. לשון הרב מבארת גם מהי המדידה ביושר (כאילו נוקבים את ההר בשיפולו), וכמה מתמעט השיפוע בכל מדידה בחבל של ד׳ אמות (יותר מחצי קומת אדם).',
         comm='בשיפוע מתון יותר נחלקו המפרשים: ראה רמה 2.'),
    dict(he_t='נקודה ו — הר המשופע ביותר (שו״ע הרב שצ״ט:ז)', id='האומד-וגבולו', h3='האומד וגבולו',
         meh=g('m_g') + ' (שו״ע או״ח שצ״ט:ד).', rav=g('r_g') + ' (שו״ע הרב שצ״ט:ז).',
         diff='שני הלשונות כותבים ששיפוע המתלקט עשרה טפחים מתוך ארבע אמות משערים אותו באומד אם אין בו אלא חמשים אמה, ומודדים אותו בחבל של ד׳ אמות אם יש בו יותר. לשון הרב נותנת טעם להקלה (אין הליכתו נוחה, וטורח הוא לעלות ולמתוח חבל מעץ לעץ) ולגבולה (אילו לא היה משופע כל כך, היה צריך למדוד כל שיפועו בחבל של ד׳ אמות).',
         comm='בשיפוע כזה הרחב יותר מחמשים אמה נחלקו המפרשים: ראה רמה 2.'),
    dict(he_t='נקודה ז — כותל וגיא (שו״ע הרב שצ״ט:ח)', id='הגיא-נבלע-בלא-עצים', h3='הגיא נבלע בלא עצים',
         meh=g('m_h') + ' (שו״ע או״ח שצ״ט:ה).', rav=g('r_h1') + ' (שו״ע הרב שצ״ט:ח); ' + g('r_h2') + ' (שו״ע הרב שצ״ט:ח).',
         diff='לשון הרב משווה לכותל, בין זקוף בין שנפל, את מה שנאמר בהר. בגיא היא שואלת תחילה אם אפשר להבליעו: גיא שאפשר להבליעו בחבל של נ׳ אמה — מבליעו ואינו משער באומד, אפילו מתלקט עשרה מתוך ארבע אמות, ואפילו אין חוט המשקולת מתרחק ארבע אמות, לפי שבקל מבליעו, בלא העמדת עצים; ואחר כך היא עוסקת בגיא שאי אפשר להבליעו, ובגיא העמוק יותר מאלפים (ראה הלשון בפרק 1). סעיף ה של המחבר שואל תחילה על חוט המשקולת, ואינו מזכיר אומד בגיא.'),
    dict(he_t='נקודה ח — הר או גיא המתקצר מן הצד (שו״ע הרב שצ״ט:ט)', id='טעם-ההגבלה', h3='טעם ההגבלה',
         meh=g('m_i') + ' (שו״ע או״ח שצ״ט:ו).', rav=g('r_i') + ' (שו״ע הרב שצ״ט:ט).',
         diff='המחבר כותב שלא יתרחק יותר; לשון הרב נותנת את הטעם: גזירה שמא יאמרו הרואים שמדת התחומין מגיעה לשם. ועוד היא כותבת שאחרי שהבליע מן הצד, חוזר כנגד העיר לפי המדה שמדד שם.'),
    dict(he_t='נקודה ט — תחומין מוחזקין (שו״ע הרב שצ״ט:יא)', id='למה-שומעים-למומחה-שריבה', h3='למה שומעים למומחה שריבה',
         meh=g('m_j') + ' (שו״ע או״ח שצ״ט:ח).', rav=g('r_j') + ' (שו״ע הרב שצ״ט:יא).',
         diff='לשון הרב מוסיפה: אף על פי שהוא להקל; ונותנת טעם: תולים שהראשונים לא מתחו את החבל כל צרכו.'),
    dict(he_t='נקודה י — מותח החוט באלכסון (שו״ע הרב שצ״ט:יב)', id='האלכסון-והדעה-החולקת', h3='האלכסון והדעה החולקת', rama=True,
         meh='ההגה שבסוף סעיף ח: ' + g('m_k') + ' (שו״ע או״ח שצ״ט:ח).', rav=g('r_k1') + ' (שו״ע הרב שצ״ט:יב); וכן ' + g('r_k2') + ' (שו״ע הרב שצ״ט:יב).',
         diff='ההגה מביאה את מתיחת החוט באלכסון, ואחריה, בלשון <em>וי״א</em>, את הדעה שמודדים בשוה. לשון הרב נותנת טעם לכל אחת — לראשונה, המדה שנתקצרה היא מחמת הרים וגאיות שהוצרך למדדם; לשניה, תולים בטעות שבמדה שנתקצרה — ומסיימת, בסוגריים, שהעיקר כסברא הראשונה. בהגה אין סיום זה.',
         comm='בדין זה נחלקו המפרשים: ראה רמה 2.'),
    dict(he_t='נקודה יא — שני מומחים (שו״ע הרב שצ״ט:יג)', id='עד-כמה-שומעים-למרבה', h3='עד כמה שומעים למרבה',
         meh=g('m_l') + ' (שו״ע או״ח שצ״ט:ט).', rav=g('r_l1') + ' (שו״ע הרב שצ״ט:יג); ' + g('r_l2') + ' (שו״ע הרב שצ״ט:יג); ' + g('r_l3') + ' (שו״ע הרב שצ״ט:יג).',
         diff='לשון הרב נותנת טעם (להקל בדברי סופרים); כותבת <em>אלכסונה של קרן העיר</em> במקום שהמחבר כותב <em>אלכסונה של עיר</em>; מפרשת שהראשון אפשר שמדד באלכסון משתי קרנות זו כנגד זו; כותבת שאם ריבה האחרון יותר משיעור זה אין שומעים לו; ומחשבת את השיעור: צלע מרובע שאלכסונו אלפים היא כאלף ותכ״ח אמה לפי חשבון חכמי התלמוד, והעודף כתקפ״ה אמה לפי חשבון חכמי המדות.'),
    dict(he_t='נקודה יב — כטבלא מרובעת (שו״ע הרב שצ״ט:יד)', id='חשבון-חכמי-המדות', h3='חשבון חכמי המדות',
         meh=g('m_m') + ' (שו״ע או״ח שצ״ט:י).', rav=g('r_m') + ' (שו״ע הרב שצ״ט:יד).',
         diff='המחבר כותב אלף ותכ״ח; לשון הרב מוסיפה, לפי חשבון חכמי המדות, אלף ותט״ו. בסעיף יג היא קוראת לחשבון הראשון חשבון חכמי התלמוד, שהוא בקירוב ולא בצמצום.'),
    dict(he_t='נקודה יג — עבד ושפחה (שו״ע הרב שצ״ט:טו)', id='עבד-כנעני-וטעם-המשנה', h3='עבד כנעני וטעם המשנה',
         meh=g('m_n') + ' (שו״ע או״ח שצ״ט:יא).', rav=g('r_n1') + ' (שו״ע הרב שצ״ט:טו); ' + g('r_n2') + ' (שו״ע הרב שצ״ט:טו).',
         diff='לשון הרב מפרשת באיזה עבד ובאיזו שפחה מדובר — כנעניים, שקיבלו עליהם מצוות שהאשה חייבת בהן — ונותנת טעם, והוא לשון המשנה: ' + g('mish_n') + ' (משנה עירובין ה:ה).'),
]
HE['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · למעשה</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="ההנהגה-המעשית-לחב״ד">ההנהגה המעשית לחב״ד</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      נקודות הנהגה הלכתית הנובעות ישירות משולחן ערוך אדמו״ר הזקן סימן שצ״ט, ברגישות החב״דית. כל נקודה מפנה לסעיף שלה בשולחן ערוך הרב, לפי סדר הלשון.
    </p>

    <div class="lemaaseh-block">
      <h3 id="לחסיד-חב״ד-סימן-שצ״ט">לחסיד חב״ד — סימן שצ״ט</h3>
      <ul>'''
HE['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 14px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ סעיף זה מציג את ההנהגה ההלכתית של חב״ד. לכל שאלה ממשית: <strong>להיוועץ ברב שלך</strong>.
      </p>
    </div>
  </section>
'''
RH = lambda s: ' <em>הפניה: שולחן ערוך אדמו״ר הזקן שצ״ט:' + s + '.</em>'
HE['s4'] = [
    '<strong>① החבל:</strong> מודדים את תחום העיר בחבל של פשתן של חמשים אמה, לא פחות ולא יותר (שו״ע הרב שצ״ט:א); מודדים כנגד הלב (שו״ע הרב שצ״ט:ג), ומותחים את החבל בכל הכח (שו״ע הרב שצ״ט:ד).' + RH('א, ג, ד'),
    '<strong>② הנהר:</strong> אם יש לסוף ע״ה אמה מן העיר נהר הרחב יותר מכ״ה אמה — אחרי שמדד נ׳ אמה מן העיר חוזר לאחוריו כ״ה אמה, כדי שהחבל של נ׳ אמה יושלם עד הנהר (שו״ע הרב שצ״ט:ב).' + RH('ב'),
    '<strong>③ כנגד העיר:</strong> מודדים כנגד העיר, אפילו יש כנגדה הרים וגאיות; אין הולכים לצדה, במקום ישר, למדוד שם ולחזור אחר כך כנגד העיר לפי המדה שמדד שם (שו״ע הרב שצ״ט:ה). בהר או בגיא שאי אפשר להבליעו כנגד העיר, ראה נקודה ⑦.' + RH('ה'),
    '<strong>④ ההר:</strong> הר זקוף כל כך שחוט המשקולת אינו מתרחק ד׳ אמות — אין מודדים כלל את הירידה והעליה; מודדים את המישור שבראשו אם יש, ואם לאו מדלגים את ההר לגמרי, אף על פי שיכול להבליעו בחבל של נ׳ אמה. אם חוט המשקולת מתרחק ד׳ אמות, וההר מתלקט עשרה טפחים מתוך יותר מד׳ אמות: אם אין משפתו אל שפתו אלא נ׳ אמה ביושר — מבליעו בחבל של נ׳ אמה המתוח בין שני עצים הזקופים על שפתו; ואם לאו — מודדו בחבל של ד׳ אמות, התחתון כנגד לבו והעליון כנגד רגליו (שו״ע הרב שצ״ט:ו); ראה גם נקודה ⑦. בשיפוע מתון יותר נחלקו המפרשים: ראה פרק 2, נקודה ה, ורמה 2.' + RH('ו'),
    '<strong>⑤ שיפוע של עשרה טפחים מתוך ד׳ אמות:</strong> משערים באומד כמה יהיה בחבל המתוח מעץ לעץ שעל שפתיו; אם שיער שיהיה בו יותר מנ׳ אמה — מודדים את כולו בחבל של ד׳ אמות (שו״ע הרב שצ״ט:ז). בשיפוע כזה הרחב יותר מחמשים אמה נחלקו המפרשים: ראה פרק 2, נקודה ו, ורמה 2; היעזר ברב שלך.' + RH('ז'),
    '<strong>⑥ הכותל והגיא:</strong> כותל, בין זקוף בין שנפל, דינו כהר. גיא שאפשר להבליעו בחבל של נ׳ אמה — מבליעו ואינו משער באומד, אפילו מתלקט עשרה מתוך ד׳ אמות, ואפילו אין חוט המשקולת מתרחק ד׳ אמות. ואם אי אפשר להבליעו, וחוט המשקולת מתרחק ד׳ אמות — מודדו כולו בחבל של ד׳ אמות כבהר (ראה גם נקודה ⑦), ובלבד שלא יהיה עמוק יותר מאלפים; ואם הוא עמוק יותר מאלפים — מודד את הירידה והעליה של כל השיפוע כקרקע חלקה, אפילו אם יכול להבליעו. ואם אין החוט מתרחק ד׳ אמות — אינו מודד את השיפוע כלל, אלא את המישור שלמטה בלבד אם אינו יכול להבליעו, ואפילו עמוק יותר מאלפים (שו״ע הרב שצ״ט:ח).' + RH('ח'),
    '<strong>⑦ הבלעה מן הצד:</strong> הר או גיא הרחב מחמשים אמה כנגד העיר, ומתקצר מן הצד — אם יכול להבליעו בתוך אלפים של צד צפון או דרום, הולך לשם ומבליעו, וחוזר כנגד העיר לפי המדה שמדד שם; ואם אינו יכול להבליעו בתוך אלפים של צד העיר — אינו מתרחק יותר להבליעו, גזירה שמא יאמרו הרואים שמדת התחומין מגיעה לשם (שו״ע הרב שצ״ט:ט).' + RH('ט'),
    '<strong>⑧ המומחה:</strong> אין סומכים אלא על מדידת אדם מומחה, היודע מדת הקרקע (שו״ע הרב שצ״ט:י); תחומי שבת מוחזקין, ובא מומחה ומדד, ריבה במקצתם ומיעט במקצתם — שומעים לו אף בתחום שריבה (שו״ע הרב שצ״ט:יא). המשנה ברורה כותב, על סעיף ח של המחבר: ' + g('mb_29') + ' (משנה ברורה שצ״ט ס״ק כ״ט).' + RH('י, יא'),
    '<strong>⑨ מותח החוט באלכסון:</strong> מדד ומצא מדתו במזרחית צפונית יתרה על שכנגדה במזרחית דרומית — מותח את החוט של סימן התחום מזו לזו באלכסון. הרב מביא דעה (<em>[[r_yo]]</em>) שתולים בטעותו, ומוציאים את הקצרה עד כנגד הארוכה, ומסיים: «&nbsp;[[r_k3]]&nbsp;» (שו״ע הרב שצ״ט:יב). בדין זה נחלקו המפרשים: ראה פרק 2, נקודה י, ורמה 2; היעזר ברב שלך.' + RH('יב'),
    '<strong>⑩ שני מומחים:</strong> באו שני מומחים ומדדו את התחום, אחד ריבה ואחד מיעט — שומעים למרבה, ובלבד שלא ירבה יותר ממדת אלכסונה של קרן העיר; ואם ריבה יותר משיעור זה — אין שומעים לו (שו״ע הרב שצ״ט:יג). המשנה ברורה כותב, על סעיף ט של המחבר: ' + g('mb_39') + ' (משנה ברורה שצ״ט ס״ק ל״ט).' + RH('יג'),
    '<strong>⑪ כטבלא מרובעת:</strong> מודדים על פני כל אורך העיר אלפים אמה לחוץ למזרח, וכן לצפון, וממלאים את הקרן כטבלא מרובעת של אלפים על אלפים; וכן בשאר הקרנות. אין מודדים מן הקרן אלפים באלכסון, וכן מן הקרן שכנגדה, כדי למתוח את החוט מזו לזו (שו״ע הרב שצ״ט:יד).' + RH('יד'),
    '<strong>⑫ מי נאמן:</strong> עבד ושפחה כנעניים, שקיבלו עליהם מצוות שהאשה חייבת בהן, נאמנים לומר עד כאן תחום שבת; קטן אינו נאמן בעודו קטן; גדול נאמן לומר שזוכר שעד כאן היו באים בשבת כשהיה קטן, וסומכים על עדותו (שו״ע הרב שצ״ט:טו).' + RH('טו'),
]

# ============================================================================ ANGLAIS
EN = {}
EN['title'] = "Siman שצ״ט · Level 4 — Shitah of the Alter Rebbe: with what the limits are measured, where, and who measures | Hilchos Techumin"
EN['desc'] = ("Level 4 (Daat HaRav) of Siman שצ״ט — with what the Shabbos limits (techumin) are measured, where, and who measures: "
              "the flax cord of fifty amos, the river, the cord held opposite the heart and stretched with all one's strength, measuring opposite the town, "
              "the mountain and its slope, the wall and the valley, measuring at the side, the expert and established limits, the diagonal line, two experts, "
              "the square limit and its corners, who is believed about the limit. The full text of the 15 seifim of the Shulchan Aruch HaRav, "
              "their translation, where the Rav's text differs from the seifim of the Mechaber and the Rema, and the practical conduct.")
EN['og'] = ("The shitah of the Alter Rebbe on measuring the Shabbos limits: the cord, the mountain, the wall and the valley, "
            "the expert who measures, the square limit and testimony about the limit.")
EN['tw'] = "Shitah of the Alter Rebbe: with what the Shabbos limits are measured, where, and who measures."
EN['ld'] = ("Level 4 (Daat HaRav) of Siman שצ״ט: with what the Shabbos limits are measured, where, and who measures, "
            "in the Shulchan Aruch HaRav.")
EN['hero'] = '''<div class="page-hero">
  <div class="hero-inner">
    <div class="hero-meta">DAAT · LEVEL 4 — DAAT HARAV · Shitah of the Alter Rebbe</div>
    <p class="hero-title-he">דעת הרב</p>
    <h1 class="hero-title" style="margin: 0;">Daat HaRav — The Shulchan Aruch HaRav on Siman 399</h1>
    <p class="hero-subtitle">With what the limits (<em>techumin</em>) are measured, where, and who measures: the flax cord of fifty <em>amos</em>; the river at the end of seventy-five <em>amos</em>; the cord held opposite the heart, stretched with all one's strength; measuring opposite the town; the steep mountain, the slope and measuring with a cord of four <em>amos</em>; the wall and the valley; the mountain or valley absorbed at the side; the expert, established limits and the diagonal line; two experts who disagree; the square limit and its corners; who is believed about the limit. The 15 seifim of the Shulchan Aruch HaRav; the Mechaber's Shulchan Aruch has 11.</p>
  </div>
</div>
'''
EN['intro'] = '''  <div class="intro-block">
    <p><strong>Why a Level 4 dedicated to the Alter Rebbe?</strong> The <strong>Shulchan Aruch HaRav</strong> is not a commentary on the Mechaber: it is a Shulchan Aruch in its own right, written by the Alter Rebbe, with its own division and numbering of the seifim. Here the Shulchan Aruch HaRav announces 15 seifim at the head of the siman, and the Shulchan Aruch of the Mechaber has 11. Sefaria serves the Rav's text in 15 blocks, which this page reproduces and numbers as they stand (section 1). The Rav's seifim 1 and 2 correspond to the Mechaber's seifim א and ב; the Rav's seifim 3 and 4 divide between them the Mechaber's seif ג (the cord held opposite the heart, then stretched with all one's strength); the Rav's seifim 5, 6 and 7 divide between them the Mechaber's seif ד (measuring opposite the town, the mountain, then the slope of ten <em>tefachim</em> over four <em>amos</em>); the Rav's seif 8 corresponds to the Mechaber's seif ה (the valley), and opens by extending to a wall what was said of the mountain; the Rav's seifim 9 and 10 correspond to the Mechaber's seifim ו and ז; the Rav's seif 11 corresponds to the Mechaber's seif ח, and the Rav's seif 12 to the gloss introduced by הגה at the end of that seif; the Rav's seifim 13, 14 and 15 correspond to the Mechaber's seifim ט, י and יא. In the English text of this page, the Rav's seifim are designated by their number (399:4, seif 4), the Mechaber's by their Hebrew letter (the Mechaber's seif ד); in the Hebrew references in parentheses, both numberings are in letters, and the reference always names the work (שו״ע או״ח for the Mechaber, שו״ע הרב for the Rav).</p>
    <p>This page gathers, for Siman 399, the full text of the Rav with its translation, where his text differs from that of the Mechaber and the Rema, and the practical conduct that follows from it.</p>
    <p style="margin-top:14px;"><a href="../../../chitah-admour-hazaken-en.html" style="color:var(--habad);font-weight:600;">→ Read the general preface on the shitah of the Alter Rebbe</a></p>
  </div>
'''
EN['s1_head'] = '''  <!-- 1. TEXTE DU CHOULHAN AROUKH HARAV -->
  <section class="section-block">
    <span class="section-num">1 · Text of the Alter Rebbe</span>
    <h2 class="section-title-he" id="שלחן-ערוך-הרב-סימן-שצ״ט">שלחן ערוך הרב — סימן שצ״ט</h2>
    <h2 class="section-title-fr" id="the-full-text-of-the-shulchan-aruch-harav-of-the-alter-rebbe">The full text of the Shulchan Aruch HaRav of the Alter Rebbe</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 24px; color: var(--text-mid); font-size: 15px;">
      <strong>''' + CHAP_LIGNE + '''</strong><br>
      <em>Source: Kehot edition, as reproduced on Sefaria. The heading announces 15 seifim; Sefaria serves the text in 15 blocks (the Mechaber's Shulchan Aruch has 11 seifim, under its own numbering).</em>
    </p>
'''
EN['s1_source'] = '''    <p style="margin-top: 20px; font-size: 13px; color: var(--text-muted); font-style: italic;">
      Source: <a href="https://www.sefaria.org/Shulchan_Arukh_HaRav%2C_Orach_Chayim.399" target="_blank" style="color: var(--habad);">Sefaria — Shulchan Arukh HaRav, Orach Chayim 399</a>. Sefaria gives no Kuntres Acharon entry for this siman. The text is copied as Sefaria serves it. In seif 13, the words ''' + Q['w_misof'] + ''' and ''' + Q['w_metsela'] + ''' are vocalized thus in the text served; they are left as they stand.
    </p>'''
EN['trad_cls'] = 'sa-en'
EN['trads'] = [
    # 1
    "With what the limits (<em>techumin</em>) are measured, the place of the measuring, and who is the one who measures; it contains 15 <em>seifim</em>:<br><br>"
    "The limit (<em>techum</em>) of the town is measured only with a cord of flax of fifty <em>amos</em>. Not less, because when it is short it stretches excessively and lengthens the measure needlessly (and likewise one of other kinds stretches excessively); and not longer, because it does not stretch properly: its weight makes it sag, it shortens in its middle and shortens the measure of the limit:",
    # 2
    "If there is before him, at the end of seventy-five <em>amos</em> from the town, a river wider than twenty-five <em>amos</em>, which he cannot absorb (<em>lehavlio</em>) in a cord of fifty <em>amos</em> when he measures with it from the end of the fifty [<em>amos</em>] from the town — the place where the cord ended the [first] time —, what shall he do? After he has measured fifty <em>amos</em> from the town, he goes back twenty-five <em>amos</em>, so that the cord of fifty <em>amos</em> is completed up to the river:",
    # 3
    "He shall measure only opposite his heart, for the Sages fixed for him a place opposite which to put the end of the cord, so that one should not put it opposite his neck and the other opposite his feet, [for then] the cord shortens and the limits are diminished:",
    # 4
    "And he must stretch the cord with all his strength, because it weighs down in its middle:",
    # 5
    "He shall measure only opposite the town. Even if there are mountains and valleys opposite it, he shall not go from opposite it to its side, where it is straight, and measure there, and then return opposite the town according to the measure he measured there; rather, he shall measure opposite the town, in order to absorb the mountains and valleys that are opposite it, or to measure it in the manner that will be explained:",
    # 6
    "If he reached a mountain: if it is so steep that, were a plumb line lowered from its top, it would not move away four <em>amos</em> from the point opposite it below, at its foot, he need not measure the descent and the ascent at all; rather, if there is a plateau (<em>mishor</em>) on its top, he measures it, and if there is no plateau on its top, he does not measure it at all but skips it entirely, even though he could absorb it in a cord of fifty <em>amos</em>.<br><br>"
    "And if the plumb line moves away four <em>amos</em> from the point opposite it, and it rises (<em>mitlaket</em>) ten <em>tefachim</em> over more than four <em>amos</em> — that is, in walking more than four <em>amos</em> of slope one climbs ten <em>tefachim</em> in height — then one looks: if there are only fifty <em>amos</em> from its edge to its edge in a straight line — were one to bore through it at its foot near its edge and measure through the hole —, then he must absorb it in a cord of fifty <em>amos</em>: he sets up a tall pole at its edge on this side and another pole opposite it at its edge on that side, and stretches a cord from one to the other.<br><br>"
    "And if he cannot absorb it in a cord of fifty <em>amos</em>, he measures it with a cord of four <em>amos</em>, and he shall do so: one stands at the foot of the mountain below and one above him at a distance of four <em>amos</em>; the lower one puts the cord opposite his heart and the upper one opposite his feet; the lower one goes up to the place where the upper one stands, and the upper one goes up four <em>amos</em>, and they measure as at first; and so he shall do until they have measured the whole mountain on its two sides. It turns out that its slope is reduced, in every four <em>amos</em>, by more than half a man's height, as from his heart to his feet:",
    # 7
    "And if it is more sloping, so that it rises ten <em>tefachim</em> over four <em>amos</em>: since walking on it is not of convenient use, and it is a bother to climb and to stretch a cord from the pole at its edge on this side to the pole opposite it, the Sages did not burden him with this; rather, he estimates by approximation how much there would be in the cord that would be stretched over it from pole to pole, were they set up at its edges on this side and that, and he goes on to measure further, to complete the measure of his limit.<br><br>"
    "And if he estimated in his mind that there would be more than fifty <em>amos</em> in it: since, were it not so sloping, he would have had to measure its whole slope with a cord of four <em>amos</em>, even when it is so sloping they were not lenient in this to estimate by the approximation of his mind how much there would be in the stretched cord; rather, he must measure all of it with a cord of four <em>amos</em>:",
    # 8
    "And all this is for a mountain, and likewise for a wall, whether it stands upright or has fallen and become like a mountain. But if he reached a valley (<em>gai</em>): if he can absorb it in a cord of fifty <em>amos</em>, he must absorb it and not estimate by the approximation of his mind, even if it rises ten [<em>tefachim</em>] over four <em>amos</em>, because he can absorb it easily: one stands on this side and one on that side, and there is no need to set up poles at all. And for this reason, even if the plumb line does not move away four <em>amos</em> below from the point opposite it, he must absorb it.<br><br>"
    "But if he cannot absorb it in a cord of fifty <em>amos</em>: if the plumb line moves away four <em>amos</em> from the point opposite it, he measures all of it with a cord of four <em>amos</em>, as for a mountain.<br><br>"
    "And this is provided that it is not deeper than two thousand [<em>amos</em>]. But if it is deeper than two thousand, he measures the descent and the ascent of the whole slope with a full measurement (<em>medidah yafah</em>), like smooth ground, even if he can absorb it in a cord of fifty <em>amos</em>.<br><br>"
    "And if the line does not move away four <em>amos</em> from the point opposite it, he does not measure the slope of the descent and ascent at all, but only the level ground below, if he cannot absorb it; and even if it is deeper than two thousand:",
    # 9
    "If he reached a mountain or a valley, and all of it that is opposite the town is wider than fifty <em>amos</em>, so that he cannot absorb it, and at the side it keeps narrowing — for example, it is to the east of the town, and along the whole length of the east he cannot absorb it —: if he can absorb it within the two thousand [<em>amos</em>] of the north or south side, he shall go there and absorb it, since it is still within the limit of the town's side, and afterward return opposite the town according to the measure he measured there. But if he cannot absorb it within the two thousand of the town's side, he shall not go farther away to absorb it — a decree (<em>gezeirah</em>), lest onlookers say that the measure of the limits reaches here:",
    # 10
    "One relies only on the measuring of an expert (<em>mumcheh</em>), who knows the measuring of land:",
    # 11
    "If we had established (<em>muchzakin</em>) Shabbos limits, and an expert came and measured, increasing the limit in some of them and decreasing the limit in others — we listen to him even for the limit he increased, although it is to be lenient, because we attribute [the difference], saying that the first ones did not stretch the cord as much as needed, since it must be stretched with all one's strength:",
    # 12
    "If he measured and found his measure in the northeast (<em>mizrachis tzefonis</em>) longer than the one opposite it in the southeast (<em>mizrachis deromis</em>), he stretches the line of the limit marker from one to the other diagonally (<em>alachson</em>). And we do not say that he erred in one of them; rather, we attribute [the difference] to this, that the one that was shortened is so because of mountains and valleys that are there, and he had to measure them in a way that shortened the limit. And some say (<em>yesh omrim</em>) that we attribute it to his error, and we go to be lenient, saying that he erred in the one that was shortened for him, and we extend it further, until opposite the long one (and the main view is like the first opinion):",
    # 13
    "If two experts came and measured the limit, one increased and one decreased — we listen to the one who increases, to be lenient in [matters] of the words of the Sofrim, provided that he does not increase more than the measure of the diagonal of the corner of the town. How so? When this one increases, we shall say: perhaps the first measured the two thousand [<em>amos</em>] from the diagonal corner of the town also diagonally, and likewise from the corner opposite it; and it turns out that when a line is stretched from the end of the limit [measured] from this corner to the end of the limit [measured] from that corner, there will be less than two thousand [<em>amos</em>] between this line and the town; and the last one measured properly, from the side of the town. And we do not presume that the first erred by more than this measure. Therefore, if the last one increased by more than this measure, we do not listen to him.<br><br>"
    "And this measure is the measure of the excess that a side two thousand long has over the side of a square whose diagonal is two thousand; for from the town to the line stretched from the end of the two thousand [measured] along the diagonal is the side of a square whose diagonal is two thousand. And the measure of this side is approximately 1,428 <em>amos</em>, according to the calculation of the Sages of the Talmud — which is approximate and not exact — [by which], in every diagonal, it exceeds the sides of its square by two fifths of the length of the side; it turns out that, over 1,428, its diagonal exceeds by 2,856 fifths, which are 572 <em>amos</em> less four fifths; add them to 1,428 — they make two thousand <em>amos</em> less four fifths. But according to the calculation of the geometers (<em>chachmei hamiddos</em>), who were precise and exact in the calculation for every diagonal, this excess will be approximately 585 <em>amos</em>:",
    # 14
    "The limits are made around the town like a square tablet: that is, he measures along the whole length of the town two thousand <em>amos</em> outward to the east, and likewise to the north, and afterward one views it as if there were a square tablet of two thousand by two thousand in the corner to fill it; and it turns out that the limit in the corner is two thousand and [their] diagonal, which are 2,800; and so he shall do at the other corners. But he shall not measure from the middle of the corner two thousand diagonally, and likewise at the opposite corner, and put the line from one to the other, for if so he loses the eight hundred that are in the corner, and moreover the limit opposite the town will be only 1,428, and according to the calculation of the geometers 1,415:",
    # 15
    "Even a Canaanite slave and maidservant, who have accepted upon themselves the commandments that a woman is obligated in, are believed to say “up to here is the Shabbos limit”, for the Sages did not say the matter to be stringent but to be lenient.<br><br>"
    "But a minor is not believed while he is still a minor. But an adult is believed to say “I remember that up to here we used to come on Shabbos when I was a minor”, and one relies on his testimony:",
]
EN['s2_head'] = '''  <!-- 2. LE TEXTE DU RAV ET CELUI DU MEHABER -->
  <section class="section-block">
    <span class="section-num">2 · The Rav's text and the Mechaber's</span>
    <h2 class="section-title-he" id="לשון-הרב-מול-סעיף-המחבר-והרמ״א">לשון הרב מול סעיף המחבר והרמ״א</h2>
    <h2 class="section-title-fr" id="where-the-rav-s-text-differs-from-the-mechaber-s-seif-and-the-rema-s">Where the Rav's text differs from the Mechaber's seif and the Rema's</h2>
    <div class="section-divider"></div>
    <p style="margin-bottom: 24px; color: var(--text-mid);">
      Each point sets side by side a seif of the Mechaber's Shulchan Aruch (its numbering, 11 seifim, designated by their letter), or the Rema's gloss, and the corresponding seif of the Shulchan Aruch HaRav (its own numbering, 15 seifim), in the order of the Rav's seifim, and notes only what the comparison of the two texts shows. A point noted is not thereby peculiar to the Rav: the page sometimes names its source; it notes neither all the sources nor all the divergences. Where it notes that the commentators differ on a case, it refers to Level 2.
    </p>
'''
EN['points'] = [
    dict(he_t='נקודה א — חבל של פשתן (שו״ע הרב שצ״ט:א)', t='Point א — the flax cord (Shulchan Aruch HaRav 399:1)',
         id='neither-shorter-nor-longer', h3='Neither shorter nor longer',
         meh=g('m_a') + ' (שו״ע או״ח שצ״ט:א).', rav=g('r_a') + ' (שו״ע הרב שצ״ט:א).',
         diff="the Mechaber writes that the shorter cord stretches excessively and that the longer one does not stretch properly; the Rav's text states the effect: the short cord lengthens the measure needlessly; the long one, its weight makes it sag, it shortens in its middle and shortens the measure of the limit. It adds, in parentheses, that one of other kinds also stretches excessively."),
    dict(he_t='נקודה ב — נהר (שו״ע הרב שצ״ט:ב)', t='Point ב — the river (Shulchan Aruch HaRav 399:2)',
         id='a-river-wider-than-twenty-five-amos', h3='A river wider than twenty-five amos',
         meh=g('m_b') + ' (שו״ע או״ח שצ״ט:ב).', rav=g('r_b') + ' (שו״ע הרב שצ״ט:ב).',
         diff="the Mechaber's seif ב does not state the river's width; the Rav's text states it: a river wider than twenty-five <em>amos</em>, which cannot be absorbed in the cord of fifty <em>amos</em> measured from the end of the first fifty. The Mishnah Berurah reads the Mechaber's seif the same way: " + g('mb_c') + ' (משנה ברורה שצ״ט ס״ק ג).'),
    dict(he_t='נקודה ג — כנגד לבו (שו״ע הרב שצ״ט:ג, ד)', t='Point ג — the cord opposite the heart, stretched with all one\'s strength (Shulchan Aruch HaRav 399:3, 4)',
         id='two-seifim-two-reasons', h3='Two seifim, two reasons',
         meh=g('m_c') + ' (שו״ע או״ח שצ״ט:ג).',
         rav='in seif 3, ' + g('r_c1') + ' (שו״ע הרב שצ״ט:ג); in seif 4, ' + g('r_c2') + ' (שו״ע הרב שצ״ט:ד).',
         diff="the Rav makes two seifim of the Mechaber's seif ג, and gives the reason for each of the two instructions. In seif 3, his wording is that of the Mishnah: " + g('mish_c') + ' (משנה עירובין ה:ד).'),
    dict(he_t='נקודה ד — כנגד העיר (שו״ע הרב שצ״ט:ה)', t='Point ד — measuring opposite the town (Shulchan Aruch HaRav 399:5)',
         id='to-absorb-the-mountains', h3='To absorb the mountains',
         meh=g('m_d') + ' (שו״ע או״ח שצ״ט:ד).', rav=g('r_d') + ' (שו״ע הרב שצ״ט:ה).',
         diff="the Mechaber writes that one measures opposite the town; the Rav's text states the purpose: to absorb the mountains and valleys that are opposite it, or to measure it in the manner that will be explained."),
    dict(he_t='נקודה ה — הגיע להר (שו״ע הרב שצ״ט:ו)', t='Point ה — the mountain (Shulchan Aruch HaRav 399:6)',
         id='the-steep-mountain-and-the-slope', h3='The steep mountain and the slope',
         meh=g('m_e') + ' (שו״ע או״ח שצ״ט:ד); ' + g('m_f') + ' (שו״ע או״ח שצ״ט:ד).', rav=g('r_e') + ' (שו״ע הרב שצ״ט:ו); ' + g('r_f') + ' (שו״ע הרב שצ״ט:ו).',
         diff="for the steep mountain, the Mechaber's seif ד writes that one need not measure the descent and the ascent if there is a plateau on its top, and that one measures nothing if there is none; the Rav's text writes explicitly that the plateau on the top is measured, and adds: even though one could absorb the mountain in a cord of fifty <em>amos</em>. The Mishnah Berurah reads the Mechaber's seif the same way: " + g('mb_e') + " (משנה ברורה שצ״ט ס״ק י). For the slope, the Mechaber writes: ten [<em>tefachim</em>] over five [<em>amos</em>]; the Rav's text: ten <em>tefachim</em> over more than four <em>amos</em>. The Rav's text also explains what measuring in a straight line is (as if one bored through the mountain at its foot), and what measuring with the cord of four <em>amos</em> takes off the slope each time (more than half a man's height).",
         comm="on a gentler slope, the commentators differ: see Level 2."),
    dict(he_t='נקודה ו — הר המשופע ביותר (שו״ע הרב שצ״ט:ז)', t='Point ו — the slope of ten tefachim over four amos (Shulchan Aruch HaRav 399:7)',
         id='the-estimate-and-its-limit', h3='The estimate and its limit',
         meh=g('m_g') + ' (שו״ע או״ח שצ״ט:ד).', rav=g('r_g') + ' (שו״ע הרב שצ״ט:ז).',
         diff="both texts write that a slope of ten [<em>tefachim</em>] over four <em>amos</em> is estimated if it has only fifty <em>amos</em>, and is measured with the cord of four <em>amos</em> if it has more. The Rav's text gives the reason for the leniency (walking on it is not of convenient use, and it is a bother to climb and stretch a cord from pole to pole) and the reason for its limit (were it less sloping, it would have had to be measured entirely with the cord of four <em>amos</em>).",
         comm="on a slope of this kind wider than fifty <em>amos</em>, the commentators differ: see Level 2."),
    dict(he_t='נקודה ז — כותל וגיא (שו״ע הרב שצ״ט:ח)', t='Point ז — the wall and the valley (Shulchan Aruch HaRav 399:8)',
         id='the-valley-is-absorbed-without-poles', h3='The valley is absorbed without poles',
         meh=g('m_h') + ' (שו״ע או״ח שצ״ט:ה).', rav=g('r_h1') + ' (שו״ע הרב שצ״ט:ח); ' + g('r_h2') + ' (שו״ע הרב שצ״ט:ח).',
         diff="the Rav's text extends to a wall, standing or fallen, what was said of the mountain. For the valley, it first asks about absorbing: a valley that can be absorbed in the cord of fifty <em>amos</em> is absorbed without estimating, even if it rises ten [<em>tefachim</em>] over four <em>amos</em>, and even if the plumb line does not move away four <em>amos</em>, because it is absorbed easily, without setting up poles; it then deals with the valley that cannot be absorbed, and with the valley deeper than two thousand [<em>amos</em>] (see the translation in section 1). The Mechaber's seif ה first asks about the plumb line, and does not speak of estimating for the valley."),
    dict(he_t='נקודה ח — הר או גיא המתקצר מן הצד (שו״ע הרב שצ״ט:ט)', t='Point ח — the mountain or valley absorbed at the side (Shulchan Aruch HaRav 399:9)',
         id='the-reason-for-the-limit', h3='The reason for the limit',
         meh=g('m_i') + ' (שו״ע או״ח שצ״ט:ו).', rav=g('r_i') + ' (שו״ע הרב שצ״ט:ט).',
         diff="the Mechaber writes that one does not go farther away; the Rav's text gives the reason: a decree, lest onlookers say that the measure of the limits reaches there. It also writes that after absorbing at the side, one returns opposite the town according to the measure taken there."),
    dict(he_t='נקודה ט — תחומין מוחזקין (שו״ע הרב שצ״ט:יא)', t='Point ט — established limits (Shulchan Aruch HaRav 399:11)',
         id='why-the-expert-who-increases-is-heeded', h3='Why the expert who increases is heeded',
         meh=g('m_j') + ' (שו״ע או״ח שצ״ט:ח).', rav=g('r_j') + ' (שו״ע הרב שצ״ט:יא).',
         diff="the Rav's text adds: although it is to be lenient; and gives the reason: we attribute [the difference] to the first ones not having stretched the cord as much as needed."),
    dict(he_t='נקודה י — מותח החוט באלכסון (שו״ע הרב שצ״ט:יב)', t='Point י — the line stretched diagonally (Shulchan Aruch HaRav 399:12)',
         id='the-diagonal-and-the-contrary-view', h3='The diagonal and the contrary view', rama=True,
         meh='the gloss introduced by הגה at the end of seif ח: ' + g('m_k') + ' (שו״ע או״ח שצ״ט:ח).', rav=g('r_k1') + ' (שו״ע הרב שצ״ט:יב); and ' + g('r_k2') + ' (שו״ע הרב שצ״ט:יב).',
         diff="the gloss reports the line stretched diagonally, then, introduced by <em>וי״א</em>, the view of measuring evenly. The Rav's text gives the reason for each — for the first, the shorter measure comes from mountains and valleys that had to be measured; for the second, the difference is attributed to an error in the shortened measure — and concludes, in parentheses, that the main view is like the first opinion. The gloss does not have this conclusion.",
         comm="on this case, the commentators differ: see Level 2."),
    dict(he_t='נקודה יא — שני מומחים (שו״ע הרב שצ״ט:יג)', t='Point יא — two experts (Shulchan Aruch HaRav 399:13)',
         id='how-far-the-one-who-increases-is-heeded', h3='How far the one who increases is heeded',
         meh=g('m_l') + ' (שו״ע או״ח שצ״ט:ט).', rav=g('r_l1') + ' (שו״ע הרב שצ״ט:יג); ' + g('r_l2') + ' (שו״ע הרב שצ״ט:יג); ' + g('r_l3') + ' (שו״ע הרב שצ״ט:יג).',
         diff="the Rav's text gives the reason (to be lenient in matters of the words of the Sofrim); it writes <em>the diagonal of the corner of the town</em> where the Mechaber writes <em>the diagonal of the town</em>; it explains that the first may have measured diagonally from two opposite corners; it writes that the last one is not heeded if he increases by more than this measure; and it quantifies it: the side of a square whose diagonal is two thousand is about 1,428 <em>amos</em> according to the calculation of the Sages of the Talmud, and the excess is about 585 <em>amos</em> according to the calculation of the geometers."),
    dict(he_t='נקודה יב — כטבלא מרובעת (שו״ע הרב שצ״ט:יד)', t='Point יב — the square limit (Shulchan Aruch HaRav 399:14)',
         id='the-calculation-of-the-geometers', h3='The calculation of the geometers',
         meh=g('m_m') + ' (שו״ע או״ח שצ״ט:י).', rav=g('r_m') + ' (שו״ע הרב שצ״ט:יד).',
         diff="the Mechaber writes 1,428; the Rav's text adds, according to the calculation of the geometers, 1,415. In seif 13, it calls the first calculation that of the Sages of the Talmud, approximate and not exact."),
    dict(he_t='נקודה יג — עבד ושפחה (שו״ע הרב שצ״ט:טו)', t='Point יג — who is believed (Shulchan Aruch HaRav 399:15)',
         id='the-canaanite-slave-and-the-reason-of-the-mishnah', h3='The Canaanite slave and the reason of the Mishnah',
         meh=g('m_n') + ' (שו״ע או״ח שצ״ט:יא).', rav=g('r_n1') + ' (שו״ע הרב שצ״ט:טו); ' + g('r_n2') + ' (שו״ע הרב שצ״ט:טו).',
         diff="the Rav's text specifies which slave and which maidservant are meant — Canaanite, who have accepted the commandments that a woman is obligated in — and gives the reason, which is the wording of the Mishnah: " + g('mish_n') + ' (משנה עירובין ה:ה).'),
]
EN['s4_head'] = '''    <!-- 4. LEMAASEH (למעשה) -->
  <section class="section-block">
    <span class="section-num">4 · Lemaaseh</span>
    <h2 class="section-title-he" id="הלכה-למעשה-מנהג-חב״ד">הלכה למעשה — מנהג חב״ד</h2>
    <h2 class="section-title-fr" id="the-practical-chabad-conduct">The practical Chabad conduct</h2>
    <div class="section-divider"></div>

    <p style="margin-bottom: 22px; color: var(--text-mid);">
      Points of halachic conduct that flow directly from the Shulchan Aruch HaRav Siman 399, in the Chabad sensibility. Each point refers to its seif of the Rav, in the order of the text.
    </p>

    <div class="lemaaseh-block">
      <h3 id="for-the-chabad-chassid-siman-399">For the Chabad Chassid — Siman 399</h3>
      <ul>'''
EN['s4_foot'] = '''      </ul>

      <p style="margin-top: 22px; font-size: 13px; color: var(--text-muted); font-style: italic; padding-top: 14px; border-top: 1px dashed var(--border);">
        ⚠ This section presents the Chabad halachic conduct. For any concrete question: <strong>consult your Rav</strong>.
      </p>
    </div>
  </section>
'''
RE_ = lambda s: ' <em>Reference: Shulchan Aruch HaRav 399:' + s + '.</em>'
EN['s4'] = [
    "<strong>① The cord:</strong> the town's limit is measured with a flax cord of fifty <em>amos</em>, neither shorter nor longer (399:1); one measures opposite the heart (399:3), and stretches the cord with all one's strength (399:4)." + RE_('1, 3, 4'),
    "<strong>② The river:</strong> if there is, at the end of seventy-five <em>amos</em> from the town, a river wider than twenty-five <em>amos</em>, after measuring fifty <em>amos</em> from the town one goes back twenty-five <em>amos</em>, so that the cord of fifty <em>amos</em> is completed up to the river (399:2)." + RE_('2'),
    "<strong>③ Opposite the town:</strong> one measures opposite the town, even if there are mountains and valleys opposite it; one does not go to measure at its side, where it is straight, and then return opposite the town according to the measure taken there (399:5). For a mountain or valley that cannot be absorbed opposite the town, see point ⑦." + RE_('5'),
    "<strong>④ The mountain:</strong> if it is so steep that the plumb line does not move away four <em>amos</em>, one does not measure the descent and the ascent at all; one measures the plateau on its top if there is one, and otherwise skips the mountain entirely, even though one could absorb it in a cord of fifty <em>amos</em>. If the plumb line moves away four <em>amos</em> and it rises ten <em>tefachim</em> over more than four <em>amos</em>: if there are only fifty <em>amos</em> from edge to edge in a straight line, one absorbs it in a cord of fifty <em>amos</em> stretched between two poles set up at its edges; otherwise, one measures it with a cord of four <em>amos</em>, the lower one holding it opposite his heart and the upper one opposite his feet (399:6); see also point ⑦. On a gentler slope, the commentators differ: see section 2, point ה, and Level 2." + RE_('6'),
    "<strong>⑤ The slope of ten <em>tefachim</em> over four <em>amos</em>:</strong> one estimates how much there would be in the cord stretched from pole to pole at its edges; if one estimates that there would be more than fifty <em>amos</em>, one measures the whole slope with a cord of four <em>amos</em> (399:7). On a slope of this kind wider than fifty <em>amos</em>, the commentators differ: see section 2, point ו, and Level 2; consult your Rav." + RE_('7'),
    "<strong>⑥ The wall and the valley:</strong> a wall, standing or fallen, is measured like a mountain. A valley that can be absorbed in a cord of fifty <em>amos</em> is absorbed, without estimating, even if it rises ten [<em>tefachim</em>] over four <em>amos</em>, and even if the plumb line does not move away four <em>amos</em>. If it cannot be absorbed and the plumb line moves away four <em>amos</em>, it is measured entirely with a cord of four <em>amos</em>, like a mountain (see also point ⑦), provided that it is not deeper than two thousand [<em>amos</em>]; if it is, the whole slope, descent and ascent, is measured like smooth ground, even if it can be absorbed. If the plumb line does not move away four <em>amos</em>, the slope is not measured, but only the level ground below, if it cannot be absorbed, even if it is deeper than two thousand (399:8)." + RE_('8'),
    "<strong>⑦ Absorbing at the side:</strong> a mountain or valley wider than fifty <em>amos</em> opposite the town, which narrows at the side: if one can absorb it within the two thousand [<em>amos</em>] of the north or south side, one goes to absorb it there, then returns opposite the town according to the measure taken there; if one cannot absorb it within the two thousand of the town's side, one does not go farther away to absorb it, lest onlookers say that the measure of the limits reaches there (399:9)." + RE_('9'),
    "<strong>⑧ The expert:</strong> one relies only on the measuring of an expert, who knows the measuring of land (399:10); when there are established Shabbos limits and an expert, measuring them, increases some and decreases others, he is heeded even where he increased (399:11). The Mishnah Berurah writes, on the Mechaber's seif ח: " + g('mb_29') + " (משנה ברורה שצ״ט ס״ק כ״ט) — it is plain that [the seif] speaks of the case where we do not know that the first presumption was made by an expert's measuring; otherwise, the second is heeded only when he increases, and not when he decreases." + RE_('10, 11'),
    "<strong>⑨ The line stretched diagonally:</strong> if the measure in the northeast is longer than the one opposite it in the southeast, one stretches the line of the limit marker from one to the other diagonally. The Rav reports a view (<em>[[r_yo]]</em>) that the difference is attributed to an error in the shortened measure, which is extended until opposite the long one, and concludes: «&nbsp;[[r_k3]]&nbsp;» (שו״ע הרב שצ״ט:יב). On this case, the commentators differ: see section 2, point י, and Level 2; consult your Rav." + RE_('12'),
    "<strong>⑩ Two experts:</strong> if two experts measured the limit, one increasing and one decreasing, the one who increases is heeded, provided that he does not increase more than the measure of the diagonal of the corner of the town; if he increases by more than this measure, he is not heeded (399:13). The Mishnah Berurah writes, on the Mechaber's seif ט: " + g('mb_39') + " (משנה ברורה שצ״ט ס״ק ל״ט) — and if it happens that they differ in the measuring by more than this measure, it is reasonable that the measuring of neither of them is followed, and one must measure anew and clarify the matter." + RE_('13'),
    "<strong>⑪ The square limit:</strong> two thousand <em>amos</em> are measured outward along the whole length of the town, to the east, and likewise to the north, and the corner is filled as with a square tablet of two thousand by two thousand; and so at the other corners. One does not measure two thousand diagonally from the corner, and likewise from the opposite corner, to stretch the line from one to the other (399:14)." + RE_('14'),
    "<strong>⑫ Who is believed:</strong> a Canaanite slave and maidservant, who have accepted the commandments that a woman is obligated in, are believed to say <em>up to here is the Shabbos limit</em>; a minor is not believed while he is a minor; an adult is believed to say that he remembers that up to there they used to come on Shabbos when he was a minor, and one relies on his testimony (399:15)." + RE_('15'),
]

CONTENU = {'fr': FR, 'he': HE, 'en': EN}
